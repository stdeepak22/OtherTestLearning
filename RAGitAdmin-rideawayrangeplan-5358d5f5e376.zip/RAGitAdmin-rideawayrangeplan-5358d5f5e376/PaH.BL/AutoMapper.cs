﻿using System;
using AutoMapper;

namespace PaH.BL
{
    /// <summary>
    /// Static AutoMapper mapping class to define the mapping between 
    /// SqlModel and UiModel
    /// Need to call it in Global.asax
    /// </summary>
    public static class AutoMapper
    {
        public static void ConfigureMapping()
        {
            Mapper.CreateMap<PaH.SqlModel.ComboModel.Age, PaH.UiModel.ComboModel.Age>().ReverseMap();

            Mapper.CreateMap<PaH.SqlModel.ComboModel.CatalogueCategory, PaH.UiModel.ComboModel.CatalogueCategory>()
                  .ForMember(c => c.CatalogueSubCategories, opt => opt.MapFrom(src => src.CatalogueSubCategories))
                  .ReverseMap();

            //Mapper.CreateMap<PaH.UiModel.ComboModel.CatalogueCategory, PaH.SqlModel.ComboModel.CatalogueCategory>();


            Mapper.CreateMap<PaH.SqlModel.ComboModel.CatalogueSubCategory, PaH.UiModel.ComboModel.CatalogueSubCategory>()
                  .ForMember(c => c.CatalogueCategory, opt => opt.MapFrom(src => src.CatalogueCategory)).ReverseMap();
            //.ReverseMap();


            Mapper.CreateMap<PaH.SqlModel.ComboModel.CoreSeasonalRange, PaH.UiModel.ComboModel.CoreSeasonalRange>()
                  .ReverseMap();

            Mapper.CreateMap<PaH.SqlModel.ComboModel.DeliveryOption, PaH.UiModel.ComboModel.DeliveryOption>()
                  .ReverseMap();

            Mapper
                .CreateMap
                <PaH.SqlModel.ComboModel.DropDownDefiningAttribute, PaH.UiModel.ComboModel.DropDownDefiningAttribute>()
                .ReverseMap();

            Mapper.CreateMap<PaH.SqlModel.ComboModel.FoodNonFood, PaH.UiModel.ComboModel.FoodNonFood>().ReverseMap();

            Mapper.CreateMap<PaH.SqlModel.ComboModel.GBB, PaH.UiModel.ComboModel.GBB>().ReverseMap();

            Mapper.CreateMap<PaH.SqlModel.ComboModel.Gender, PaH.UiModel.ComboModel.Gender>().ReverseMap();

            Mapper.CreateMap<PaH.SqlModel.ComboModel.MainColour, PaH.UiModel.ComboModel.MainColour>().ReverseMap();

            Mapper.CreateMap<PaH.SqlModel.ComboModel.NewRI, PaH.UiModel.ComboModel.NewRI>().ReverseMap();

            Mapper.CreateMap<PaH.SqlModel.ComboModel.Outlet, PaH.UiModel.ComboModel.Outlet>().ReverseMap();

            Mapper.CreateMap<PaH.SqlModel.ComboModel.PackSize, PaH.UiModel.ComboModel.PackSize>().ReverseMap();

            Mapper.CreateMap<PaH.SqlModel.ComboModel.ProductCategory, PaH.UiModel.ComboModel.ProductCategory>()
                  .ReverseMap();

            Mapper.CreateMap<PaH.SqlModel.ComboModel.RaCategory, PaH.UiModel.ComboModel.RaCategory>()
                .ForMember(c => c.RaSubCategories, opt => opt.MapFrom(src => src.RaSubCategories))
                .ReverseMap();

            Mapper.CreateMap<PaH.SqlModel.ComboModel.RaSubCategory, PaH.UiModel.ComboModel.RaSubCategory>()
                .ForMember(c => c.RaCategory, opt => opt.MapFrom(src => src.RaCategory))
                .ReverseMap();

            Mapper.CreateMap<PaH.SqlModel.ComboModel.RaSubSubCategory, PaH.UiModel.ComboModel.RaSubSubCategory>()
                  .ForMember(c => c.RaCategory, opt => opt.MapFrom(src => src.RaCategory))
                  .ForMember(c => c.RaSubCategory, opt => opt.MapFrom(src => src.RaSubCategory))
                  .ReverseMap();

            Mapper.CreateMap<PaH.SqlModel.ComboModel.Shot, PaH.UiModel.ComboModel.Shot>().ReverseMap();

            Mapper.CreateMap<PaH.SqlModel.ComboModel.Status, PaH.UiModel.ComboModel.Status>().ReverseMap();

            Mapper.CreateMap<PaH.SqlModel.ComboModel.Supplier, PaH.UiModel.ComboModel.Supplier>().ReverseMap();

            Mapper.CreateMap<PaH.SqlModel.ComboModel.VAT, PaH.UiModel.ComboModel.VAT>().ReverseMap();

            Mapper.CreateMap<PaH.SqlModel.ComboModel.WebCategory, PaH.UiModel.ComboModel.WebCategory>()
                .ForMember(c => c.WebSubCategories, opt => opt.MapFrom(src => src.WebSubCategories))
                .ReverseMap();

            Mapper.CreateMap<PaH.SqlModel.ComboModel.WebSubCategory, PaH.UiModel.ComboModel.WebSubCategory>()
                  .ForMember(c => c.WebCategory, opt => opt.MapFrom(src => src.WebCategory))
                  .ForMember(c => c.WebSubSubCategories, opt => opt.MapFrom(src => src.WebSubSubCategories))
                  .ReverseMap();

            Mapper.CreateMap<PaH.SqlModel.ComboModel.WebSubSubCategory, PaH.UiModel.ComboModel.WebSubSubCategory>()
                  .ForMember(c => c.WebCategory, opt => opt.MapFrom(src => src.WebCategory))
                  .ForMember(c => c.WebSubCategory, opt => opt.MapFrom(src => src.WebSubCategory))
                  .ReverseMap();

            Mapper.CreateMap<PaH.SqlModel.ComboModel.YesNo, PaH.UiModel.ComboModel.YesNo>().ReverseMap();

            #region Changes because of CR01 - Add new 14 columns on RangePlan

            Mapper.CreateMap<PaH.SqlModel.ComboModel.SizeType, PaH.UiModel.ComboModel.SizeType>().ReverseMap();
            #endregion

            Mapper.CreateMap<PaH.SqlModel.EntityModel.RangePlan, PaH.UiModel.EntityModel.RangePlan>()
                .ForMember(c => c.Age, opt => opt.MapFrom(src => src.Age))
                .ForMember(c => c.CatalogueSubCategory, opt => opt.MapFrom(src => src.CatalogueSubCategory))
                .ForMember(c => c.CoreSeasonalRange, opt => opt.MapFrom(src => src.CoreSeasonalRange))
                .ForMember(c => c.GBB, opt => opt.MapFrom(src => src.GBB))
                .ForMember(c => c.Gender, opt => opt.MapFrom(src => src.Gender))
                .ForMember(c => c.MainColour, opt => opt.MapFrom(src => src.MainColour))
                .ForMember(c => c.NewRI, opt => opt.MapFrom(src => src.NewRI))
                .ForMember(c => c.Outlet, opt => opt.MapFrom(src => src.Outlet))
                .ForMember(c => c.ProductCategory, opt => opt.MapFrom(src => src.ProductCategory))
                .ForMember(c => c.RaSubCategory, opt => opt.MapFrom(src => src.RaSubCategory))
                .ForMember(c => c.Supplier, opt => opt.MapFrom(src => src.Supplier))
                .ForMember(c => c.VAT, opt => opt.MapFrom(src => src.VAT))
                .ReverseMap();

            #region changes under CR01

            Mapper.CreateMap<PaH.UiModel.EntityModel.RangePlan, PaH.UiModel.EntityModel.RangePlanIndexView>()
                  .ForMember(c => c.Size1, opt => opt.MapFrom(src => CustomSizeMappingForRangePlan(src, 1, s => s.Size)))
                  .ForMember(c => c.Size1Attribute1,
                             opt => opt.MapFrom(src => CustomSizeMappingForRangePlan(src, 1, s => s.SizeAttribute1)))
                  .ForMember(c => c.Size1Attribute2,
                             opt => opt.MapFrom(src => CustomSizeMappingForRangePlan(src, 1, s => s.SizeAttribute2)))

                  .ForMember(c => c.Size2, opt => opt.MapFrom(src => CustomSizeMappingForRangePlan(src, 2, s => s.Size)))
                  .ForMember(c => c.Size2Attribute1,
                             opt => opt.MapFrom(src => CustomSizeMappingForRangePlan(src, 2, s => s.SizeAttribute1)))
                  .ForMember(c => c.Size2Attribute2,
                             opt => opt.MapFrom(src => CustomSizeMappingForRangePlan(src, 2, s => s.SizeAttribute2)))
                  .ForMember(c => c.Size2Attribute3,
                             opt => opt.MapFrom(src => CustomSizeMappingForRangePlan(src, 2, s => s.SizeAttribute3)))

                  .ForMember(c => c.Size3, opt => opt.MapFrom(src => CustomSizeMappingForRangePlan(src, 3, s => s.Size)))

                  .ForMember(c => c.Size4, opt => opt.MapFrom(src => CustomSizeMappingForRangePlan(src, 4, s => s.Size)))
                  .ForMember(c => c.Size4Attribute1,
                             opt => opt.MapFrom(src => CustomSizeMappingForRangePlan(src, 4, s => s.SizeAttribute1)))
                  .ForMember(c => c.Size4Attribute2,
                             opt => opt.MapFrom(src => CustomSizeMappingForRangePlan(src, 4, s => s.SizeAttribute2)))

                  .ForMember(c => c.Size5, opt => opt.MapFrom(src => CustomSizeMappingForRangePlan(src, 5, s => s.Size)))

                  .ForMember(c => c.Size6, opt => opt.MapFrom(src => CustomSizeMappingForRangePlan(src, 6, s => s.Size)))

                  .ForMember(c => c.Size7, opt => opt.MapFrom(src => CustomSizeMappingForRangePlan(src, 7, s => s.Size)))

                  .ForMember(c => c.Size8, opt => opt.MapFrom(src => CustomSizeMappingForRangePlan(src, 8, s => s.Size)));

            #endregion
        }

        private static string CustomSizeMappingForRangePlan(PaH.UiModel.EntityModel.RangePlan model, int expectedId, Func<PaH.UiModel.EntityModel.RangePlan, string> sourceFunc)
        {
            return model.SizeTypeId==expectedId ? sourceFunc.Invoke(model) : "";
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using AutoMapper;
using Log4NetLibrary;
using PaH.DBL;

namespace PaH.BL.Repository
{
    /// <summary>
    /// Basic Repository is real implementation of IRepository Interface.
    /// used to Perform the EF CRUD operations.
    /// </summary>
    public class BasicRepository : IRepository, IDisposable
    {
        readonly internal PaHContext context = new PaHContext();
        // Set Logger variable
        ILogService logger = new FileLogService(typeof(BasicRepository));
        /// <summary>
        /// from the AutoMapper get the SqlModel type of T,
        /// where T is one UiModel
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        private Type GetSqlModelType<T>()
        {
            logger.EnterMethod("GetSqlModelType");
            var firstOrDefault = Mapper.GetAllTypeMaps().FirstOrDefault(c => c.DestinationType == typeof(T));
            if (firstOrDefault != null)
            {
                Type sqlModel =
                    firstOrDefault.SourceType;
                logger.LeaveMethod("GetSqlModelType");
                return sqlModel;
            }
            logger.LeaveMethod("GetSqlModelType");
            return null;
        }

        /// <summary>
        /// Get the DbSet of UiModel.
        /// first get the SqlModel of UiModel, then DbSet of SqlModel,
        /// then using mapper convert the DbSet of SqlModel to DbSet of UiModel
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        private List<T> GetDbSetOfViewModel<T>()
        {
            logger.EnterMethod("GetDbSetOfViewModel");
            Type sqlModelType = GetSqlModelType<T>();
            if (sqlModelType != null)
            {
                var dbSet = context.Set(sqlModelType);
                logger.LeaveMethod("GetDbSetOfViewModel");
                return Mapper.Map<List<T>>(dbSet);
            }
            logger.LeaveMethod("GetDbSetOfViewModel");
            return null;
        }

        /// <summary>
        /// Convert the SqlModel to UiModel using AutoMapper
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="uiModel"></param>
        /// <returns></returns>
        private object GetSqlModel<T>(T uiModel)
        {
            logger.EnterMethod("GetSqlModel");
            Type sqlModelType = GetSqlModelType<T>();
            if (sqlModelType != null)
            {
                return Mapper.Map(uiModel, typeof(T), sqlModelType);
            }
            return null;
        }

        /// <summary>
        /// Get the DbSet of UiModel
        /// Where IsDeleted is "false"
        /// This method takes the T generic type derived from 
        /// UiModel.BaseClass.BaseEntity
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        private List<T> GetDBSetForViewModel_NotDeleted<T>() where T : PaH.UiModel.BaseClass.BaseEntity
        {
            logger.EnterMethod("GetDBSetForViewModel_NotDeleted");
            // The Where method lives on the Enumerable type in System.Linq
            var whereMethods = typeof(System.Linq.Enumerable)
                .GetMethods(BindingFlags.Static | BindingFlags.Public)
                .Where(mi => mi.Name == "Where");

            // 2 (There are 2 methods that are called Where)
            MethodInfo whereMethod = null;
            foreach (var methodInfo in whereMethods)
            {
                var paramType = methodInfo.GetParameters()[1].ParameterType;
                if (paramType.GetGenericArguments().Count() == 2)
                {
                    // we are looking for  Func<TSource, bool>, the other has 3
                    whereMethod = methodInfo;
                }
            }
            var sqlModelType = GetSqlModelType<T>();
            if (sqlModelType != null && whereMethod != null)
            {
                whereMethod = whereMethod.MakeGenericMethod(sqlModelType);
                var dbSet = context.Set(GetSqlModelType<T>());

                // invoke the Where method from Enumerable which takes the Func<T,bool>
                var ret = whereMethod.Invoke(null,
                                             new object[]
                                                 {
                                                     dbSet,
                                                     new Func<PaH.SqlModel.BaseClass.BaseEntity, bool>(
                                                 c => c.IsDeleted == false)
                                                 });
                logger.LeaveMethod("GetDBSetForViewModel_NotDeleted");
                return Mapper.Map<List<T>>(ret);
            }
            logger.LeaveMethod("GetDBSetForViewModel_NotDeleted");
            return null;
        }

        //BEGIN changed under CR01
        public List<T> GetAllRangePlanIndexView<T>() where T : PaH.UiModel.EntityModel.RangePlanIndexView
        {
            logger.EnterMethod("GetAllRangePlanIndexView");
            var rangePlans = GetAll<PaH.UiModel.EntityModel.RangePlan>();
            var list = Mapper.Map<List<T>>(rangePlans);
            logger.LeaveMethod("GetAllRangePlanIndexView");
            return list;
        }
        //END changed under CR01

        /// <summary>
        /// returns the List of T type.
        /// where T is derived from BaseEntity
        /// used to create the combo for Create Action in Controller
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public List<T> GetComboForNew<T>() where T : PaH.UiModel.BaseClass.BaseEntity
        {
            logger.EnterMethod("GetComboForNew");
            var list = GetAllEnabled<T>();
            logger.LeaveMethod("GetComboForNew");
            return list.ToList();
        }

        /// <summary>
        /// returns the List of T type.
        /// where T is derived from BaseEntity
        /// used to create the combo for Edit Action in Controller
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="id"></param>        
        /// <returns></returns>
        public List<T> GetComboForEdit<T>(int? id) where T : PaH.UiModel.BaseClass.BaseEntity
        {
            logger.EnterMethod("GetComboForEdit");
            var list = GetDbSetOfViewModel<T>();
            if (list != null)
            {
                logger.LeaveMethod("GetComboForEdit");
                return list.Where(c => c.IsEnabled == true || c.Id == (id ?? 0)).ToList();
            }
            logger.LeaveMethod("GetComboForEdit");
            return null;
        }

        /// <summary>
        /// method to return the Combo of WebSubSubCategory
        /// Special about this method is  it returns the text
        /// Cat Name + Sub Cat Name + Sub Sub Name;
        /// For Create Action in Controller
        /// </summary>
        /// <returns></returns>
        public List<Tuple<int, string>> GetSpecialComboOfWebCatNew()
        {
            logger.EnterMethod("GetSpecialComboOfWebCatNew");
            var items = context.WebSubSubCategories.Where(c => c.IsEnabled)
                .Select(c => new { Id = c.Id, Name = c.WebCategory.Name + " - " + c.WebSubCategory.Name + " - " + c.Name })
                .OrderBy(c => c.Name);

            var list = new List<Tuple<int, string>>();
            foreach (var item in items)
            {
                list.Add(new Tuple<int, string>(item.Id, item.Name));
                logger.LogDebugMessage(string.Format("Item.Id: {0}, Item.Name: {1}", item.Id.ToString(), item.Name.ToString()));
            }
            logger.LeaveMethod("GetSpecialComboOfWebCatNew");
            return list.ToList();
        }

        /// <summary>
        /// method to return the Combo of WebSubSubCategory
        /// Special about this method is  it returns the text
        /// Cat Name + Sub Cat Name + Sub Sub Name;
        /// For Edit action in Controller
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public List<Tuple<int, string>> GetSpecialComboOfWebCatEdit(int? id)
        {
            logger.EnterMethod("GetSpecialComboOfWebCatEdit");
            var items = context.WebSubSubCategories.Where(c => c.IsEnabled || c.Id == (id ?? 0))
               .Select(c => new { Id = c.Id, Name = c.WebCategory.Name + " - " + c.WebSubCategory.Name + " - " + c.Name })
               .OrderBy(c => c.Name);

            var list = new List<Tuple<int, string>>();
            foreach (var item in items)
            {
                list.Add(new Tuple<int, string>(item.Id, item.Name));
                logger.LogDebugMessage(string.Format("Item.Id: {0}, Item.Name: {1}", item.Id.ToString(), item.Name.ToString()));
            }
            logger.LeaveMethod("GetSpecialComboOfWebCatEdit");
            return list.ToList();
        }
        /// <summary>
        /// method to return the Combo of RaSubCategory
        /// Special about this method is  it returns the text
        /// Cat Name + Sub Cat Name;
        /// For Create action in Controller
        /// </summary>
        /// <returns></returns>
        public List<Tuple<int, string>> GetSpecialComboOfRaCatNew()
        {
            logger.EnterMethod("GetSpecialComboOfRaCatNew");
            var items = context.RaSubCategories.Where(c => c.IsEnabled)
                .Select(c => new { Id = c.Id, Name = c.RaCategory.Name + " - " + c.Name })
                .OrderBy(c => c.Name);

            var list = new List<Tuple<int, string>>();
            foreach (var item in items)
            {
                list.Add(new Tuple<int, string>(item.Id, item.Name));
                logger.LogDebugMessage(string.Format("Item.Id: {0}, Item.Name: {1}", item.Id.ToString(), item.Name.ToString()));
            }
            logger.LeaveMethod("GetSpecialComboOfRaCatNew");
            return list.ToList();
        }
        /// <summary>
        /// method to return the Combo of RaSubCategory
        /// Special about this method is  it returns the text
        /// Cat Name + Sub Cat Name;
        /// For Edit action in Controller
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public List<Tuple<int, string>> GetSpecialComboOfRaCatEdit(int? id)
        {
            logger.EnterMethod("GetSpecialComboOfRaCatEdit");
            var items = context.RaSubCategories.Where(c => c.IsEnabled || c.Id == (id ?? 0))
               .Select(c => new { Id = c.Id, Name = c.RaCategory.Name + " - " + c.Name })
               .OrderBy(c => c.Name);

            var list = new List<Tuple<int, string>>();
            foreach (var item in items)
            {
                list.Add(new Tuple<int, string>(item.Id, item.Name));
                logger.LogDebugMessage(string.Format("Item.Id: {0}, Item.Name: {1}", item.Id.ToString(), item.Name.ToString()));
            }
            logger.LeaveMethod("GetSpecialComboOfRaCatEdit");
            return list.ToList();
        }
        /// <summary>
        /// method to return the Combo of CategoueCategory
        /// Special about this method is  it returns the text
        /// Catalogue Name + Catalogue Sub Cat Name;
        /// For Create action in Controller
        /// </summary>
        /// <returns></returns>
        public List<Tuple<int, string>> GetSpecialComboOfCatalogueCategoryNew()
        {
            logger.EnterMethod("GetSpecialComboOfCatalogueCategoryNew");
            var items = context.CatalogueSubCategories.Where(c => c.IsEnabled)
               .Select(c => new { Id = c.Id, Name = c.CatalogueCategory.Name + " - " + c.Name })
               .OrderBy(c => c.Name);

            var list = new List<Tuple<int, string>>();
            foreach (var item in items)
            {
                list.Add(new Tuple<int, string>(item.Id, item.Name));
                logger.LogDebugMessage(string.Format("Item.Id: {0}, Item.Name: {1}", item.Id.ToString(), item.Name.ToString()));
            }
            logger.LeaveMethod("GetSpecialComboOfCatalogueCategoryNew");
            return list.ToList();
        }

        /// <summary>
        /// method to return the Combo of CategoueCategory
        /// Special about this method is  it returns the text
        /// Catalogue Name + Catalogue Sub Cat Name;
        /// For Edit action in Controller
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public List<Tuple<int, string>> GetSpecialComboOfCatalogueCategoryEdit(int? id)
        {
            var items = context.CatalogueSubCategories.Where(c => c.IsEnabled || c.Id == (id ?? 0))
               .Select(c => new { Id = c.Id, Name = c.CatalogueCategory.Name + " - " + c.Name })
               .OrderBy(c => c.Name);

            var list = new List<Tuple<int, string>>();
            foreach (var item in items)
            {
                list.Add(new Tuple<int, string>(item.Id, item.Name));
                logger.LogDebugMessage(string.Format("Item.Id: {0}, Item.Name: {1}", item.Id.ToString(), item.Name.ToString()));
            }
            return list.ToList();
        }
        /// <summary>
        /// Method to execute Stored Procedure and other stored SQL Query
        /// returns the records inserted or modified.
        /// </summary>
        /// <param name="query"></param>
        /// <param name="args"></param>
        /// <returns></returns>
        public int ExecuteSqlQuery(string query, ref string errorMessage, params object[] args)
        {
            logger.EnterMethod("ExecuteSqlQuery");
            int result = 0;
            var objectContext = ((IObjectContextAdapter)context).ObjectContext;
            if (objectContext.Connection.State == ConnectionState.Closed)
            {
                objectContext.Connection.Open();
            }
            try
            {
                objectContext.CommandTimeout = 600;
                result = objectContext.ExecuteStoreCommand(query, args);
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
            }
            logger.LogDebugMessage(string.Format("query: {0}", query));
            logger.LeaveMethod("ExecuteSqlQuery");
            return result;
        }

        /// <summary>
        /// Method to Export Report
        /// returns the DataTable filter by the whereClause and ReportType specified.
        /// </summary>
        /// <param name="whereClause"></param>
        /// <param name="reportType"></param>
        /// <returns></returns>
        public DataTable ExportReports(string whereClause, string reportType)
        {
            logger.EnterMethod("ExportReports");
            DataTable result = new DataTable();

            using (var conn = new SqlConnection(context.Database.Connection.ConnectionString))
            {
                logger.LogDebugMessage(string.Format("conn.ConnectionString: {0}", conn.ConnectionString));
                SqlCommand cmd = new SqlCommand("ExportReport");
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("whereClause", SqlDbType.NVarChar)).Value = whereClause.Trim();
                logger.LogDebugMessage(string.Format("whereClause: {0}", whereClause.Trim()));
                cmd.Parameters.Add(new SqlParameter("ReportType", SqlDbType.VarChar, 10)).Value = reportType.Trim();
                logger.LogDebugMessage(string.Format("ReportType: {0}", reportType.ToString()));
                cmd.Connection = conn;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(result);
            }
            logger.LeaveMethod("ExportReports");
            return result;
        }

        /// <summary>
        /// Method to check if IsEnabled is "TRUE" for 
        /// for T type UiModel
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="id"></param>
        /// <returns></returns>
        public bool IsEnabled<T>(int? id) where T : PaH.UiModel.BaseClass.BaseEntity
        {
            logger.EnterMethod("IsEnabled");
            bool result = true;
            result = ((id == null) || (GetDbSetOfViewModel<T>().First(c => c.Id == id).IsEnabled));
            logger.LogDebugMessage(string.Format("result: {0}", result));
            logger.LeaveMethod("IsEnabled");
            return result;
        }

        /// <summary>
        /// Find is to find the T type Ui Model 
        /// by its primary key ID
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="id"></param>
        /// <returns></returns>
        public T Find<T>(int? id) where T : PaH.UiModel.BaseClass.BaseEntity
        {
            logger.EnterMethod("Find");
            T result = null;
            var sqlModelType = GetSqlModelType<T>();
            if (sqlModelType != null)
            {
                var item = context.Set(sqlModelType).Find(id);

                if (item != null)
                {
                    if (((PaH.SqlModel.BaseClass.BaseEntity)item).IsDeleted == false)
                    {
                        result = Mapper.Map<T>(item);
                    }
                }
            }
            logger.LeaveMethod("Find");
            return result;
        }

        /// <summary>
        /// Add method is to add T type Model
        /// into Database and then return the Model back
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="obj"></param>
        /// <returns></returns>
        public T Add<T>(T obj) where T : PaH.UiModel.BaseClass.BaseEntity
        {
            logger.EnterMethod("Add");
            var sqlModel = GetSqlModel(obj);
            var sqlModelType = GetSqlModelType<T>();
            if (sqlModel != null && sqlModelType != null)
            {
                sqlModel = context.Set(sqlModelType).Add(sqlModel);
                context.SaveChanges();
                return Mapper.Map<T>(sqlModel);
            }
            logger.LeaveMethod("Add");
            return obj;
        }

        /// <summary>
        /// this Method returns list of all UiModel 
        /// where IsEnabled property is "True"
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public List<T> GetAllEnabled<T>() where T : PaH.UiModel.BaseClass.BaseEntity
        {
            logger.EnterMethod("GetAllEnabled");
            var result = GetDbSetOfViewModel<T>();
            if (result != null)
            {
                logger.LeaveMethod("GetAllEnabled");
                return result.Where(c => c.IsEnabled).ToList();
            }
            logger.LeaveMethod("GetAllEnabled");
            return new List<T>();
        }

        /// <summary>
        /// this method returns list of T type UiModel
        /// where IsDeleted is false;
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public List<T> GetAll<T>() where T : PaH.UiModel.BaseClass.BaseEntity
        {
            logger.EnterMethod("GetAll");
            var result = GetDBSetForViewModel_NotDeleted<T>();
            if (result != null)
            {
                logger.LeaveMethod("GetAll");
                return result;
            }
            logger.LeaveMethod("GetAll");
            return new List<T>();
        }

        /// <summary>
        /// this method Saves the changes made in T type obj
        /// and returns the True and False;
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="obj"></param>
        /// <returns></returns>
        public bool Save<T>(T obj) where T : PaH.UiModel.BaseClass.BaseEntity
        {
            logger.EnterMethod("Save");
            try
            {
                var sqlModelType = GetSqlModelType<T>();
                var sqlModel = GetSqlModel(obj);

                if (sqlModel != null && sqlModelType != null)
                {
                    // Get the SqlModel using the T type and Id of the UiModel
                    var modelToSave = context.Set(sqlModelType).Find(((PaH.SqlModel.BaseClass.BaseEntity)sqlModel).Id);

                    //Write the changed value from the UiModel to modelToSave
                    context.Entry(modelToSave).CurrentValues.SetValues(sqlModel);

                    #region no need to Modifed the Below fields
                    context.Entry(modelToSave).Property("CreatedBy").IsModified = false;
                    context.Entry(modelToSave).Property("CreatedOn").IsModified = false;
                    context.Entry(modelToSave).Property("UpdatedOn").IsModified = false;
                    context.Entry(modelToSave).Property("UpdatedBy").IsModified = false;
                    //Range Plan not needed fields.
                    var baseType = modelToSave.GetType().BaseType;
                    if (baseType != null && baseType.Name == "RangePlan")
                    {
                        logger.LogDebugMessage(string.Format("baseType.Name: {0}", baseType.Name));
                        context.Entry(modelToSave).Property("WebSubSubCategoryId").IsModified = false;
                        context.Entry(modelToSave).Property("DualWebSubSubCategoryId").IsModified = false;
                        context.Entry(modelToSave).Property("StatusId").IsModified = false;
                        context.Entry(modelToSave).Property("DropDownDefiningAttributeId1").IsModified = false;
                        context.Entry(modelToSave).Property("DefiningAtributeValue1").IsModified = false;
                        context.Entry(modelToSave).Property("DropDownSequence1").IsModified = false;
                        context.Entry(modelToSave).Property("DropDownDefiningAttributeId2").IsModified = false;
                        context.Entry(modelToSave).Property("DefiningAtributeValue2").IsModified = false;
                        context.Entry(modelToSave).Property("DropDownSequence2").IsModified = false;
                        context.Entry(modelToSave).Property("InStoreOnly").IsModified = false;
                        context.Entry(modelToSave).Property("DeliveryOptionId").IsModified = false;
                        context.Entry(modelToSave).Property("Keywords").IsModified = false;
                        context.Entry(modelToSave).Property("ClickandCollectId").IsModified = false;
                        context.Entry(modelToSave).Property("ThresholdQTYforClickAndCollect").IsModified = false;
                        context.Entry(modelToSave).Property("ProductTypeId").IsModified = false;
                        context.Entry(modelToSave).Property("WebCategory1").IsModified = false;
                        context.Entry(modelToSave).Property("WebCategory2").IsModified = false;
                        context.Entry(modelToSave).Property("WebCategory3").IsModified = false;
                        context.Entry(modelToSave).Property("WebCategory4").IsModified = false;
                        context.Entry(modelToSave).Property("WebCategory5").IsModified = false;
                        context.Entry(modelToSave).Property("WebCategory6").IsModified = false;
                        context.Entry(modelToSave).Property("WebCategory7").IsModified = false;
                        context.Entry(modelToSave).Property("WebCategory8").IsModified = false;
                        context.Entry(modelToSave).Property("WebCategory9").IsModified = false;
                        context.Entry(modelToSave).Property("WebCategory10").IsModified = false;
                        context.Entry(modelToSave).Property("ProductWeightKG").IsModified = false;
                        context.Entry(modelToSave).Property("ProductDimensionsCMLxWxH").IsModified = false;
                    }
                    #endregion

                    //If need to check model modifed or not.  currently not in used.
                    DbEntityEntry entityEntry = context.Entry(modelToSave);
                    bool isSame =
                        entityEntry.CurrentValues.PropertyNames.All(
                            propertyName => !entityEntry.Property(propertyName).IsModified);

                    context.Entry(modelToSave).State = EntityState.Modified;
                    context.SaveChanges();
                    logger.LeaveMethod("Save");
                    return true;
                }
                return false;
            }
            catch (Exception exception)
            {
                logger.LogException(exception);
                return false;
            }
        }

        /// <summary>
        /// Set the IsDeleted = TRUE 
        /// of T type Ui Model and for Id passed in.
        /// returns TRUE/FALSE
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="id"></param>
        /// <returns></returns>
        public bool Delete<T>(int? id) where T : PaH.UiModel.BaseClass.BaseEntity
        {
            logger.EnterMethod("Delete");
            bool blnDelete = false;
            var sqlModelType = GetSqlModelType<T>();
            if (sqlModelType != null)
            {
                var sqlModel = (PaH.SqlModel.BaseClass.BaseEntity)context.Set(sqlModelType).Find(id);
                if (typeof(T).Name.IndexOf("RangePlan") > -1)
                {
                    context.Entry(sqlModel).State = EntityState.Deleted;
                }
                else
                {
                    sqlModel = sqlModel.IsDeleted ? null : sqlModel;
                    if (sqlModel == null)
                    {
                        blnDelete = false;
                    }
                    sqlModel.IsDeleted = true;
                    sqlModel.IsEnabled = false;
                    context.Entry(sqlModel).State = EntityState.Modified;
                }
                context.SaveChanges();
                blnDelete = true;
            }
            logger.LogDebugMessage(string.Format("{0}", blnDelete));
            logger.LeaveMethod("Delete");
            return blnDelete;
        }

        /// <summary>
        /// method to check the RaProductCode is Unique or not before sumitted the 
        /// RangePlan to Save
        /// </summary>
        /// <param name="raProductCode"></param>
        /// <returns></returns>
        public bool IsRaProductCodeUnique(string raProductCode)
        {
            bool result = false;

            result = !context.RangePlans.Any(c => c.RAProductCodeNew.Trim() == raProductCode.Trim());

            return result;
        }

        /// <summary>
        ///  dispose to make it sure resource and disposed properly
        /// </summary>
        public void Dispose()
        {
            logger.EnterMethod("Dispose");
            context.Dispose();
            GC.SuppressFinalize(this);
            logger.LeaveMethod("Dispose");
        }
    }
}
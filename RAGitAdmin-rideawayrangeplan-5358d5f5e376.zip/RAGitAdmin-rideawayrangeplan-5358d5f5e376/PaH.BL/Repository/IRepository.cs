﻿using System;
using System.Collections.Generic;
using System.Data;

namespace PaH.BL.Repository
{
    /// <summary>
    /// Interface to implment BasicRepository
    /// </summary>
    public interface IRepository
    {
        List<T> GetComboForNew<T>() where T : PaH.UiModel.BaseClass.BaseEntity;
        List<T> GetComboForEdit<T>(int? id) where T : PaH.UiModel.BaseClass.BaseEntity;
        List<Tuple<int, string>> GetSpecialComboOfWebCatNew();
        List<Tuple<int, string>> GetSpecialComboOfWebCatEdit(int? id);
        List<Tuple<int, string>> GetSpecialComboOfRaCatNew();
        List<Tuple<int, string>> GetSpecialComboOfRaCatEdit(int? id);
        List<Tuple<int, string>> GetSpecialComboOfCatalogueCategoryNew();
        List<Tuple<int, string>> GetSpecialComboOfCatalogueCategoryEdit(int? id);
        int ExecuteSqlQuery(string query, ref string errorMessage, params object[] args);
        DataTable ExportReports(string whereClause, string reportType);
        bool IsEnabled<T>(int? id) where T : PaH.UiModel.BaseClass.BaseEntity;
        T Find<T>(int? id) where T : PaH.UiModel.BaseClass.BaseEntity;
        T Add<T>(T obj) where T : PaH.UiModel.BaseClass.BaseEntity;
        List<T> GetAllEnabled<T>() where T : PaH.UiModel.BaseClass.BaseEntity;
        List<T> GetAll<T>() where T : PaH.UiModel.BaseClass.BaseEntity;
        bool Save<T>(T obj) where T : PaH.UiModel.BaseClass.BaseEntity;
        bool Delete<T>(int? id) where T : PaH.UiModel.BaseClass.BaseEntity;
        bool IsRaProductCodeUnique(string RaProductCode);
        void Dispose();
        //BEGIN changed under CR01
        List<T> GetAllRangePlanIndexView<T>() where T : PaH.UiModel.EntityModel.RangePlanIndexView;
        //END changed under CR01
    }
}

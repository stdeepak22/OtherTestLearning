namespace PaH.DBL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Age",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Value = c.String(nullable: false, maxLength: 256),
                        Description = c.String(maxLength: 1024),
                        IsEnabled = c.Boolean(nullable: false),
                        IsDeleted = c.Boolean(nullable: false),
                        CreatedOn = c.DateTime(),
                        CreatedBy = c.String(),
                        UpdatedOn = c.DateTime(),
                        UpdatedBy = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.CatalogueCategory",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(nullable: false, maxLength: 256),
                        Description = c.String(maxLength: 1024),
                        IsEnabled = c.Boolean(nullable: false),
                        IsDeleted = c.Boolean(nullable: false),
                        CreatedOn = c.DateTime(),
                        CreatedBy = c.String(),
                        UpdatedOn = c.DateTime(),
                        UpdatedBy = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.CatalogueSubCategory",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(nullable: false, maxLength: 256),
                        CatalogueCategoryId = c.Int(nullable: false),
                        Description = c.String(maxLength: 1024),
                        IsEnabled = c.Boolean(nullable: false),
                        IsDeleted = c.Boolean(nullable: false),
                        CreatedOn = c.DateTime(),
                        CreatedBy = c.String(),
                        UpdatedOn = c.DateTime(),
                        UpdatedBy = c.String(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.CatalogueCategory", t => t.CatalogueCategoryId)
                .Index(t => t.CatalogueCategoryId);
            
            CreateTable(
                "dbo.CoreSeasonalRange",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(nullable: false, maxLength: 256),
                        Description = c.String(maxLength: 1024),
                        IsEnabled = c.Boolean(nullable: false),
                        IsDeleted = c.Boolean(nullable: false),
                        CreatedOn = c.DateTime(),
                        CreatedBy = c.String(),
                        UpdatedOn = c.DateTime(),
                        UpdatedBy = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.DeliveryOption",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Option = c.String(nullable: false, maxLength: 1024),
                        Description = c.String(maxLength: 1024),
                        IsEnabled = c.Boolean(nullable: false),
                        IsDeleted = c.Boolean(nullable: false),
                        CreatedOn = c.DateTime(),
                        CreatedBy = c.String(),
                        UpdatedOn = c.DateTime(),
                        UpdatedBy = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.DropDownDefiningAttribute",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        AttributeName = c.String(nullable: false, maxLength: 256),
                        Description = c.String(maxLength: 1024),
                        IsEnabled = c.Boolean(nullable: false),
                        IsDeleted = c.Boolean(nullable: false),
                        CreatedOn = c.DateTime(),
                        CreatedBy = c.String(),
                        UpdatedOn = c.DateTime(),
                        UpdatedBy = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.FoodNonFood",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Type = c.String(nullable: false, maxLength: 256),
                        Description = c.String(maxLength: 1024),
                        IsEnabled = c.Boolean(nullable: false),
                        IsDeleted = c.Boolean(nullable: false),
                        CreatedOn = c.DateTime(),
                        CreatedBy = c.String(),
                        UpdatedOn = c.DateTime(),
                        UpdatedBy = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.GBB",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Value = c.String(nullable: false, maxLength: 256),
                        Description = c.String(maxLength: 1024),
                        IsEnabled = c.Boolean(nullable: false),
                        IsDeleted = c.Boolean(nullable: false),
                        CreatedOn = c.DateTime(),
                        CreatedBy = c.String(),
                        UpdatedOn = c.DateTime(),
                        UpdatedBy = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.Gender",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Title = c.String(nullable: false, maxLength: 256),
                        Description = c.String(maxLength: 1024),
                        IsEnabled = c.Boolean(nullable: false),
                        IsDeleted = c.Boolean(nullable: false),
                        CreatedOn = c.DateTime(),
                        CreatedBy = c.String(),
                        UpdatedOn = c.DateTime(),
                        UpdatedBy = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.Log",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        DateTime = c.DateTime(nullable: false),
                        Thread = c.String(maxLength: 255),
                        Level = c.String(nullable: false, maxLength: 50),
                        Logger = c.String(nullable: false, maxLength: 255),
                        Host = c.String(nullable: false, maxLength: 50),
                        Message = c.String(nullable: false, maxLength: 4000),
                        Exception = c.String(maxLength: 2000),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.MainColour",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Colour = c.String(nullable: false, maxLength: 256),
                        Description = c.String(maxLength: 1024),
                        IsEnabled = c.Boolean(nullable: false),
                        IsDeleted = c.Boolean(nullable: false),
                        CreatedOn = c.DateTime(),
                        CreatedBy = c.String(),
                        UpdatedOn = c.DateTime(),
                        UpdatedBy = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.NewRI",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(nullable: false, maxLength: 256),
                        Description = c.String(maxLength: 1024),
                        IsEnabled = c.Boolean(nullable: false),
                        IsDeleted = c.Boolean(nullable: false),
                        CreatedOn = c.DateTime(),
                        CreatedBy = c.String(),
                        UpdatedOn = c.DateTime(),
                        UpdatedBy = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.Outlet",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Type = c.String(nullable: false, maxLength: 256),
                        Description = c.String(maxLength: 1024),
                        IsEnabled = c.Boolean(nullable: false),
                        IsDeleted = c.Boolean(nullable: false),
                        CreatedOn = c.DateTime(),
                        CreatedBy = c.String(),
                        UpdatedOn = c.DateTime(),
                        UpdatedBy = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.PackSize",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(nullable: false, maxLength: 256),
                        Quantity = c.Int(nullable: false),
                        Description = c.String(maxLength: 1024),
                        IsEnabled = c.Boolean(nullable: false),
                        IsDeleted = c.Boolean(nullable: false),
                        CreatedOn = c.DateTime(),
                        CreatedBy = c.String(),
                        UpdatedOn = c.DateTime(),
                        UpdatedBy = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.ProductCategory",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(nullable: false, maxLength: 256),
                        Code = c.String(nullable: false, maxLength: 256),
                        Description = c.String(maxLength: 1024),
                        IsEnabled = c.Boolean(nullable: false),
                        IsDeleted = c.Boolean(nullable: false),
                        CreatedOn = c.DateTime(),
                        CreatedBy = c.String(),
                        UpdatedOn = c.DateTime(),
                        UpdatedBy = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.RaCategory",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(nullable: false, maxLength: 256),
                        Description = c.String(maxLength: 1024),
                        IsEnabled = c.Boolean(nullable: false),
                        IsDeleted = c.Boolean(nullable: false),
                        CreatedOn = c.DateTime(),
                        CreatedBy = c.String(),
                        UpdatedOn = c.DateTime(),
                        UpdatedBy = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.RaSubCategory",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        AnalysisCode = c.String(nullable: false, maxLength: 256),
                        Name = c.String(nullable: false, maxLength: 256),
                        FirstPartShufti = c.String(maxLength: 256),
                        RaCategoryId = c.Int(nullable: false),
                        Description = c.String(maxLength: 1024),
                        IsEnabled = c.Boolean(nullable: false),
                        IsDeleted = c.Boolean(nullable: false),
                        CreatedOn = c.DateTime(),
                        CreatedBy = c.String(),
                        UpdatedOn = c.DateTime(),
                        UpdatedBy = c.String(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.RaCategory", t => t.RaCategoryId)
                .Index(t => t.RaCategoryId);
            
            CreateTable(
                "dbo.RangePlan",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Season = c.String(nullable: false, maxLength: 256),
                        SuppId = c.Int(nullable: false),
                        SupplierProductCode = c.String(maxLength: 256),
                        NewRIId = c.Int(),
                        FirstPartShufti = c.String(),
                        SecondPartShufti = c.String(maxLength: 256),
                        RAProductCodeNew = c.String(nullable: false, maxLength: 256),
                        RaSubSubCategory = c.String(maxLength: 256),
                        RaSubCategoryId = c.Int(),
                        RaCategory = c.String(),
                        GenderId = c.Int(),
                        AgeId = c.Int(),
                        Brand = c.String(maxLength: 256),
                        Description = c.String(maxLength: 256),
                        MainColourId = c.Int(),
                        ActualColour = c.String(maxLength: 256),
                        SizeTypeId = c.Int(),
                        Size = c.String(maxLength: 256),
                        SizeAttribute1 = c.String(maxLength: 256),
                        SizeAttribute2 = c.String(maxLength: 256),
                        SizeAttribute3 = c.String(maxLength: 256),
                        Personalised = c.String(),
                        MaterialComposition = c.String(maxLength: 1024),
                        TradeCost = c.Decimal(precision: 18, scale: 2),
                        RRP = c.Decimal(precision: 18, scale: 2),
                        SupplierStandardDiscount = c.Decimal(precision: 18, scale: 2),
                        SupplierForwardOrderDiscount = c.Decimal(precision: 18, scale: 2),
                        SRPLessVAT = c.Decimal(precision: 18, scale: 2),
                        CostLessSTDSupplierDiscount = c.Decimal(precision: 18, scale: 2),
                        CostLessFWDSupplierDiscount = c.Decimal(precision: 18, scale: 2),
                        MarginPound = c.Decimal(precision: 18, scale: 2),
                        MarginPercentage = c.Decimal(precision: 18, scale: 2),
                        RideAwayRetail = c.Decimal(precision: 18, scale: 2),
                        OldCostLessSTDDiscount = c.Decimal(precision: 18, scale: 2),
                        OldRideawayRetail = c.Decimal(precision: 18, scale: 2),
                        VATId = c.Int(),
                        RideAwayRetailLessVAT = c.Decimal(precision: 18, scale: 2),
                        RideAwayMarginPound = c.Decimal(precision: 18, scale: 2),
                        RideAwayMarginPercentSTDcost = c.Decimal(precision: 18, scale: 2),
                        RideAwayMarginPercentFWDcost = c.Decimal(precision: 18, scale: 2),
                        PackSizeId = c.Int(),
                        StockedDD = c.String(maxLength: 256),
                        CoreSeasonalRangeId = c.Int(),
                        ExclusiveToRAId = c.Int(),
                        OutletId = c.Int(),
                        WebSubSubCategoryId = c.Int(),
                        DualWebSubSubCategoryId = c.Int(),
                        SalesExVAT = c.Decimal(precision: 18, scale: 2),
                        SalesUnits = c.Decimal(precision: 18, scale: 2),
                        SalesPoundMargin = c.Decimal(precision: 18, scale: 2),
                        SalesForecastExVAT = c.Decimal(precision: 18, scale: 2),
                        SalesForecastUnits = c.Decimal(precision: 18, scale: 2),
                        SalesForecastPoundMargin = c.Decimal(precision: 18, scale: 2),
                        EstimateValExVATAve = c.Decimal(precision: 18, scale: 2),
                        EstimateQty = c.Decimal(precision: 18, scale: 2),
                        RoundedEstimateQTY = c.Decimal(precision: 18, scale: 2),
                        RetailEstimateSTDCost = c.Int(),
                        RetailEstimateFWDCost = c.Int(),
                        RetailEstimateExVAT = c.Decimal(precision: 18, scale: 2),
                        RetailEstimateIncVAT = c.Decimal(precision: 18, scale: 2),
                        CurrentStock = c.Int(),
                        CurrentSeasonEstimate = c.Decimal(precision: 18, scale: 2),
                        CurrentSeasonClosingStock = c.Decimal(precision: 18, scale: 2),
                        CurrentSeasonClosingStockRounded = c.Decimal(precision: 18, scale: 2),
                        ForwardOrderQty = c.Int(),
                        ForwardOrderCPStdDisc = c.Int(),
                        ForwardOrderCPFwdDisc = c.Int(),
                        ForwardOrderRetailExVAT = c.Decimal(precision: 18, scale: 2),
                        ForwardOrderRetailINCVAT = c.Decimal(precision: 18, scale: 2),
                        FirstDROP = c.Int(),
                        SecondDROP = c.Int(),
                        ThirdDROP = c.Int(),
                        FourthDROP = c.Int(),
                        FifthDROP = c.Int(),
                        SixthDROP = c.Int(),
                        SplitCheck = c.String(),
                        Comments = c.String(maxLength: 1024),
                        CatalogueCategory = c.String(),
                        SubCatalogueCategoryId = c.Int(),
                        GBBId = c.Int(),
                        HeroProductId = c.Int(),
                        ProductText = c.String(maxLength: 1024),
                        AnalysisCode = c.String(maxLength: 256),
                        AnalysisCodeDescription = c.String(),
                        SupplierCode = c.String(),
                        ProdCategoryId = c.Int(),
                        FreeCode7Id = c.Int(),
                        VATCode = c.String(),
                        ProductCategoryCode = c.String(),
                        PrimaryPickWarehouse = c.String(),
                        PrimaryPickLocation = c.String(),
                        BuyingPackQTY = c.String(),
                        M4BuyingPackCost = c.Decimal(precision: 18, scale: 2),
                        ProductLeadtime = c.Decimal(precision: 18, scale: 2),
                        ReOrderLevel = c.Int(),
                        ReOrderQuantity = c.Int(),
                        ShopReOrderLevel = c.Int(),
                        ShopReOrderQuantity = c.Int(),
                        StatusId = c.Int(),
                        DropDownDefiningAttributeId1 = c.Int(),
                        DefiningAtributeValue1 = c.String(),
                        DropDownSequence1 = c.String(),
                        DropDownDefiningAttributeId2 = c.Int(),
                        DefiningAtributeValue2 = c.String(),
                        DropDownSequence2 = c.String(),
                        InStoreOnly = c.String(),
                        DeliveryOptionId = c.Int(),
                        Keywords = c.String(),
                        ClickandCollectId = c.Int(),
                        ThresholdQTYforClickAndCollect = c.Decimal(precision: 18, scale: 2),
                        ProductTypeId = c.Int(),
                        WebCategory1 = c.String(),
                        WebCategory2 = c.String(),
                        WebCategory3 = c.String(),
                        WebCategory4 = c.String(),
                        WebCategory5 = c.String(),
                        WebCategory6 = c.String(),
                        WebCategory7 = c.String(),
                        WebCategory8 = c.String(),
                        WebCategory9 = c.String(),
                        WebCategory10 = c.String(),
                        ProductWeightKG = c.Decimal(precision: 18, scale: 2),
                        ProductDimensionsCMLxWxH = c.Decimal(precision: 18, scale: 2),
                        IsEnabled = c.Boolean(nullable: false),
                        IsDeleted = c.Boolean(nullable: false),
                        CreatedOn = c.DateTime(),
                        CreatedBy = c.String(),
                        UpdatedOn = c.DateTime(),
                        UpdatedBy = c.String(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Age", t => t.AgeId)
                .ForeignKey("dbo.PackSize", t => t.PackSizeId)
                .ForeignKey("dbo.CatalogueSubCategory", t => t.SubCatalogueCategoryId)
                .ForeignKey("dbo.YesNo", t => t.ClickandCollectId)
                .ForeignKey("dbo.CoreSeasonalRange", t => t.CoreSeasonalRangeId)
                .ForeignKey("dbo.DeliveryOption", t => t.DeliveryOptionId)
                .ForeignKey("dbo.DropDownDefiningAttribute", t => t.DropDownDefiningAttributeId1)
                .ForeignKey("dbo.DropDownDefiningAttribute", t => t.DropDownDefiningAttributeId2)
                .ForeignKey("dbo.WebSubSubCategory", t => t.DualWebSubSubCategoryId)
                .ForeignKey("dbo.YesNo", t => t.ExclusiveToRAId)
                .ForeignKey("dbo.FoodNonFood", t => t.ProductTypeId)
                .ForeignKey("dbo.YesNo", t => t.FreeCode7Id)
                .ForeignKey("dbo.GBB", t => t.GBBId)
                .ForeignKey("dbo.Gender", t => t.GenderId)
                .ForeignKey("dbo.YesNo", t => t.HeroProductId)
                .ForeignKey("dbo.MainColour", t => t.MainColourId)
                .ForeignKey("dbo.NewRI", t => t.NewRIId)
                .ForeignKey("dbo.Outlet", t => t.OutletId)
                .ForeignKey("dbo.ProductCategory", t => t.ProdCategoryId)
                .ForeignKey("dbo.RaSubCategory", t => t.RaSubCategoryId)
                .ForeignKey("dbo.SizeType", t => t.SizeTypeId)
                .ForeignKey("dbo.Status", t => t.StatusId)
                .ForeignKey("dbo.Supplier", t => t.SuppId)
                .ForeignKey("dbo.VAT", t => t.VATId)
                .ForeignKey("dbo.WebSubSubCategory", t => t.WebSubSubCategoryId)
                .Index(t => t.SuppId)
                .Index(t => t.NewRIId)
                .Index(t => t.RAProductCodeNew, unique: true, name: "IX_RaProductCodeIndexing")
                .Index(t => t.RaSubCategoryId)
                .Index(t => t.GenderId)
                .Index(t => t.AgeId)
                .Index(t => t.MainColourId)
                .Index(t => t.SizeTypeId)
                .Index(t => t.VATId)
                .Index(t => t.PackSizeId)
                .Index(t => t.CoreSeasonalRangeId)
                .Index(t => t.ExclusiveToRAId)
                .Index(t => t.OutletId)
                .Index(t => t.WebSubSubCategoryId)
                .Index(t => t.DualWebSubSubCategoryId)
                .Index(t => t.SubCatalogueCategoryId)
                .Index(t => t.GBBId)
                .Index(t => t.HeroProductId)
                .Index(t => t.ProdCategoryId)
                .Index(t => t.FreeCode7Id)
                .Index(t => t.StatusId)
                .Index(t => t.DropDownDefiningAttributeId1)
                .Index(t => t.DropDownDefiningAttributeId2)
                .Index(t => t.DeliveryOptionId)
                .Index(t => t.ClickandCollectId)
                .Index(t => t.ProductTypeId);
            
            CreateTable(
                "dbo.YesNo",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Value = c.String(nullable: false, maxLength: 256),
                        Description = c.String(maxLength: 1024),
                        IsEnabled = c.Boolean(nullable: false),
                        IsDeleted = c.Boolean(nullable: false),
                        CreatedOn = c.DateTime(),
                        CreatedBy = c.String(),
                        UpdatedOn = c.DateTime(),
                        UpdatedBy = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.WebSubSubCategory",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(nullable: false, maxLength: 256),
                        WebSubCategoryId = c.Int(nullable: false),
                        WebCategoryId = c.Int(nullable: false),
                        Description = c.String(maxLength: 1024),
                        IsEnabled = c.Boolean(nullable: false),
                        IsDeleted = c.Boolean(nullable: false),
                        CreatedOn = c.DateTime(),
                        CreatedBy = c.String(),
                        UpdatedOn = c.DateTime(),
                        UpdatedBy = c.String(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.WebSubCategory", t => t.WebSubCategoryId)
                .ForeignKey("dbo.WebCategory", t => t.WebCategoryId)
                .Index(t => t.WebSubCategoryId)
                .Index(t => t.WebCategoryId);
            
            CreateTable(
                "dbo.WebCategory",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(nullable: false, maxLength: 256),
                        Description = c.String(maxLength: 1024),
                        IsEnabled = c.Boolean(nullable: false),
                        IsDeleted = c.Boolean(nullable: false),
                        CreatedOn = c.DateTime(),
                        CreatedBy = c.String(),
                        UpdatedOn = c.DateTime(),
                        UpdatedBy = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.WebSubCategory",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(nullable: false, maxLength: 256),
                        WebCategoryId = c.Int(nullable: false),
                        Description = c.String(maxLength: 1024),
                        IsEnabled = c.Boolean(nullable: false),
                        IsDeleted = c.Boolean(nullable: false),
                        CreatedOn = c.DateTime(),
                        CreatedBy = c.String(),
                        UpdatedOn = c.DateTime(),
                        UpdatedBy = c.String(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.WebCategory", t => t.WebCategoryId)
                .Index(t => t.WebCategoryId);
            
            CreateTable(
                "dbo.SizeType",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Value = c.String(nullable: false, maxLength: 256),
                        Description = c.String(maxLength: 1024),
                        IsEnabled = c.Boolean(nullable: false),
                        IsDeleted = c.Boolean(nullable: false),
                        CreatedOn = c.DateTime(),
                        CreatedBy = c.String(),
                        UpdatedOn = c.DateTime(),
                        UpdatedBy = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.Status",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(nullable: false, maxLength: 256),
                        Description = c.String(maxLength: 1024),
                        IsEnabled = c.Boolean(nullable: false),
                        IsDeleted = c.Boolean(nullable: false),
                        CreatedOn = c.DateTime(),
                        CreatedBy = c.String(),
                        UpdatedOn = c.DateTime(),
                        UpdatedBy = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.Supplier",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(nullable: false, maxLength: 256),
                        Code = c.String(nullable: false, maxLength: 256),
                        Description = c.String(maxLength: 1024),
                        IsEnabled = c.Boolean(nullable: false),
                        IsDeleted = c.Boolean(nullable: false),
                        CreatedOn = c.DateTime(),
                        CreatedBy = c.String(),
                        UpdatedOn = c.DateTime(),
                        UpdatedBy = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.VAT",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Value = c.String(nullable: false, maxLength: 256),
                        Description = c.String(maxLength: 1024),
                        IsEnabled = c.Boolean(nullable: false),
                        IsDeleted = c.Boolean(nullable: false),
                        CreatedOn = c.DateTime(),
                        CreatedBy = c.String(),
                        UpdatedOn = c.DateTime(),
                        UpdatedBy = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.RaSubSubCategory",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(nullable: false, maxLength: 256),
                        RaSubCategoryId = c.Int(nullable: false),
                        RaCategoryId = c.Int(nullable: false),
                        Description = c.String(maxLength: 1024),
                        IsEnabled = c.Boolean(nullable: false),
                        IsDeleted = c.Boolean(nullable: false),
                        CreatedOn = c.DateTime(),
                        CreatedBy = c.String(),
                        UpdatedOn = c.DateTime(),
                        UpdatedBy = c.String(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.RaCategory", t => t.RaCategoryId)
                .ForeignKey("dbo.RaSubCategory", t => t.RaSubCategoryId)
                .Index(t => t.RaSubCategoryId)
                .Index(t => t.RaCategoryId);
            
            CreateTable(
                "dbo.Shot",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(nullable: false, maxLength: 256),
                        Description = c.String(maxLength: 1024),
                        IsEnabled = c.Boolean(nullable: false),
                        IsDeleted = c.Boolean(nullable: false),
                        CreatedOn = c.DateTime(),
                        CreatedBy = c.String(),
                        UpdatedOn = c.DateTime(),
                        UpdatedBy = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.RaSubSubCategory", "RaSubCategoryId", "dbo.RaSubCategory");
            DropForeignKey("dbo.RaSubSubCategory", "RaCategoryId", "dbo.RaCategory");
            DropForeignKey("dbo.RangePlan", "WebSubSubCategoryId", "dbo.WebSubSubCategory");
            DropForeignKey("dbo.RangePlan", "VATId", "dbo.VAT");
            DropForeignKey("dbo.RangePlan", "SuppId", "dbo.Supplier");
            DropForeignKey("dbo.RangePlan", "StatusId", "dbo.Status");
            DropForeignKey("dbo.RangePlan", "SizeTypeId", "dbo.SizeType");
            DropForeignKey("dbo.RangePlan", "RaSubCategoryId", "dbo.RaSubCategory");
            DropForeignKey("dbo.RangePlan", "ProdCategoryId", "dbo.ProductCategory");
            DropForeignKey("dbo.RangePlan", "OutletId", "dbo.Outlet");
            DropForeignKey("dbo.RangePlan", "NewRIId", "dbo.NewRI");
            DropForeignKey("dbo.RangePlan", "MainColourId", "dbo.MainColour");
            DropForeignKey("dbo.RangePlan", "HeroProductId", "dbo.YesNo");
            DropForeignKey("dbo.RangePlan", "GenderId", "dbo.Gender");
            DropForeignKey("dbo.RangePlan", "GBBId", "dbo.GBB");
            DropForeignKey("dbo.RangePlan", "FreeCode7Id", "dbo.YesNo");
            DropForeignKey("dbo.RangePlan", "ProductTypeId", "dbo.FoodNonFood");
            DropForeignKey("dbo.RangePlan", "ExclusiveToRAId", "dbo.YesNo");
            DropForeignKey("dbo.RangePlan", "DualWebSubSubCategoryId", "dbo.WebSubSubCategory");
            DropForeignKey("dbo.WebSubSubCategory", "WebCategoryId", "dbo.WebCategory");
            DropForeignKey("dbo.WebSubSubCategory", "WebSubCategoryId", "dbo.WebSubCategory");
            DropForeignKey("dbo.WebSubCategory", "WebCategoryId", "dbo.WebCategory");
            DropForeignKey("dbo.RangePlan", "DropDownDefiningAttributeId2", "dbo.DropDownDefiningAttribute");
            DropForeignKey("dbo.RangePlan", "DropDownDefiningAttributeId1", "dbo.DropDownDefiningAttribute");
            DropForeignKey("dbo.RangePlan", "DeliveryOptionId", "dbo.DeliveryOption");
            DropForeignKey("dbo.RangePlan", "CoreSeasonalRangeId", "dbo.CoreSeasonalRange");
            DropForeignKey("dbo.RangePlan", "ClickandCollectId", "dbo.YesNo");
            DropForeignKey("dbo.RangePlan", "SubCatalogueCategoryId", "dbo.CatalogueSubCategory");
            DropForeignKey("dbo.RangePlan", "PackSizeId", "dbo.PackSize");
            DropForeignKey("dbo.RangePlan", "AgeId", "dbo.Age");
            DropForeignKey("dbo.RaSubCategory", "RaCategoryId", "dbo.RaCategory");
            DropForeignKey("dbo.CatalogueSubCategory", "CatalogueCategoryId", "dbo.CatalogueCategory");
            DropIndex("dbo.RaSubSubCategory", new[] { "RaCategoryId" });
            DropIndex("dbo.RaSubSubCategory", new[] { "RaSubCategoryId" });
            DropIndex("dbo.WebSubCategory", new[] { "WebCategoryId" });
            DropIndex("dbo.WebSubSubCategory", new[] { "WebCategoryId" });
            DropIndex("dbo.WebSubSubCategory", new[] { "WebSubCategoryId" });
            DropIndex("dbo.RangePlan", new[] { "ProductTypeId" });
            DropIndex("dbo.RangePlan", new[] { "ClickandCollectId" });
            DropIndex("dbo.RangePlan", new[] { "DeliveryOptionId" });
            DropIndex("dbo.RangePlan", new[] { "DropDownDefiningAttributeId2" });
            DropIndex("dbo.RangePlan", new[] { "DropDownDefiningAttributeId1" });
            DropIndex("dbo.RangePlan", new[] { "StatusId" });
            DropIndex("dbo.RangePlan", new[] { "FreeCode7Id" });
            DropIndex("dbo.RangePlan", new[] { "ProdCategoryId" });
            DropIndex("dbo.RangePlan", new[] { "HeroProductId" });
            DropIndex("dbo.RangePlan", new[] { "GBBId" });
            DropIndex("dbo.RangePlan", new[] { "SubCatalogueCategoryId" });
            DropIndex("dbo.RangePlan", new[] { "DualWebSubSubCategoryId" });
            DropIndex("dbo.RangePlan", new[] { "WebSubSubCategoryId" });
            DropIndex("dbo.RangePlan", new[] { "OutletId" });
            DropIndex("dbo.RangePlan", new[] { "ExclusiveToRAId" });
            DropIndex("dbo.RangePlan", new[] { "CoreSeasonalRangeId" });
            DropIndex("dbo.RangePlan", new[] { "PackSizeId" });
            DropIndex("dbo.RangePlan", new[] { "VATId" });
            DropIndex("dbo.RangePlan", new[] { "SizeTypeId" });
            DropIndex("dbo.RangePlan", new[] { "MainColourId" });
            DropIndex("dbo.RangePlan", new[] { "AgeId" });
            DropIndex("dbo.RangePlan", new[] { "GenderId" });
            DropIndex("dbo.RangePlan", new[] { "RaSubCategoryId" });
            DropIndex("dbo.RangePlan", "IX_RaProductCodeIndexing");
            DropIndex("dbo.RangePlan", new[] { "NewRIId" });
            DropIndex("dbo.RangePlan", new[] { "SuppId" });
            DropIndex("dbo.RaSubCategory", new[] { "RaCategoryId" });
            DropIndex("dbo.CatalogueSubCategory", new[] { "CatalogueCategoryId" });
            DropTable("dbo.Shot");
            DropTable("dbo.RaSubSubCategory");
            DropTable("dbo.VAT");
            DropTable("dbo.Supplier");
            DropTable("dbo.Status");
            DropTable("dbo.SizeType");
            DropTable("dbo.WebSubCategory");
            DropTable("dbo.WebCategory");
            DropTable("dbo.WebSubSubCategory");
            DropTable("dbo.YesNo");
            DropTable("dbo.RangePlan");
            DropTable("dbo.RaSubCategory");
            DropTable("dbo.RaCategory");
            DropTable("dbo.ProductCategory");
            DropTable("dbo.PackSize");
            DropTable("dbo.Outlet");
            DropTable("dbo.NewRI");
            DropTable("dbo.MainColour");
            DropTable("dbo.Log");
            DropTable("dbo.Gender");
            DropTable("dbo.GBB");
            DropTable("dbo.FoodNonFood");
            DropTable("dbo.DropDownDefiningAttribute");
            DropTable("dbo.DeliveryOption");
            DropTable("dbo.CoreSeasonalRange");
            DropTable("dbo.CatalogueSubCategory");
            DropTable("dbo.CatalogueCategory");
            DropTable("dbo.Age");
        }
    }
}

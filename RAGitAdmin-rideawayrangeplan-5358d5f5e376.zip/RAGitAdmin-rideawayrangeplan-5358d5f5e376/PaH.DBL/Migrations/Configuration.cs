﻿using System.Configuration;
using System.Data.Entity;
using System.Data.Entity.Migrations;
using System.Linq;
using Log4NetLibrary;
using PaH.SqlModel.ComboModel;

namespace PaH.DBL.Migrations
{
    public sealed class Configuration : DbMigrationsConfiguration<PaHContext>
    {
        // Set Logger variable
        ILogService logger = new FileLogService(typeof(Configuration));
       
        
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
            string value = ConfigurationManager.AppSettings["AllowDataLoss"]??"false";
            bool dataLoss = false;
            if (bool.TryParse(value, out dataLoss))
            {
                AutomaticMigrationDataLossAllowed = dataLoss;
            }

            DbMigrator migrator = new DbMigrator(this);
            if (migrator.GetPendingMigrations().Any())
            {
                migrator.Update();
            }

        }

        protected override void Seed(PaHContext context)
        {                          
            logger.EnterMethod("Seed");

            #region Drop First if Exists
            #region Export Views and Stored Procedure

            #region Views
            logger.LogDebugMessage("Drop Export Views Export_Report_Hanger7");
            context.Database.SqlQuery<object>(SeedingObjects.View_Export_Report_Hanger7_Drop).FirstOrDefault();            

            logger.LogDebugMessage("Drop Export Views Export_Report_Create");
            context.Database.SqlQuery<object>(SeedingObjects.View_Export_Report_Create_Drop).FirstOrDefault();            

            logger.LogDebugMessage("Drop Export Views Export_Report_RangePlan");
            context.Database.SqlQuery<object>(SeedingObjects.View_Export_Report_RangePlan_Drop).FirstOrDefault();            

            logger.LogDebugMessage("Drop Export Views Export_Report_Filter");
            context.Database.SqlQuery<object>(SeedingObjects.View_Export_Report_Filter_Drop).FirstOrDefault();
            
            #endregion

            #region SP
            logger.LogDebugMessage("Drop ExportReport StoredProcedure");
            context.Database.SqlQuery<object>(SeedingObjects.SP_ExportReport_Drop).FirstOrDefault();            
            #endregion            

            #endregion

            #region Drop CustomTableDataType and SP

            logger.LogDebugMessage("Drop Dump_XXXXXXX StoreProcedures for all Entities");
            #region Drop Stored Procedure
            context.Database.SqlQuery<object>(SeedingObjects.SP_Dump_Age_Drop).FirstOrDefault();            
            context.Database.SqlQuery<object>(SeedingObjects.SP_Dump_CatalogueCategory_Drop).FirstOrDefault();            
            context.Database.SqlQuery<object>(SeedingObjects.SP_Dump_CoreSeasonalRange_Drop).FirstOrDefault();            
            context.Database.SqlQuery<object>(SeedingObjects.SP_Dump_DeliveryOption_Drop).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.SP_Dump_DropDownDefiningAttribute_Drop).FirstOrDefault();            
            context.Database.SqlQuery<object>(SeedingObjects.SP_Dump_FoodNonFood_Drop).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.SP_Dump_GBB_Drop).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.SP_Dump_Gender_Drop).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.SP_Dump_MainColour_Drop).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.SP_Dump_NewRI_Drop).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.SP_Dump_Outlet_Drop).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.SP_Dump_PackSize_Drop).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.SP_Dump_ProductCategory_Drop).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.SP_Dump_RaCategory_Drop).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.SP_Dump_Shot_Drop).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.SP_Dump_Status_Drop).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.SP_Dump_VAT_Drop).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.SP_Dump_WebCategory_Drop).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.SP_Dump_YesNo_Drop).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.SP_Dump_Supplier_Drop).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.SP_Dump_RangePlan_Drop).FirstOrDefault();            
            context.Database.SqlQuery<object>(SeedingObjects.SP_Delete_Before_Dump_RangePlan_Drop).FirstOrDefault();            
            #endregion

            logger.LogDebugMessage("Drop Custom DataType List_XXXXXXX for all Entities");
            #region Drop CustomeDataType
            context.Database.SqlQuery<object>(SeedingObjects.Type_ListAge_Drop).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.Type_List_CatalogueCategory_Drop).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.Type_List_CoreSeasonalRange_Drop).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.Type_List_DeliveryOption_Drop).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.Type_List_DropDownDefiningAttribute_Drop).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.Type_List_FoodNonFood_Drop).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.Type_List_GBB_Drop).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.Type_List_Gender_Drop).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.Type_List_MainColour_Drop).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.Type_List_NewRI_Drop).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.Type_List_Outlet_Drop).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.Type_List_PackSize_Drop).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.Type_List_ProductCategory_Drop).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.Type_List_RaCategory_Drop).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.Type_List_Shot_Drop).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.Type_List_Status_Drop).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.Type_List_VAT_Drop).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.Type_List_WebCategory_Drop).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.Type_List_YesNo_Drop).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.Type_List_Supplier_Drop).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.Type_List_RangePlan_Drop).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.Type_Delete_Before_List_RangePlan_Drop).FirstOrDefault();
            
            #endregion
            
            #endregion

            #region Sql Function
            logger.LogDebugMessage("Drop Function VarcharToDecimal");
            // Function to convert Varchar To Decimal value
            context.Database.SqlQuery<object>(SeedingObjects.Fn_VarcharToDecimal_Drop).FirstOrDefault();            
            #endregion

            #region Logging Stored Procedure
            logger.LogDebugMessage("Drop Procedure LogEntry");
            // Drop Stored Procedure LogEntry to re create it again fresh
            context.Database.SqlQuery<object>(SeedingObjects.SP_LogEntry_Drop).FirstOrDefault();            
            #endregion
            
            #endregion

            #region Re-Create 
            #region Logging Stored Procedure
            logger.LogDebugMessage("Create Procedure LogEntry");
            // Create Stored Procedure LogEntry to make Log entries from Import Stored Procedures            
            context.Database.SqlQuery<object>(SeedingObjects.SP_LogEntry_Create).FirstOrDefault();
            #endregion

            #region Sql Function
            logger.LogDebugMessage("Create Function VarcharToDecimal");
            // Function to convert Varchar To Decimal value            
            context.Database.SqlQuery<object>(SeedingObjects.Fn_VarcharToDecimal_Create).FirstOrDefault();
            #endregion

            #region Import CustomTableDataType and SP
            logger.LogDebugMessage("Create Custom DataType List_XXXXXXX for all Entities");
            #region insert CustomeDataType
            context.Database.SqlQuery<object>(SeedingObjects.Type_ListAge_Create).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.Type_List_CatalogueCategory_Create).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.Type_List_CoreSeasonalRange_Create).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.Type_List_DeliveryOption_Create).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.Type_List_DropDownDefiningAttribute_Create).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.Type_List_FoodNonFood_Create).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.Type_List_GBB_Create).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.Type_List_Gender_Create).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.Type_List_MainColour_Create).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.Type_List_NewRI_Create).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.Type_List_Outlet_Create).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.Type_List_PackSize_Create).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.Type_List_ProductCategory_Create).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.Type_List_RaCategory_Create).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.Type_List_Shot_Create).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.Type_List_Status_Create).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.Type_List_VAT_Create).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.Type_List_WebCategory_Create).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.Type_List_YesNo_Create).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.Type_List_Supplier_Create).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.Type_List_RangePlan_Create).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.Type_Delete_Before_List_RangePlan_Create).FirstOrDefault();
            #endregion

            logger.LogDebugMessage("Create Dump_XXXXXXX StoreProcedures for all Entities");
            #region insert Stored Procedure
            context.Database.SqlQuery<object>(SeedingObjects.SP_Dump_Age_Create).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.SP_Dump_CatalogueCategory_Create).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.SP_Dump_CoreSeasonalRange_Create).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.SP_Dump_DeliveryOption_Create).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.SP_Dump_DropDownDefiningAttribute_Create).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.SP_Dump_FoodNonFood_Create).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.SP_Dump_GBB_Create).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.SP_Dump_Gender_Create).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.SP_Dump_MainColour_Create).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.SP_Dump_NewRI_Create).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.SP_Dump_Outlet_Create).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.SP_Dump_PackSize_Create).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.SP_Dump_ProductCategory_Create).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.SP_Dump_RaCategory_Create).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.SP_Dump_Shot_Create).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.SP_Dump_Status_Create).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.SP_Dump_VAT_Create).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.SP_Dump_WebCategory_Create).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.SP_Dump_YesNo_Create).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.SP_Dump_Supplier_Create).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.SP_Dump_RangePlan_Create).FirstOrDefault();
            context.Database.SqlQuery<object>(SeedingObjects.SP_Delete_Before_Dump_RangePlan_Create).FirstOrDefault();
            #endregion
            #endregion

            #region Export Views and Stored Procedure

            #region SP
            logger.LogDebugMessage("Create ExportReport StoredProcedure");            
            context.Database.SqlQuery<object>(SeedingObjects.SP_ExportReport_Create).FirstOrDefault();
            #endregion

            #region Views
            logger.LogDebugMessage("Create Export Views Export_Report_Filter");            
            context.Database.SqlQuery<object>(SeedingObjects.View_Export_Report_Filter_Create).FirstOrDefault();

            logger.LogDebugMessage("Create Export Views Export_Report_RangePlan");            
            context.Database.SqlQuery<object>(SeedingObjects.View_Export_Report_RangePlan_Create).FirstOrDefault();

            logger.LogDebugMessage("Create Export Views Export_Report_Create");            
            context.Database.SqlQuery<object>(SeedingObjects.View_Export_Report_Create_Create).FirstOrDefault();

            logger.LogDebugMessage("Create Export Views Export_Report_Hanger7");            
            context.Database.SqlQuery<object>(SeedingObjects.View_Export_Report_Hanger7_Create).FirstOrDefault();

            #endregion

            #endregion
            #endregion

            context.SizeTypes.AddOrUpdate(c=>c.Value,
                new SizeType { Value = "Garment" },
                new SizeType { Value = "Body Protectors" },
                new SizeType { Value = "Riding Hats" },
                new SizeType { Value = "Footwear & Chaps" },
                new SizeType { Value = "Rugs" },
                new SizeType { Value = "Saddlery (Inc Masks)" },
                new SizeType { Value = "Saddles" },
                new SizeType { Value = "Liquids & Creams" }
                );            
            base.Seed(context);
            logger.LogInfoMessage("Exit ConfigurationFile.Seed");
        }
    }

}
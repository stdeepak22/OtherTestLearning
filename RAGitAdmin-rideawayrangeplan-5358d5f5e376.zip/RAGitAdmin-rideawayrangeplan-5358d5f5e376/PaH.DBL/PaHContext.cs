﻿using System.Data.Entity.Migrations;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Web;
using PaH.SqlModel.BaseClass;
using System;
using System.Data.Entity;
using System.Linq;
using PaH.SqlModel.ComboModel;
using PaH.SqlModel.EntityModel;
using Log4NetLibrary;
using System.Data.SqlClient;
using System.Web.ModelBinding;

namespace PaH.DBL
{
    /// <summary>
    /// Main context class to perform the EntityFrameowrk operations
    /// </summary>
    public class PaHContext : DbContext
    {
        // Set Logger variable
        ILogService logger = new FileLogService(typeof(PaHContext));

        /// <summary>
        /// 
        /// </summary>
        public PaHContext()
            : base("PaHContext")
        {
            //this.Configuration.AutoDetectChangesEnabled = false;                
        }

        /// <summary>
        /// this method is customized to Set the CreatedBy, CreatedOn
        /// UpdatedBy and UpdatedOn fields on each entity
        /// on Add or Update DB operation
        /// </summary>
        /// <returns></returns>
        public override int SaveChanges()
        {
            try
            {
                logger.EnterMethod("SaveChanges");

                var entities = ChangeTracker.Entries()
             .Where(
                 e =>
                 e.Entity is BaseEntity && (e.State == EntityState.Added || e.State == EntityState.Modified)
                 );

                foreach (var entity in entities)
                {
                    logger.LogDebugMessage("Entity State: " + entity.State.ToString());
                    if (entity.State == EntityState.Added)
                    {
                        ((BaseEntity)entity.Entity).CreatedBy = HttpContext.Current.User==null?"_Inserted throw Coding_":HttpContext.Current.User.Identity.Name;
                        logger.LogDebugMessage(string.Format("Entity CreatedBy New Value: {0}", ((BaseEntity)entity.Entity).CreatedBy.ToString()));

                        ((BaseEntity)entity.Entity).CreatedOn = DateTime.Now;
                        logger.LogDebugMessage(string.Format("Entity CreatedOn New Value: {0}", ((BaseEntity)entity.Entity).CreatedOn.ToString()));
                    }
                    ((BaseEntity)entity.Entity).UpdatedBy = HttpContext.Current.User == null ? "_Inserted throw Coding_" : HttpContext.Current.User.Identity.Name;
                    ((BaseEntity)entity.Entity).UpdatedOn = DateTime.Now;
                }
                logger.LeaveMethod("SaveChanges");

                return base.SaveChanges();
            }
            catch (Exception ex)
            {
                if (ex.InnerException.InnerException.Message.Contains("unique index"))
                {
                    logger.LogException(ex.InnerException.InnerException);
                }
                logger.LogException(ex);
                return 0;
            }
        }

        /// <summary>
        /// removed the Pluralization on model and cascase delete conventions
        /// used the Database Inilization and Seeding the 
        /// Sql functions, View, SP and Custom Table DataTypes
        /// </summary>
        /// <param name="modelBuilder"></param>
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            try
            {
                logger.EnterMethod("OnModelCreating");
                modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
                modelBuilder.Conventions.Remove<OneToManyCascadeDeleteConvention>();      
                base.OnModelCreating(modelBuilder);

                logger.LeaveMethod("OnModelCreating");
            }
            catch (Exception ex)
            {
                logger.LogException(ex);
            }
        }

        #region Combos
        public DbSet<Age> Ages { get; set; }
        public DbSet<CatalogueCategory> CatalogueCategories { get; set; }
        public DbSet<CatalogueSubCategory> CatalogueSubCategories { get; set; }
        public DbSet<CoreSeasonalRange> CoreSeasonalRanges { get; set; }
        public DbSet<DeliveryOption> DeliveryOptionses { get; set; }
        public DbSet<DropDownDefiningAttribute> DropDownDefiningAttributes { get; set; }
        public DbSet<FoodNonFood> FoodNonFoods { get; set; }
        public DbSet<GBB> GBBs { get; set; }
        public DbSet<Gender> Genders { get; set; }
        public DbSet<MainColour> MainColours { get; set; }
        public DbSet<NewRI> NewRIs { get; set; }
        public DbSet<Outlet> Outlets { get; set; }
        public DbSet<PackSize> PackSizes { get; set; }
        public DbSet<ProductCategory> ProductCategories { get; set; }
        public DbSet<RaCategory> RaCategories { get; set; }
        public DbSet<RaSubCategory> RaSubCategories { get; set; }
        public DbSet<RaSubSubCategory> RaSubSubCategories { get; set; }
        public DbSet<Shot> Shots { get; set; }
        public DbSet<Status> Statuses { get; set; }
        public DbSet<Supplier> Suppliers { get; set; }
        public DbSet<VAT> VATs { get; set; }
        public DbSet<WebCategory> WebCategories { get; set; }
        public DbSet<WebSubCategory> WebSubCategories { get; set; }
        public DbSet<WebSubSubCategory> WebSubSubCategories { get; set; }
        public DbSet<YesNo> YesNo { get; set; }
        // under CR01
        public DbSet<SizeType> SizeTypes { get; set; }
        #endregion

        // RangePlan
        public System.Data.Entity.DbSet<RangePlan> RangePlans { get; set; }

        //Log Table
        public System.Data.Entity.DbSet<Log> Logs { get; set; }
    }
}

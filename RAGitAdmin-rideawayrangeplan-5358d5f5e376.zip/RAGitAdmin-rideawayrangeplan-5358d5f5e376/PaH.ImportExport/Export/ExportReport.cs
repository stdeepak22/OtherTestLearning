﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using ClosedXML.Excel;
using Log4NetLibrary;
using PaH.BL.Repository;

namespace PaH.ImportExport.Export
{
    /// <summary>
    /// Internal Class to perform the Complete Export Operations
    /// Exports - RangePlan, Create and Hanger7
    /// </summary>
    internal class ExportReport
    {
        //Set Logger variable
        ILogService logger = new FileLogService(typeof(ExportReport));
        /// <summary>
        /// Internal Method to return back the MemoryStream of the excel file
        /// to be downloaded. 
        /// </summary>
        /// <param name="filters"></param>
        /// <param name="repository"></param>
        /// <param name="reportType"></param>
        /// <returns></returns>
        internal Stream GetDownloadFileStream(List<GridFilter> filters, IRepository repository, ReportType reportType)
        {
            logger.EnterMethod("GetDownloadFileStream");

            Stream result = new MemoryStream();

            string whereClause = String.Empty;
            bool isFirstFilter = true;

            /* takes the GridFilter list and form the Sql Where clause to 
              apply while filtering the RangePlan report to Export the result.
             */
            foreach (var gridFilter in filters)
            {
                logger.LogDebugMessage(string.Format("gridFilter.FilterType: {0}, gridFilter.FilterOn: {1},gridFilter.FilterValue: {2}", gridFilter.FilterType, gridFilter.FilterOn, gridFilter.FilterValue));
                if (isFirstFilter)
                {
                    whereClause += " [" + gridFilter.FilterOn + "]";
                    isFirstFilter = false;
                }
                else
                {
                    whereClause += " AND [" + gridFilter.FilterOn + "]";
                }

                if (gridFilter.FilterType == SearchType.Equals)
                {
                    whereClause += " = '" + gridFilter.FilterValue + "'";
                }
                else if (gridFilter.FilterType == SearchType.Contains)
                {
                    whereClause += " like '%" + gridFilter.FilterValue + "%'";
                }
                else if (gridFilter.FilterType == SearchType.StartsWith)
                {
                    whereClause += " like '" + gridFilter.FilterValue + "%'";
                }
                else if (gridFilter.FilterType == SearchType.EndWith)
                {
                    whereClause += " like '%" + gridFilter.FilterValue + "'";
                }
                else if (gridFilter.FilterType == SearchType.GreaterThan)
                {
                    whereClause += " > " + gridFilter.FilterValue + "";
                }
                else if (gridFilter.FilterType == SearchType.LessThan)
                {
                    whereClause += "  < " + gridFilter.FilterValue + "";
                }
            }
            // 
            try
            {
                logger.LogDebugMessage(string.Format("whereClause: {0}", whereClause));
                logger.LogDebugMessage(string.Format("reportType: {0}", reportType.ToString()));
                /*
                 * get the DataTable for particular ReportType to be exported.
                 */
                var datatable = repository.ExportReports(whereClause, reportType.ToString());

                using (XLWorkbook workbook = new XLWorkbook())
                {
                    InsertHeaderAndOtherCalcualteField(workbook, datatable, reportType);
                    workbook.SaveAs(result);
                }
                //return result;
            }
            catch (Exception exception)
            {
                logger.LogException(exception);
                throw;
            }
            logger.LeaveMethod("GetDownloadFileStream");
            return result;
        }

        /// <summary>
        ///  Method to apply the formatting like currency and number on exported SpreadSheet.
        /// </summary>
        /// <param name="ws"></param>
        /// <param name="cellsSelectorString"></param>
        /// <param name="format"></param>
        private void ApplyFormatting(IXLWorksheet ws, string cellsSelectorString, string format)
        {
            logger.EnterMethod("ApplyFormatting with string format");
            logger.LogDebugMessage(string.Format("cellsSelectorString: {0}, format: {1}", cellsSelectorString, format));

            ws.Cells(cellsSelectorString).Style.NumberFormat.SetFormat(format);

            logger.LeaveMethod("ApplyFormatting with string format");
        }

        /// <summary>
        /// Overloaded on ApplyFormatting, accepts the Id of predefine numberFormattings
        /// </summary>
        /// <param name="ws"></param>
        /// <param name="cellsSelectorString"></param>
        /// <param name="numberFormattingId"></param>
        private void ApplyFormatting(IXLWorksheet ws, string cellsSelectorString, int numberFormattingId)
        {
            logger.EnterMethod("ApplyFormatting with numberFormattingId");
            logger.LogDebugMessage(string.Format("cellsSelectorString: {0}, format: {1}", cellsSelectorString, numberFormattingId.ToString()));
            ws.Cells(cellsSelectorString).Style.NumberFormat.NumberFormatId = numberFormattingId;
            logger.LeaveMethod("ApplyFormatting with numberFormattingId");
        }

        /// <summary>
        /// private method.
        /// create the SpreadSheet, its header, format the cells, apply the formula, insert the DataTable.
        /// </summary>
        /// <param name="workbook"></param>
        /// <param name="dataTable"></param>
        /// <param name="reportType"></param>
        /// <returns></returns>
        private IXLWorksheet InsertHeaderAndOtherCalcualteField(XLWorkbook workbook, DataTable dataTable, ReportType reportType)
        {
            logger.EnterMethod("InsertHeaderAndOtherCalcualteField");
            IXLWorksheet ws = null;

            logger.LogDebugMessage(string.Format("{0}", reportType.ToString()));

            ws = workbook.AddWorksheet(reportType.ToString());
            if (ws == null)
            {
                logger.LogError("Sorry, we can export only \"RangePlan\", \"Create\" and \"Hanger7\".");
                throw new Exception("Sorry, we can export only \"RangePlan\", \"Create\" and \"Hanger7\".");
            }

            #region Report Formatting
            if (reportType == ReportType.RangePlan)
            {
                #region Header Row
                logger.LogDebugMessage("RangePlan Header Row Formatting for first three rows");

                IXLStyle style = ws.Cell(3, 1).Style;
                style.Fill.BackgroundColor = XLColor.FromArgb(245, 209, 140);
                style.Font.FontSize = 14;
                style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                style.Border.TopBorder
                    = style.Border.RightBorder
                    = style.Border.BottomBorder
                    = style.Border.LeftBorder = XLBorderStyleValues.Thick;

                ws.Cell("A3").Value = "RideAway York";
                //ws.Range("A3:AQ3").Merge();
                ws.Range("A3:BE3").Merge();
                logger.LogDebugMessage(string.Format("Set {0} Header and Merge cell for range({1})", ws.Cell("A3").Value, "A3:BE3"));

                ws.Cell("BF3").Value = "ESTIMATES & WORKINGS";
                //ws.Range("AR3:BD3").Merge();
                ws.Range("BF3:BR3").Merge();
                logger.LogDebugMessage(string.Format("Set {0} Header and Merge cell for range({1})", ws.Cell("BF3").Value, "BF3:BR3"));

                ws.Cell("BS3").Value = "FORWARD ORDER DETAILS";
                //ws.Range("BE3:BU3").Merge();
                ws.Range("BS3:CI3").Merge();
                logger.LogDebugMessage(string.Format("Set {0} Header and Merge cell for range({1})", ws.Cell("BS3").Value, "BS3:CI3"));

                ws.Cell("CJ3").Value = "EXTRA CATALOGUE DETAILS";
                //ws.Range("BV3:BZ3").Merge();
                ws.Range("CJ3:CN3").Merge();
                logger.LogDebugMessage(string.Format("Set {0} Header and Merge cell for range({1})", ws.Cell("CJ3").Value, "CJ3:CN3"));

                ws.Cell("CO3").Value = "PRODUCT SETUP";
                //ws.Range("CA3:CP3").Merge();
                ws.Range("CO3:DD3").Merge();
                logger.LogDebugMessage(string.Format("Set {0} Header and Merge cell for range({1})", ws.Cell("CO3").Value, "CO3:DD3"));

                ws.Cell("DE3").Value = "EXTRA WEB DETAILS";
                //ws.Range("CQ3:DO3").Merge();
                ws.Range("DE3:EC3").Merge();
                logger.LogDebugMessage(string.Format("Set {0} Header and Merge cell for range({1})", ws.Cell("DE3").Value, "DE3:EC3"));

                ws.Ranges("A3:BE3,BF3:BR3,BS3:CI3,CJ3:CN3,CO3:DD3,DE3:EC3").Style = style;
                #endregion

                #region Insert Table
                ws.Cell(4, 1).InsertTable(dataTable);
                logger.LogDebugMessage("Export Data from fourth row onwards for RangePlan");
                #endregion

                #region Formula calcualted cell
                ws.Cell("AW1").SetValue("Total Margin Est>");
                logger.LogDebugMessage(string.Format("Value set in Cell {0}: {1}", "AW1", ws.Cell("AW1").Value));

                ws.Cell("AX1").SetFormulaA1("=iferror((BR2-BQ2)/BR2,0)");
                logger.LogDebugMessage(string.Format("Value set in Cell {0}: {1}", "AX1", ws.Cell("AX1").FormulaA1));

                ws.Cell("AV2").Value = "Margin Ave>";
                logger.LogDebugMessage(string.Format("Value set in Cell {0}: {1}", "AV2", ws.Cell("AV2").Value));

                ws.Cell("AW2").SetFormulaA1("=iferror(AVERAGE(Table1[Ride-Away Margin % STD cost]),0)");
                logger.LogDebugMessage(string.Format("Value set in Cell {0}: {1}", "AW2", ws.Cell("AW2").FormulaA1));

                ws.Cell("AX2").SetFormulaA1("=iferror(AVERAGE(Table1[Ride-Away Margin % FWD cost]),0)");
                logger.LogDebugMessage(string.Format("Value set in Cell {0}: {1}", "AX2", ws.Cell("AX2").FormulaA1));

                ws.Cell("BF2").SetFormulaA1("=SUM(Table1[Sales Ex VAT])");
                logger.LogDebugMessage(string.Format("Value set in Cell {0}: {1}", "BF2", ws.Cell("BF2").FormulaA1));

                ws.Cell("BG2").SetFormulaA1("=SUM(Table1[Sales Units])");
                logger.LogDebugMessage(string.Format("Value set in Cell {0}: {1}", "BG2", ws.Cell("BG2").FormulaA1));

                ws.Cell("BH2").SetFormulaA1("=SUM(Table1[Sales £ Margin])");
                logger.LogDebugMessage(string.Format("Value set in Cell {0}: {1}", "BH2", ws.Cell("BH2").FormulaA1));

                ws.Cell("BI2").SetFormulaA1("=SUM(Table1[Sales Forecast Ex VAT])");
                logger.LogDebugMessage(string.Format("Value set in Cell {0}: {1}", "BI2", ws.Cell("BI2").FormulaA1));

                ws.Cell("BJ2").SetFormulaA1("=SUM(Table1[Sales Forecast Units])");
                logger.LogDebugMessage(string.Format("Value set in Cell {0}: {1}", "BJ2", ws.Cell("BJ2").FormulaA1));

                ws.Cell("BK2").SetFormulaA1("=SUM(Table1[Sales Forecast £ Margin])");
                logger.LogDebugMessage(string.Format("Value set in Cell {0}: {1}", "BK2", ws.Cell("BK2").FormulaA1));

                ws.Cell("BL2").SetFormulaA1("=SUM(Table1[Estimate Val Ex VAT (Ave)])");
                logger.LogDebugMessage(string.Format("Value set in Cell {0}: {1}", "BL2", ws.Cell("BL2").FormulaA1));

                ws.Cell("BM2").SetFormulaA1("=SUM(Table1[Estimate Qty])");
                logger.LogDebugMessage(string.Format("Value set in Cell {0}: {1}", "BM2", ws.Cell("BM2").FormulaA1));

                ws.Cell("BN2").SetFormulaA1("=SUM(Table1[Rounded Estimate QTY])");
                logger.LogDebugMessage(string.Format("Value set in Cell {0}: {1}", "BN2", ws.Cell("BN2").FormulaA1));

                ws.Cell("BO2").SetFormulaA1("=SUM(Table1[Retail Estimate @STD Cost])");
                logger.LogDebugMessage(string.Format("Value set in Cell {0}: {1}", "BO2", ws.Cell("BO2").FormulaA1));

                ws.Cell("BP2").SetFormulaA1("=SUM(Table1[Retail Estimate @FWD Cost])");
                logger.LogDebugMessage(string.Format("Value set in Cell {0}: {1}", "BP2", ws.Cell("BP2").FormulaA1));

                ws.Cell("BQ2").SetFormulaA1("=SUM(Table1[Retail Estimate Ex VAT])");
                logger.LogDebugMessage(string.Format("Value set in Cell {0}: {1}", "BQ2", ws.Cell("BQ2").FormulaA1));

                ws.Cell("BR2").SetFormulaA1("=SUM(Table1[Retail Estimate Inc VAT])");
                logger.LogDebugMessage(string.Format("Value set in Cell {0}: {1}", "BR2", ws.Cell("BR2").FormulaA1));

                ws.Cell("BS2").SetFormulaA1("=SUM(Table1[Current Stock])");
                logger.LogDebugMessage(string.Format("Value set in Cell {0}: {1}", "BS2", ws.Cell("BS2").FormulaA1));

                ws.Cell("BT2").SetFormulaA1("=SUM(Table1[Current Season Estimate])");
                logger.LogDebugMessage(string.Format("Value set in Cell {0}: {1}", "BT2", ws.Cell("BT2").FormulaA1));

                ws.Cell("BU2").SetFormulaA1("=SUM(Table1[Current Season Closing Stock])");
                logger.LogDebugMessage(string.Format("Value set in Cell {0}: {1}", "BU2", ws.Cell("BU2").FormulaA1));

                ws.Cell("BV2").SetFormulaA1("=SUM(Table1[Current Season Closing Stock (Rounded)])");
                logger.LogDebugMessage(string.Format("Value set in Cell {0}: {1}", "BV2", ws.Cell("BV2").FormulaA1));

                ws.Cell("BW2").SetFormulaA1("=SUM(Table1[Forward Order Qty])");
                logger.LogDebugMessage(string.Format("Value set in Cell {0}: {1}", "BW2", ws.Cell("BW2").FormulaA1));

                ws.Cell("BX2").SetFormulaA1("=SUM(Table1[Forward Order @CP (Std Disc)])");
                logger.LogDebugMessage(string.Format("Value set in Cell {0}: {1}", "BX2", ws.Cell("BX2").FormulaA1));

                ws.Cell("BY2").SetFormulaA1("=SUM(Table1[Forwrad Order @CP (Fwd Disc)])");
                logger.LogDebugMessage(string.Format("Value set in Cell {0}: {1}", "BY2", ws.Cell("BY2").FormulaA1));

                ws.Cell("BZ2").SetFormulaA1("=SUM(Table1[Forward Order @Retail Ex VAT])");
                logger.LogDebugMessage(string.Format("Value set in Cell {0}: {1}", "BZ2", ws.Cell("BZ2").FormulaA1));

                ws.Cell("CA2").SetFormulaA1("=SUM(Table1[Forward Order @Retail INC VAT])");
                logger.LogDebugMessage(string.Format("Value set in Cell {0}: {1}", "CA2", ws.Cell("CA2").FormulaA1));

                ws.Cell("CB2").SetFormulaA1("=SUM(Table1[1ST DROP])");
                logger.LogDebugMessage(string.Format("Value set in Cell {0}: {1}", "CB2", ws.Cell("CB2").FormulaA1));

                ws.Cell("CC2").SetFormulaA1("=SUM(Table1[2ND DROP])");
                logger.LogDebugMessage(string.Format("Value set in Cell {0}: {1}", "CC2", ws.Cell("CC2").FormulaA1));

                ws.Cell("CD2").SetFormulaA1("=SUM(Table1[3RD DROP])");
                logger.LogDebugMessage(string.Format("Value set in Cell {0}: {1}", "CD2", ws.Cell("CD2").FormulaA1));

                ws.Cell("CE2").SetFormulaA1("=SUM(Table1[4TH DROP])");
                logger.LogDebugMessage(string.Format("Value set in Cell {0}: {1}", "CE2", ws.Cell("CE2").FormulaA1));

                ws.Cell("CF2").SetFormulaA1("=SUM(Table1[5TH DROP])");
                logger.LogDebugMessage(string.Format("Value set in Cell {0}: {1}", "CF2", ws.Cell("CF2").FormulaA1));

                ws.Cell("CG2").SetFormulaA1("=SUM(Table1[6TH DROP])");
                logger.LogDebugMessage(string.Format("Value set in Cell {0}: {1}", "CG2", ws.Cell("CG2").FormulaA1));

                ws.Cell("CH2").SetFormulaA1("=SUM(Table1[Split Check])");
                logger.LogDebugMessage(string.Format("Value set in Cell {0}: {1}", "CH2", ws.Cell("CH2").FormulaA1));
                #endregion

                #region Number Percentage and Currency Formatting
                int rowsToFormat = dataTable.Rows.Count + 4;
                string percFormatting = "AJ5:AK" + rowsToFormat +
                                        ", AP5:AP" + rowsToFormat +
                                        ", AW5:AX" + rowsToFormat +
                                        ", AX1, AW2:AX2";
                logger.LogDebugMessage(string.Format("percFormatting: {0}", percFormatting));

                string currencyFormatting2Plce = "AH5:AI" + rowsToFormat +
                                                 ", AL5:AO" + rowsToFormat +
                                                 ", AQ5:AS" + rowsToFormat +
                                                 ", AU5:AV" + rowsToFormat +
                                                 ", CY5:CY" + rowsToFormat;
                logger.LogDebugMessage(string.Format("currencyFormatting2Plce: {0}", currencyFormatting2Plce));

                string currencyFormatting = "BF5:BF" + rowsToFormat +
                                            ", BH5:BI" + rowsToFormat +
                                            ", BK5:BL" + rowsToFormat +
                                            ", BO5:BR" + rowsToFormat +
                                            ", BX5:CA" + rowsToFormat +
                                            ", BF2, BH2:BI2, BK2:BL2, BO2:BR2, BX2:CA2";
                logger.LogDebugMessage(string.Format("currencyFormatting: {0}", currencyFormatting));

                ApplyFormatting(ws, percFormatting, "0.00%");
                logger.LogDebugMessage(string.Format("Percentage Format Applied on Cells {0}: Format is: {1}", percFormatting, "0.00%"));

                ApplyFormatting(ws, currencyFormatting2Plce, "£#,##0.00");
                logger.LogDebugMessage(string.Format("Currency Format Applied on Cells {0}: Format is: {1}", currencyFormatting2Plce, "£#,##0.00"));

                ApplyFormatting(ws, currencyFormatting, "£#,##0");
                logger.LogDebugMessage(string.Format("Currency Format Applied on Cells {0}: Format is: {1}", currencyFormatting, "£#,##0"));
                
                ws.Columns().AdjustToContents();

                ws.Column("AG").Width = 50;
                ws.Column("CI").Width = 50;
                ws.Column("CN").Width = 50;

                ws.Rows().Height = 15;
                
                #endregion

            }
            else if (reportType == ReportType.Create)
            {
                #region Insert Table
                ws.Cell(1, 1).InsertTable(dataTable);
                logger.LogDebugMessage("Insert Create Table");
                #endregion

                #region Formula calcualted cell
                int rowsToFormat = dataTable.Rows.Count + 1;

                // Column (B) V_trad_code
                // Formula:- =IF(A2>0,"RWSTIL","") Where A2=V_prod_code
                ws.Cells("B2:B" + rowsToFormat).FormulaR1C1 = "=IF(RC[-1]>0,\"RWSTIL\",\"\")";
                logger.LogDebugMessage(string.Format("Formula on Create Sheet for Range {0}, is {1}", "B2:B" + rowsToFormat, ws.Cell("B2").FormulaR1C1));

                // Column (C) V_prod_desc
                // Formula:- =BC2&" "&BD2&" "&BE2 Where BC=MANUAL DESCRIPTION BD=MANUAL COLOUR OPT BE=MANUAL SIZE OPT
                //ws.Cells("C2:C" + rowsToFormat).FormulaR1C1 = "=RC[52]&\" \"&RC[53]&\" \"&RC[54]";
                //logger.LogDebugMessage(string.Format("Formula on Create Sheet for Range {0}, is {1}", "C2:C" + rowsToFormat, ws.Cell("C2").FormulaR1C1));
                ws.Cells("C2:C" + rowsToFormat).FormulaR1C1 = "=RC[58]&\" \"&RC[59]&\" \"&RC[60]";
                logger.LogDebugMessage(string.Format("Formula on Create Sheet for Range {0}, is {1}", "C2:C" + rowsToFormat, ws.Cell("C2").FormulaR1C1));

                // Column (D) V_short_name
                // Formula:- =IF(C2=0,"",C2) Where C2=V_prod_desc
                ws.Cells("D2:D" + rowsToFormat).FormulaR1C1 = "=IF(RC[-1]=0,\"\",RC[-1])";
                logger.LogDebugMessage(string.Format("Formula on Create Sheet for Range {0}, is {1}", "D2:D" + rowsToFormat, ws.Cell("D2").FormulaR1C1));

                // Column (N) V_prod_prgrp_code
                // Formula:- =F2 Where F2=V_prod_analysis
                ws.Cells("N2:N" + rowsToFormat).FormulaR1C1 = "=RC[-8]";
                logger.LogDebugMessage(string.Format("Formula on Create Sheet for Range {0}, is {1}", "N2:N" + rowsToFormat, ws.Cell("N2").FormulaR1C1));

                // Column (Q) V_supp_code
                //  Formula:- =E2 Where E2=V_stock_section_code
                ws.Cells("Q2:Q" + rowsToFormat).FormulaR1C1 = "=RC[-12]";
                logger.LogDebugMessage(string.Format("Formula on Create Sheet for Range {0}, is {1}", "Q2:Q" + rowsToFormat, ws.Cell("Q2").FormulaR1C1));

                // Column (W) V_sales_order_unit_group
                // Formula:- =IF(V2>0,"EACH","") Where V2=V_sell_price
                ws.Cells("W2:W" + rowsToFormat).FormulaR1C1 = "=IF(RC[-1]>0,\"EACH\",\"\")";
                logger.LogDebugMessage(string.Format("Formula on Create Sheet for Range {0}, is {1}", "W2:W" + rowsToFormat, ws.Cell("W2").FormulaR1C1));

                // Same formula on X, Y and Z column/ AC, AD and AE column
                // Column (X) V_def_sales_order_unit, Column (Y) V_sales_pricing_unit_group, Column (Z) V_def_sales_pricing_unit
                // Column (AC) V_def_buying_order_unit, Column (AD) V_buying_price_unit_group, Column (AE) V_def_buying_price_unit
                // Formula:- For (X) =W2 , For (Y) =X2,For (Z) =Y2,For (AC) =AB2,For (AD) =AC2,For (AE) =AD2
                ws.Cells("X2:Z" + rowsToFormat+", AC2:AE"+rowsToFormat).FormulaR1C1 = "=RC[-1]";
                logger.LogDebugMessage(string.Format("Formula on Create Sheet for Range {0}, is {1}", "X2:Z" + rowsToFormat+",AC2:AE" + rowsToFormat, ws.Cell("X2").FormulaR1C1));

                // Column (AH) V_template_product --> BD
                // Formula:- =IF(L2>0,"783456","") Where L2 = V_prod_keyword_3
                //ws.Cells("AH2:AH" + rowsToFormat).FormulaR1C1 = "=IF(RC[-22]>0,\"783456\",\"\")";
                //logger.LogDebugMessage(string.Format("Formula on Create Sheet for Range {0}, is {1}", "AH2:AH" + rowsToFormat, ws.Cell("AH2").FormulaR1C1));
                ws.Cells("BD2:BD" + rowsToFormat).FormulaR1C1 = "=IF(RC[-44]>0,\"783456\",\"\")";
                logger.LogDebugMessage(string.Format("Formula on Create Sheet for Range {0}, is {1}", "BD2:BD" + rowsToFormat , ws.Cell("BD2").FormulaR1C1));

                // Column (AZ) V_short_name_range --> BF
                // Formula:- =BG2&" "&K2 Where BA2 = V_prod_analysis_desc and K2=V_prod_keyword_2
                //ws.Cells("AZ2:AZ" + rowsToFormat).FormulaR1C1 = "=RC[1]&\" \"&RC[-41]";
                //logger.LogDebugMessage(string.Format("Formula on Create Sheet for Range {0}, is {1}", "AZ2:AZ" + rowsToFormat , ws.Cell("AZ2").FormulaR1C1));
                ws.Cells("BF2:BF" + rowsToFormat).FormulaR1C1 = "=RC[1]&\" \"&RC[-47]";
                logger.LogDebugMessage(string.Format("Formula on Create Sheet for Range {0}, is {1}", "BF2:BF" + rowsToFormat, ws.Cell("BF2").FormulaR1C1));

                // Column (BA) V_prod_analysis_desc --> BG
                // Formula:- =G2 Where G2=V_prod_analysis_desc_range
                //ws.Cells("BA2:BA" + rowsToFormat).FormulaR1C1 = "=RC[-46]";
                //logger.LogDebugMessage(string.Format("Formula on Create Sheet for Range {0}, is {1}", "BA2:BA" + rowsToFormat, ws.Cell("BA2").FormulaR1C1));
                ws.Cells("BG2:BG" + rowsToFormat).FormulaR1C1 = "=RC[-52]";
                logger.LogDebugMessage(string.Format("Formula on Create Sheet for Range {0}, is {1}", "BG2:BG" + rowsToFormat, ws.Cell("BG2").FormulaR1C1));

                // Column (BF) CHARACTER COUNT --> BL
                // Formula:- =LEN(C2) Where C2=V_prod_desc
                //ws.Cells("BF2:BF" + rowsToFormat).FormulaR1C1 = "=LEN(RC[-55])";
                //logger.LogDebugMessage(string.Format("Formula on Create Sheet for Range {0}, is {1}", "BF2:BF" + rowsToFormat, ws.Cell("BF2").FormulaR1C1));
                ws.Cells("BL2:BL" + rowsToFormat).FormulaR1C1 = "=LEN(RC[-61])";
                logger.LogDebugMessage(string.Format("Formula on Create Sheet for Range {0}, is {1}", "BL2:BL" + rowsToFormat, ws.Cell("BL2").FormulaR1C1));

                // Column (BH) SHUFTY --> BN
                //Formula:- =J2&"/"&L2 Where J2= V_prod_keyword_1 L2=V_prod_keyword_3
                //ws.Cells("BH2:BH" + rowsToFormat).FormulaR1C1 = "=RC[-50]&\"/\"&RC[-48]";
                //logger.LogDebugMessage(string.Format("Formula on Create Sheet for Range {0}, is {1}", "BH2:BH" + rowsToFormat, ws.Cell("BH2").FormulaR1C1));
                ws.Cells("BN2:BN" + rowsToFormat).FormulaR1C1 = "=RC[-56]&\"/\"&RC[-54]";
                logger.LogDebugMessage(string.Format("Formula on Create Sheet for Range {0}, is {1}", "BN2:BN" + rowsToFormat, ws.Cell("BN2").FormulaR1C1));

                ws.Columns().AdjustToContents();
                
                #endregion
                //ws.Columns("G,AZ:BA").Width = 50;
                ws.Columns("G,BF:BG").Width = 50;

                #region Currency Formatting

                string currencyFormatting2Plce = "V2:V" + rowsToFormat;
                //ApplyFormatting(ws, currencyFormatting2Plce, "£#,##0.00");
                //logger.LogDebugMessage(string.Format("Currency Format Applied on Cells {0}: Format is: {1}", currencyFormatting2Plce, "£#,##0.00"));
                ApplyFormatting(ws, currencyFormatting2Plce, "#,##0.00");
                logger.LogDebugMessage(string.Format("Currency Format Applied on Cells {0}: Format is: {1}", currencyFormatting2Plce, "#,##0.00"));
                #endregion
            }
            else if (reportType == ReportType.Hanger7)
            {
                #region Header Row

                ws.Range("A1:I5").Merge()
                  .Cell(1, 1).SetValue("Publications New Page Brief")
                  .Style.Font.SetFontSize(20)
                  .Alignment.SetHorizontal(XLAlignmentHorizontalValues.Center)
                  .Alignment.SetVertical(XLAlignmentVerticalValues.Center);
                logger.LogDebugMessage(string.Format("Set Exported Hanger7 Header Text for Range {0} as {1}", "A1:I5", ws.Cell(1, 1).Value));

                //ws.Range("A10:E12").Merge()
                //  .Cell(1, 1).SetValue("RDA48A-RDA51B- Turnout Rugs")
                //  .Style.Font.SetFontSize(16)
                //  .Alignment.SetHorizontal(XLAlignmentHorizontalValues.Center)
                //  .Alignment.SetVertical(XLAlignmentVerticalValues.Center);
                //logger.LogDebugMessage(string.Format("Set Exported Hanger7 Header Text for Range {0} as {1}", "A10:E12", ws.Cell(1, 1).Value));
                #endregion

                #region Insert Table
                #region calculate the effective table and insert it
                logger.LogDebugMessage(string.Format("Calculate the effective table and insert it"));

                DataTable actualToExport = new DataTable();
                DataRow tempRow;
                List<int> newRowIndex = new List<int>();

                foreach (DataColumn column in dataTable.Columns)
                {
                    actualToExport.Columns.Add(new DataColumn(column.ColumnName, column.DataType));
                    logger.LogDebugMessage(string.Format("Added Column {0} with DataType {1}", column.ColumnName, column.DataType.ToString()));
                }                
                foreach (var dataRow in dataTable.AsEnumerable())
                {                    
                    tempRow = actualToExport.NewRow();
                    if (dataRow[0].CastTo<bool>() == false)
                    {
                        newRowIndex.Add(actualToExport.Rows.Count);
                        tempRow.ItemArray = dataRow.ItemArray.Clone() as object[];
                        actualToExport.Rows.Add(tempRow);
                    }
                    else
                    {                        
                        tempRow["Size"] = dataRow["Size"];

                        bool isRowDuplicate = false;
                        foreach (DataRow dataRowItem in actualToExport.Rows)
                        {
                            if (actualToExport.Rows.IndexOf(dataRowItem) < newRowIndex[newRowIndex.Count - 1])
                            {
                                continue;
                            }
                            if (dataRowItem["Size"].ToString().Trim() == tempRow["Size"].ToString().Trim())
                            {
                                isRowDuplicate = true;
                                break;
                            }
                        }

                        if (isRowDuplicate == false)
                        {
                            actualToExport.Rows[newRowIndex[newRowIndex.Count - 1]]["Product Text"]
                            += dataRow["Product Text"].ToString();
                            actualToExport.Rows.Add(tempRow);
                        }
                    }
                }

                newRowIndex.Add(actualToExport.Rows.Count);

                //remove IsDuplicate, Id, RaProductCodeNew
                actualToExport.Columns.RemoveAt(0);
                actualToExport.Columns.RemoveAt(0);
                actualToExport.Columns.RemoveAt(0);

                for (int i = 0; i < actualToExport.Columns.Count; i++)
                {
                    ws.Cell(13, i + 1).SetValue(actualToExport.Columns[i].ColumnName);
                    logger.LogDebugMessage(string.Format("Set header data on {0} row, {1} column and columnName {2}", "13", i + 1, ws.Cell(13, i + 1).Value.ToString()));
                }
                ws.Range("A13:R13")
                  .Style.Fill.SetBackgroundColor(XLColor.FromTheme(XLThemeColor.Accent1))
                  .Font.SetFontColor(XLColor.White);

                int rowsToFormat = actualToExport.Rows.Count + 13;

                ws.Cell(14, 1).InsertData(actualToExport.AsEnumerable());
                logger.LogDebugMessage(string.Format("Data inserted at Fourteenth row"));
                #endregion


                #region Mergin the blank cell and apply formattin on it
                // merge the duplicate blank cells
                for (int i = 0; i < newRowIndex.Count - 1; i++)
                {
                    for (int j = 1; j <= actualToExport.Columns.Count; j++)
                    {
                        if (actualToExport.Columns[j - 1].ColumnName.Trim().ToLower() != "size")
                        {
                            int firstCellRow = 14 + newRowIndex[i];
                            int firstCellColumn = j;
                            int lastCellRow = 14 + newRowIndex[i + 1] - 1;
                            int lastCellColumn = j;
                            ws.Range(firstCellRow, firstCellColumn, lastCellRow, lastCellColumn).Merge();
                        }
                    }
                }
                ws.Columns().AdjustToContents();

                string dataTableRange = "A13:R" + rowsToFormat;
                ws.Range(dataTableRange)
                  .Style.Border.SetOutsideBorder(XLBorderStyleValues.Thin)
                  .Border.SetInsideBorder(XLBorderStyleValues.Thin);

                ws.Range(dataTableRange).SetAutoFilter();
                ws.Range(dataTableRange).Style.Alignment.SetVertical(XLAlignmentVerticalValues.Center)
                  .Alignment.SetHorizontal(XLAlignmentHorizontalValues.Left);

                ws.Column("E").Width = 50;
                ws.Range("E14:E" + rowsToFormat).Style.Alignment.SetWrapText()
                  .Alignment.SetVertical(XLAlignmentVerticalValues.Center)
                  .Alignment.SetHorizontal(XLAlignmentHorizontalValues.Left);
                #endregion

                #endregion

                #region Currency Formatting

                string currencyFormatting2Plce = "D14:D" + rowsToFormat;
                ApplyFormatting(ws, currencyFormatting2Plce, "£#,##0.00");
                logger.LogDebugMessage(string.Format("Currency Format Applied on Cells {0}: Format is: {1}", currencyFormatting2Plce, "£#,##0.00"));

                #endregion
            }

            #endregion
            logger.LeaveMethod("InsertHeaderAndOtherCalcualteField");
            return ws;
        }
    }
}

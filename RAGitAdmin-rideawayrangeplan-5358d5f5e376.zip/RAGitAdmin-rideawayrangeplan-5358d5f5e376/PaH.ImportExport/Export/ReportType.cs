﻿namespace PaH.ImportExport.Export
{
    /// <summary>
    /// Enum for possible 3 report types.
    /// </summary>
    public enum ReportType
    {
        RangePlan,
        Create,
        Hanger7
    }
}
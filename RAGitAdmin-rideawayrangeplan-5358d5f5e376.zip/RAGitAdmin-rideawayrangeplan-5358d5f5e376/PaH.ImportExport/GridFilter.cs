﻿namespace PaH.ImportExport
{
    /// <summary>
    /// Enum for GridMVC filter.
    /// GridMVC filter the records from QueryString.
    /// This class is a Supportive class to convert the Querystring in to class object
    /// </summary>
    public enum SearchType
    {
        Equals = 1,
        Contains = 2,
        StartsWith = 3,
        EndWith = 4,
        GreaterThan = 5,
        LessThan = 6
    }


    /// <summary>
    /// Representing the Querystring as Object.
    /// </summary>
    public class GridFilter
    {
        public string FilterOn { get; set; }
        public SearchType FilterType { get; set; }
        public string FilterValue { get; set; }
    }
}

﻿namespace PaH.ImportExport.Import
{
    /// <summary>
    /// a Class having information about the Custom DataType and Stored Procedure 
    /// to import the Data.
    /// </summary>
    public class PaHDefined
    {
        /// <summary>
        /// Custom Sql Table Data Type
        ///  </summary>
        public class SqlDataType
        {
            public string List_Age { get; set; }
            public string List_CatalogueCategory { get; set; }
            public string List_CoreSeasonalRange { get; set; }
            public string List_DeliveryOption { get; set; }
            public string List_DropDownDefiningAttribute { get; set; }
            public string List_FoodNonFood { get; set; }
            public string List_GBB { get; set; }
            public string List_Gender { get; set; }
            public string List_MainColour { get; set; }
            public string List_NewRI { get; set; }
            public string List_Outlet { get; set; }
            public string List_PackSize { get; set; }
            public string List_ProductCategory { get; set; }
            public string List_RaCategory { get; set; }
            public string List_Shot { get; set; }
            public string List_Status { get; set; }
            public string List_VAT { get; set; }
            public string List_WebCategory { get; set; }
            public string List_YesNo { get; set; }

            // For Combo (Supplier)from RangePlan header
            public string List_Supplier { get; set; }

            public string List_RangePlan { get; set; }
        }

        /// <summary>
        /// Created SP to Import list and RangetPlan
        /// </summary>
        public class SP
        {
            public string Dump_Age { get; set; }
            public string Dump_CatalogueCategory { get; set; }
            public string Dump_CoreSeasonalRange { get; set; }
            public string Dump_DeliveryOption { get; set; }
            public string Dump_DropDownDefiningAttribute { get; set; }
            public string Dump_FoodNonFood { get; set; }
            public string Dump_GBB { get; set; }
            public string Dump_Gender { get; set; }
            public string Dump_MainColour { get; set; }
            public string Dump_NewRI { get; set; }
            public string Dump_Outlet { get; set; }
            public string Dump_PackSize { get; set; }
            public string Dump_ProductCategory { get; set; }
            public string Dump_RaCategory { get; set; }
            public string Dump_Shot { get; set; }
            public string Dump_Status { get; set; }
            public string Dump_VAT { get; set; }
            public string Dump_WebCategory { get; set; }
            public string Dump_YesNo { get; set; }

            // For Combo (Supplier)from RangePlan header
            public string Dump_Supplier { get; set; }

            public string Dump_RangePlan { get; set; }
        }
    }
}
﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using ClosedXML.Excel;
using DocumentFormat.OpenXml.Office.Excel;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using PaH.ImportExport.ImportExportConfig;
using x14 = DocumentFormat.OpenXml.Office2010.Excel;
using PaH.BL.Repository;
using Log4NetLibrary;
using PaH.UiModel.Resources;

namespace PaH.ImportExport.Import.List
{
    /// <summary>
    /// Combo Processing is to Import all the possible list/Combos
    /// </summary>
    public class ComboProcessing
    {
        // Set Logger 
        ILogService logger = new FileLogService(typeof(ComboProcessing));

        private readonly string _fileName = String.Empty;
        private readonly Regex _regRightValidation = new Regex("([a-zA-Z]+)([0-9]+):([a-zA-Z]+)([0-9]+)");
        private readonly Regex _regRangeReplace = new Regex("\\$[a-zA-Z]{1}\\$");

        /// <summary>
        /// Class to read the RangePlan sheet and fetch the 
        /// Combo information, we need to pass only the file name
        /// </summary>
        public ComboProcessing(string fileName)
        {
            logger.EnterMethod("ComboProcessing");
            _fileName = fileName;
            logger.LogDebugMessage(string.Format("_fileName {0}", _fileName));
            logger.LeaveMethod("ComboProcessing");
        }

        /// <summary>
        /// This method is to insert the Combo from Range plan sheet to 
        /// database.  we need to pass the dbContext and logged in user 
        /// for logging purpose
        /// </summary>
        /// <param name="repository"></param>
        /// <param name="loggedInUser"></param>
        /// <param name="successResult"></param>
        /// <param name="failurResult"></param>
        public void InsertComboInDB(IRepository repository, string loggedInUser, ref string successResult, ref string failurResult)
        {
            logger.EnterMethod("InsertComboInDB");
            using (SpreadsheetDocument spreadsheetDocument = SpreadsheetDocument.Open(_fileName, false))
            {
                var workbookPart = spreadsheetDocument.WorkbookPart;
                var workbook = workbookPart.Workbook;
                var sheet = workbook.Descendants<Sheet>().FirstOrDefault(c => c.Name == "Range Plan");
                if (sheet == null)
                {
                    logger.LogError("Not a Valid File.");
                    throw new Exception(Message_Resource.Message_NotValidFile);
                }
                var worksheetPart = (WorksheetPart)workbook.WorkbookPart.GetPartById(sheet.Id);
                var worksheet = worksheetPart.Worksheet;

                logger.LogDebugMessage(string.Format("worksheet LocalName {0}", worksheet.LocalName));

                CombosModel combosModel = GetComboFormulas(worksheet);
                FillDataTableInComboModel(ref combosModel);

                foreach (PropertyInfo property in combosModel.GetType().GetProperties())
                {
                    string errorMessage = string.Empty;
                    try
                    {
                        var datatableFormula = (DataTable_Formula)property.GetValue(combosModel);
                        if (datatableFormula != null)
                        {
                            logger.LogDebugMessage(string.Format("datatableFormula.formula: {0},property.Name: {1}", datatableFormula.formula, property.Name));
                            // all - 2 ==> as 2 rows are logging table rows each procedure
                            int recordInsertUpdate = (ExecuteSP(property.Name, datatableFormula.DataTable, repository, loggedInUser, ref errorMessage) - 2);
                            if (errorMessage == string.Empty)
                            {
                                successResult += recordInsertUpdate + Combo_Resource.InsertComboInDB_successResult +
                                                 property.Name +
                                                 ".\n";
                            }
                            else
                            {
                                failurResult += errorMessage;
                            }
                        }
                        else
                        {
                            failurResult += string.Format(Combo_Resource.InsertComboInDB_ComboIncorrectFormula + "\n", property.Name);
                        }
                        logger.LogDebugMessage(string.Format("returnMessage: Success-{0},Failure-{1}", successResult, failurResult));
                    }
                    catch(Exception ex){
                        failurResult += string.Format("Combo Import Failed with error{0}.\n", ex.Message);
                        logger.LogException(ex);
                    }
                    finally { }
                }
            }
            logger.LeaveMethod("InsertComboInDB");
        }

        /// <summary>
        /// A private method, responsible to execute the respecive
        /// stored procedure and insert the combo value into DB
        /// </summary>
        /// <param name="propertyName"></param>
        /// <param name="dt"></param>
        /// <param name="repository"></param>
        /// <param name="loggedInUser"></param>
        /// <returns></returns>
        private int ExecuteSP(string propertyName, DataTable dt, IRepository repository, string loggedInUser, ref string errorMessage)
        {
            logger.EnterMethod("ExecuteSP");
            logger.LogDebugMessage(string.Format("propertyName: {0}, loggedInUser: {1} ", propertyName, loggedInUser));

            var dataTable = new SqlParameter
            {
                ParameterName = "Dump",
                TypeName = StoredProcedureAndTypeSetting.AllEntities[propertyName].SqlCustomDataType,
                Value = dt
            };

            var user = new SqlParameter
            {
                ParameterName = "User",
                Value = loggedInUser
            };
            logger.LogDebugMessage(string.Format("dataTable.ParameterName: {0}, dataTable.TypeName: {1},dataTable.Value {2} user.ParameterName: {3}, user.Value: {4}", dataTable.ParameterName, dataTable.TypeName, dataTable.Value.ToString(), user.ParameterName, user.Value));

            int result = repository.ExecuteSqlQuery(@"" +
                                                     "exec " + StoredProcedureAndTypeSetting.AllEntities[propertyName].SPName +
                                                     " @Dump, @User", ref errorMessage,
                                                     dataTable, user);

            logger.LeaveMethod("ExecuteSP");
            logger.LogDebugMessage(string.Format("result: {0} errorMessage: {1}", result, errorMessage));

            return result;
        }

        /// <summary>
        /// using ClosedXML read the List sheet and populate the data in ComboModel
        /// passed in as parameter, which contains the Range for data to fetch
        /// </summary>
        /// <param name="combosModel"></param>
        private void FillDataTableInComboModel(ref CombosModel combosModel)
        {
            logger.EnterMethod("FillDataTableInComboModel");
            using (XLWorkbook workbook = new XLWorkbook(_fileName))
            {
                IXLWorksheet worksheet = null;
                foreach (PropertyInfo property in combosModel.GetType().GetProperties())
                {
                    try
                    {
                        string formula = string.Empty;
                        if (property.GetValue(combosModel) != null)
                        {
                            formula = ((DataTable_Formula)property.GetValue(combosModel)).formula;
                            logger.LogDebugMessage(string.Format("formula: {0}", formula));
                        }
                        else
                        {
                            logger.LogDebugMessage(string.Format("No Formula/Lookups defined on column {0} for Combo Import",property.Name));
                        }
                        

                        string sheetName = formula.Split('!')[0];
                        logger.LogDebugMessage(string.Format("sheetName: {0}", sheetName));

                        // if sheetName is not null or empty get comboModel details
                        if (!string.IsNullOrEmpty(sheetName))
                        {
                            worksheet = workbook.Worksheet(sheetName);
                            logger.LogDebugMessage(string.Format("worksheet.Name: {0}", worksheet.Name));

                            ((DataTable_Formula)property.GetValue(combosModel)).DataTable =
                                GetDataTable(worksheet.Range(formula), property.Name);
                            logger.LogDebugMessage(string.Format("DataTable for sheet {0} fetched", worksheet.Name));
                        }
                    }
                    catch (Exception exception)
                    {
                        logger.LogException(exception);
                    }
                }
            }
            logger.LeaveMethod("FillDataTableInComboModel");
        }

        /// <summary>
        /// Create the object of DataTable from the IXLRange object
        /// </summary>
        /// <param name="range"></param>
        /// <param name="propertyName"></param>
        /// <returns></returns>
        private DataTable GetDataTable(IXLRange range, string propertyName)
        {
            logger.EnterMethod("GetDataTable");
            logger.LogDebugMessage(string.Format("propertyName: {0}", propertyName));
            DataTable result = new DataTable();

            if (range.Rows().Any())
            {
                for (int i = 0; i < range.ColumnCount(); i++)
                {
                    result.Columns.Add(new DataColumn());
                }
                DataRow tempRow = null;
                for (int i = 1; i <= range.Rows().Count(); i++)
                {
                    tempRow = result.NewRow();
                    for (int j = 1; j <= range.ColumnCount(); j++)
                    {
                        object value = range.Cell(i, j).Value;
                        tempRow[j - 1] = value == null ? String.Empty : value.ToString().Trim();
                        logger.LogDebugMessage(string.Format("range value for Cell {0}-{1} is {2}, ", i, j, tempRow[j - 1]));
                    }
                    if (!NeedToExcludeRow(tempRow, propertyName))
                    {
                        result.Rows.Add(tempRow);
                        logger.LogDebugMessage(string.Format("tempRow not excluded"));
                    }
                }
            }
            logger.LeaveMethod("GetDataTable");
            // remove the duplicate rows.
            return result.DefaultView.ToTable();
        }

        /// <summary>
        /// To exclude few Rows or Fully Table if not required
        /// or duplicate or few to some conditions
        /// </summary>
        /// <param name="propertyName"></param>
        /// <param name="tempRow"></param>
        /// <returns></returns>
        private bool NeedToExcludeRow(DataRow tempRow, string propertyName)
        {
            bool blnNeedToExcludeRow = false;
            logger.EnterMethod("NeedToExcludeRow");
            //Category property
            logger.LogDebugMessage(string.Format("propertyName: {0}", propertyName));
            if (propertyName.ToUpper() == "SubCategory".ToUpper())
            {
                if (tempRow[1].ToString() == String.Empty)
                {
                    blnNeedToExcludeRow = true;
                }
            }
            else if (propertyName.ToUpper() == "NewRI".ToUpper())
            {
                if (tempRow[0].ToString().Trim() == String.Empty)
                {
                    blnNeedToExcludeRow = true;
                }
            }
            else if (propertyName.ToUpper() == "BuyingCaseSize".ToUpper())
            {
                if (tempRow[0].ToString().Trim() == String.Empty)
                {
                    blnNeedToExcludeRow = true;
                }
            }
            else if (propertyName == "ClickAndCollect")
            {
                // exclude full table as we will use YesNo  instead of Y/N
                blnNeedToExcludeRow = true;
            }
            else
            {
                blnNeedToExcludeRow = false;
            }
            logger.LogDebugMessage(string.Format("blnNeedToExcludeRow: {0}", blnNeedToExcludeRow));
            logger.LeaveMethod("NeedToExcludeRow");
            return blnNeedToExcludeRow;
        }

        /// <summary>
        /// Method takes two parameters - PropertyName, tempFormula
        /// using propertyName we get the columnRange defined in 
        /// DropdownSetting and then merge it with temoFormula
        /// and returns the effective formula
        /// </summary>
        /// <param name="propertyName"></param>
        /// <param name="tempFormula"></param>
        /// <returns></returns>
        private string PrepareCorrectFormula(string propertyName, string tempFormula)
        {
            logger.EnterMethod("PrepareCorrectFormula");
            logger.LogDebugMessage(string.Format("propertyName: {0},tempFormula: {1}", propertyName, tempFormula));
            string result = String.Empty;
            result =
               _regRangeReplace.Replace(tempFormula.Split(':')[0],
                                        CustomConfigSection.GetListSheetRange(propertyName).Split(':')[0] +
                                        "$") +
               ":" +
               _regRangeReplace.Replace(tempFormula.Split(':')[1],
                                        CustomConfigSection.GetListSheetRange(propertyName).Split(':')[1] +
                                        "$");
            logger.LeaveMethod("PrepareCorrectFormula");
            logger.LogDebugMessage(string.Format("result: {0}", result));
            return result;
        }

        /// <summary>
        /// Read the Worksheet and create the ComboModel 
        /// object which contains the Range formula to fetch 
        /// the data from the "List" sheet
        /// </summary>
        /// <param name="_rangePlanWorksheet"></param>
        /// <returns></returns>
        private CombosModel GetComboFormulas(Worksheet _rangePlanWorksheet)
        {
            logger.EnterMethod("GetComboFormulas");
            var comboModel = new CombosModel();
            var x14ValidationLists = _rangePlanWorksheet.Descendants<x14.DataValidation>()
                        .Where(c => c.Type == DataValidationValues.List);
            DataTable_Formula tempObj = null;
            foreach (var validationItem in x14ValidationLists)
            {
                string[] refSeqs =
                    validationItem.GetFirstChild<ReferenceSequence>()
                                  .InnerText.Split(' ');
                logger.LogDebugMessage(string.Format("refSeqs: {0}", validationItem.GetFirstChild<ReferenceSequence>().InnerText.ToString()));

                foreach (PropertyInfo property in typeof(CombosModel).GetProperties())
                {
                    var cellRef = String.Empty;
                    try
                    {
                        cellRef = CustomConfigSection.ReadColumnReference("List", property.Name);
                        logger.LogDebugMessage(string.Format("cellRef: {0}", cellRef));
                    }
                    catch (Exception exception)
                    {
                        logger.LogException(exception);
                    }
                    int index = Array.IndexOf(refSeqs, cellRef);
                    if (index > -1)
                    {
                        tempObj = new DataTable_Formula();
                        tempObj.formula = validationItem.GetFirstChild<x14.DataValidationForumla1>()
                                                        .ChildElements[0]
                            .InnerText;
                        logger.LogDebugMessage(string.Format("tempObj.formula: {0}", tempObj.formula.ToString()));

                        tempObj.formula = PrepareCorrectFormula(property.Name, tempObj.formula);
                        comboModel
                            .GetType()
                            .GetProperty(property.Name)
                            .SetValue(comboModel,
                                      tempObj);
                        logger.LogDebugMessage(string.Format("tempObj.formula PrepareCorrectFormula: {0}", tempObj.formula.ToString()));
                    }
                    else
                    {
                        var filterRefSeqs = refSeqs.Where(c => c.IndexOf(":") > 1).ToArray();
                        logger.LogDebugMessage(string.Format("filterRefSeqs: {0}", filterRefSeqs.ToString()));

                        if (filterRefSeqs.Length > 0)
                        {
                            string cellRefRow = cellRef.Substring(cellRef.Length - 1);
                            logger.LogDebugMessage(string.Format("cellRefRow: {0}", cellRefRow));

                            foreach (string seq in filterRefSeqs)
                            {
                                var groups = _regRightValidation.Match(seq).Groups;
                                
                                int initIndex = RangePlan.RangePlanProcessing.GetCellIndex(groups[1].Value);
                                int midIndex = RangePlan.RangePlanProcessing.GetCellIndex(cellRef.Substring(0, cellRef.Length - 1));
                                int endIndex = RangePlan.RangePlanProcessing.GetCellIndex(groups[3].Value);

                                if ((initIndex<=midIndex)&&(midIndex<=endIndex))
                                {
                                    if ((int.Parse(groups[2].Value) <= int.Parse(cellRefRow))
                                        && (int.Parse(cellRefRow) <= int.Parse(groups[4].Value)))
                                    {
                                        tempObj = new DataTable_Formula();
                                        tempObj.formula = validationItem.GetFirstChild<x14.DataValidationForumla1>()
                                                                        .ChildElements[0]
                                            .InnerText;
                                        logger.LogDebugMessage(string.Format("tempObj.formula: {0}", tempObj.formula.ToString()));

                                        try
                                        {
                                            tempObj.formula = PrepareCorrectFormula(property.Name, tempObj.formula);
                                        }
                                        catch (IndexOutOfRangeException)
                                        {
                                            logger.LogError(string.Format("Cell [{0}] has wrong formula({1}). Please correct it.", cellRef, tempObj.formula));
                                            throw new Exception(string.Format("Cell [{0}] has wrong formula({1}).  Please correct it.",cellRef, tempObj.formula));
                                        }
                                        comboModel
                                            .GetType()
                                            .GetProperty(property.Name)
                                            .SetValue(comboModel, tempObj);
                                        logger.LogDebugMessage(string.Format("tempObj.formula PrePareCorrectFormula: {0}", tempObj.formula.ToString()));
                                    }
                                }
                            }
                        }
                    }
                }
            }
            logger.LeaveMethod("GetComboFormulas");
            return comboModel;
        }
    }
}

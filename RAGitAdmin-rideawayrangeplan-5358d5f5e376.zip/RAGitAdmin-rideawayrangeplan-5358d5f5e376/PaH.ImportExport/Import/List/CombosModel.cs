﻿using System.Data;

namespace PaH.ImportExport.Import.List
{
    /// <summary>
    /// A class can hold Dropdown Formula and DataTable.
    /// </summary>
    public class DataTable_Formula
    {
        public string formula { get; set; }
        public DataTable DataTable { get; set; }
    }

    /// <summary>
    /// a Class for All Combos of DataTable_Formula type
    /// </summary>
    public class CombosModel
    {
        public DataTable_Formula NewRi { get; set; }
        public DataTable_Formula SubCategory { get; set; }
        public DataTable_Formula Gender { get; set; }
        public DataTable_Formula Age { get; set; }
        public DataTable_Formula MainColour { get; set; }
        public DataTable_Formula Vat { get; set; }
        public DataTable_Formula BuyingCaseSize { get; set; }
        public DataTable_Formula CoreSeasonalRange { get; set; }
        public DataTable_Formula ExclusiveToRa { get; set; }
        public DataTable_Formula Outlet { get; set; }
        public DataTable_Formula WebCategory { get; set; }
        public DataTable_Formula DualWebCategory { get; set; }
        public DataTable_Formula SubCatelogueCategory { get; set; }
        public DataTable_Formula Gbb { get; set; }
        public DataTable_Formula NewFlash { get; set; }
        public DataTable_Formula HeroProduct { get; set; }
        public DataTable_Formula NewImageReq { get; set; }
        public DataTable_Formula Shot { get; set; }
        public DataTable_Formula SupplierPhotoMandatory { get; set; }
        public DataTable_Formula SizeOptionChartReq { get; set; }
        public DataTable_Formula ProductCategory { get; set; }
        public DataTable_Formula FreeCode7 { get; set; }
        public DataTable_Formula Status { get; set; }
        public DataTable_Formula DropdownDefiningAtt1 { get; set; }
        public DataTable_Formula DropdownDefiningAtt2 { get; set; }
        public DataTable_Formula DeliveryOption { get; set; }
        public DataTable_Formula ClickAndCollect { get; set; }
        public DataTable_Formula FoodNonFood { get; set; }

        // Combo from RangePlan header
        public DataTable_Formula Supplier { get; set; }
    }
}

﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using ClosedXML.Excel;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using PaH.BL.Repository;
using PaH.ImportExport.ImportExportConfig;
using DataTable = System.Data.DataTable;
using NumberingFormat = DocumentFormat.OpenXml.Spreadsheet.NumberingFormat;
using Log4NetLibrary;
using System.Transactions;
using System.Configuration;
using PaH.UiModel.Resources;

namespace PaH.ImportExport.Import.RangePlan
{
    /// <summary>
    /// Range Plan import processing.
    /// </summary>
    public class RangePlanProcessing
    {
        // Create logger object.
        ILogService logger = new FileLogService(typeof(RangePlanProcessing));

        /*
        *  change to provide the dynamic feature for PacketSize
        */
        public bool overwritePacketSize;

        /*
         * changes becuase of overwriting the RangePlan sheet data
         */
        public bool overwriteRangePlanData;

        private readonly string _fileName;
        static Regex regCellIndex = new Regex("([a-zA-Z]+)([0-9]+)");
        public RangePlanProcessing(string fileName)
        {
            logger.EnterMethod("RangePlanProcessing");

            _fileName = fileName;

            logger.LogDebugMessage(string.Format("_fileName: {0}", _fileName));
            logger.LeaveMethod("RangePlanProcessing");
        }

        /// <summary>
        /// Read the passing in excel file and import 
        /// the whole rangePlan data into DataBase from the Excelsheet selected
        /// </summary>
        /// <param name="repository"></param>
        /// <param name="loggedInUser"></param>        
        /// <param name="successResult"></param>
        /// <param name="failurResult"></param>
        public void InsertRangePlanInDB(IRepository repository, string loggedInUser, ref string successResult, ref string failurResult)
        {
            logger.EnterMethod("InsertRangePlanInDB");
            Int64 rows = 0;
            Int64 columns = 0;
            using (XLWorkbook workbook = new XLWorkbook(_fileName))
            {
                var worksheet = workbook.Worksheet(CustomConfigSection.SheetName("RangePlan"));
                logger.LogDebugMessage(string.Format("worksheet Name: {0}", worksheet.Name));

                int rowsCount = worksheet.RangeUsed().RowCount();
                string columnRange = CustomConfigSection.GetRangePlanSheetRange("RangePlan");
                logger.LogDebugMessage(string.Format("columnRange: {0}", columnRange));

                string effectiveRange = columnRange.Split(':')[0] + "1" + ":" + columnRange.Split(':')[1] + rowsCount;
                logger.LogDebugMessage(string.Format("{0}", effectiveRange));

                var range = worksheet.Range(effectiveRange);
                rows = range.RowCount();
                logger.LogDebugMessage(string.Format("Rows Count {0}", rows.ToString()));

                columns = range.ColumnCount();
                logger.LogDebugMessage(string.Format("Columns Count {0}", columns.ToString()));
            }
            DataTable datatable = GetDatatableFromRangePlan(rows, columns);
            string errorMessage = string.Empty;            
            int recordInsertUpdate = ExecuteSP("RangePlan", datatable, repository, loggedInUser, ref errorMessage, ref successResult);
            if (errorMessage == string.Empty)
            {
                successResult += recordInsertUpdate + " records Inserted/Updated in RangePlan.\n";
            }
            else
            {
                failurResult += errorMessage;
            }
            logger.LogDebugMessage(string.Format("returnMessage: Success-{0},Failure-{1}", successResult, failurResult));

            // Is below statement required??
            //int row = datatable.Rows.Count;
            logger.LeaveMethod("InsertRangePlanInDB");
        }

        /// <summary>
        /// Execute the Stored procedure to Insert the RangePlan in to Database. 
        /// and returns the count of rows inserted or modified.
        /// </summary>
        /// <param name="propertyName"></param>
        /// <param name="dt"></param>
        /// <param name="repository"></param>
        /// <param name="loggedInUser"></param>
        /// <returns></returns>
        private int ExecuteSP(string propertyName, DataTable dt, IRepository repository, string loggedInUser, ref string errorMessage, ref string successresult)
        {
            logger.EnterMethod("ExecuteSP");
            int result = 0;
            using (TransactionScope trans = new TransactionScope())
            {
                /*
                 * changes becuase of overwriting the RangePlan sheet data
                 */
                if (overwriteRangePlanData)
                {
                    var a = dt.Columns[CustomConfigSection.ReadColumnReference("RangePlan", "RaProductCode")];
                    DataTable dtForDelete = new DataTable();
                    dtForDelete.Columns.Add(new DataColumn());

                    var rowCollection = from r in dt.AsEnumerable()
                                        select dtForDelete.Rows.Add(dtForDelete.NewRow()[0] = r.Field<string>(CustomConfigSection.ReadColumnReference("RangePlan", "RaProductCode")));
                    dtForDelete = rowCollection.Cast<DataRow>().CopyToDataTable();

                    var dataTable = new SqlParameter
                    {
                        ParameterName = "Dump",
                        TypeName = "Delete_Before_List_RangePlan",
                        Value = dtForDelete
                    };

                    int recordDeleted = repository.ExecuteSqlQuery(@"exec Delete_Before_Dump_RangePlan @Dump", ref errorMessage, dataTable);
                    successresult += recordDeleted + " records deleted in RangePlan.\n";
                }

                int packateSize;
                if (overwritePacketSize)
                {
                    packateSize = 1;
                }
                else
                {
                    if (!int.TryParse(ConfigurationManager.AppSettings["RangePlanImportPacketSize"], out packateSize))
                    {
                        packateSize = 100;
                    }
                }       

                int possiblePacket = (dt.Rows.Count / packateSize);
                if (dt.Rows.Count % packateSize != 0)
                {
                    possiblePacket++;
                }
                int currentIndex = 0;
                for (currentIndex = 0; currentIndex < possiblePacket; currentIndex++)
                {
                    var dataTable = new SqlParameter
                            {
                                ParameterName = "Dump",
                                TypeName = StoredProcedureAndTypeSetting.AllEntities[propertyName].SqlCustomDataType,
                                Value = dt.Rows.Cast<DataRow>().Skip(currentIndex * packateSize).Take(packateSize).CopyToDataTable()
                            };
                    var user = new SqlParameter
                    {
                        ParameterName = "User",
                        Value = loggedInUser
                    };
                    logger.LogDebugMessage(string.Format("dataTable.ParameterName: {0}, dataTable.TypeName: {1},dataTable.Value {2} user.ParameterName: {3}, user.Value: {4}", dataTable.ParameterName, dataTable.TypeName, dataTable.Value.ToString(), user.ParameterName, user.Value));

                    // substract 2 - log table entry
                    result += (repository.ExecuteSqlQuery(@"" +
                                                              "exec " + StoredProcedureAndTypeSetting.AllEntities[propertyName].SPName +
                                                             " @Dump, @User", ref errorMessage,
                                                              dataTable, user)) -2 ;
                    if (errorMessage != string.Empty)
                    {
                        if (errorMessage.IndexOf("IX_RaProductCodeIndexing") == -1)
                        {
                            if ((packateSize == 1))
                            {
                                errorMessage += "\n\n" + string.Format(Message_Resource.Message_CheckRaProductCode, (dataTable.Value as DataTable).Rows[0]["G"]);
                            }
                            else
                            {
                                errorMessage += "\n\n" + string.Format(Message_Resource.Message_CheckRaProductCodeRange, (dataTable.Value as DataTable).Rows[0]["G"], (dataTable.Value as DataTable).Rows[packateSize - 1]["G"]);
                            }
                        }
                        break;
                    }
                }
                //if all the packets sent successfully.. :)
                if (currentIndex == possiblePacket)
                {
                    trans.Complete();                    
                }
                logger.LogDebugMessage(string.Format("result: {0} errorMessage: {1} currentIndex: {2}", result, errorMessage, currentIndex));
            }
            logger.LeaveMethod("ExecuteSP");
            return result;
        }

        /// <summary>
        /// Took the help from OpenXml to read the cell's value having shared string , vlookup,
        /// percentage and others
        /// </summary>
        /// <param name="sst"></param>
        /// <param name="cell"></param>
        /// <param name="stylesheet"></param>
        /// <returns></returns>
        private string GetCellValueOpenXml(SharedStringTable sst, Cell cell, Stylesheet stylesheet)
        {
            logger.EnterMethod("GetCellValueOpenXml");
            string result = String.Empty;
            if ((cell.DataType != null) && (cell.DataType == CellValues.SharedString))
            {
                int ssid = int.Parse(cell.CellValue.Text);
                string str = sst.ChildElements[ssid].InnerText;
                result = str;
                logger.LogDebugMessage(string.Format("result when Cell.DataType is not null {0}", result));
            }
            else if (cell.CellValue != null)
            {
                result = cell.CellValue.Text;
                logger.LogDebugMessage(string.Format("result when Cell.CellValue is not null {0}", result));
            }
            if ((result != String.Empty) && (IsOfPercentageType(cell, stylesheet)))
            {
                result = (decimal.Parse(result, System.Globalization.NumberStyles.Any) * 100).ToString();
                logger.LogDebugMessage(string.Format("result when Cell is Percentage type {0}", result));
            }
            if ((CustomConfigSection.ReadColumnReference("RangePlan", "RaSubSubCategory") == regCellIndex.Match(cell.CellReference.Value).Groups[1].Value)
                ||
                (CustomConfigSection.ReadColumnReference("RangePlan", "StockedDD") == regCellIndex.Match(cell.CellReference.Value).Groups[1].Value))
            {
                if (result == "0")
                {
                    result = String.Empty;
                }
                logger.LogDebugMessage(string.Format("result when Cell is {1}: {0}", result, regCellIndex.Match(cell.CellReference.Value).Groups[1].Value));
            }
            logger.LogDebugMessage(string.Format("returned result: {0}", result));
            logger.LeaveMethod("GetCellValueOpenXml");
            return result;
        }

        /// <summary>
        /// check if cell is formatted as Percantage(%)
        /// </summary>
        /// <param name="cell"></param>
        /// <param name="stylesheet"></param>
        /// <returns></returns>
        public static bool IsOfPercentageType(Cell cell, Stylesheet stylesheet)
        {
            bool result = false;
            var s = cell.StyleIndex;
            if (s != null)
            {
                var numFmtId = stylesheet.CellFormats.Descendants<CellFormat>().ElementAt(((int)((UInt16)s))).NumberFormatId;
                if (numFmtId > 0)
                {
                    // 9 and 10 it reserved for x% and x.xx% 
                    if (numFmtId == UInt16.Parse("10") || numFmtId == UInt16.Parse("9"))
                    {
                        result = true;
                    }
                    else
                    {
                        var numberingFormat = stylesheet.NumberingFormats.Descendants<NumberingFormat>()
                                  .Where(c => c.NumberFormatId.Value == numFmtId.Value);
                        if (numberingFormat.Count() == 1)
                        {
                            string formatCode = numberingFormat.ElementAt(0).FormatCode.Value;
                            if (formatCode.IndexOf("%") > -1)
                            {
                                result = true;
                            }
                        }
                    }
                }
            }
            return result;
        }

        /// <summary>
        /// get the DataTable from the RangePlan sheet
        /// </summary>
        /// <param name="rowCount"></param>
        /// <param name="columnCount"></param>
        /// <returns></returns>
        private DataTable GetDatatableFromRangePlan(long rowCount, long columnCount)
        {
            logger.EnterMethod("GetDatatableFromRangePlan");
            DataTable result = new DataTable();
            if (rowCount > 0)
            {
                for (int i = 0; i < columnCount; i++)
                {
                    result.Columns.Add(new DataColumn(GetCellReferenceZeroBased(i)));
                }
                DataRow tempRow = null;
                try
                {
                    using (FileStream fs = new FileStream(_fileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                    {
                        using (SpreadsheetDocument doc = SpreadsheetDocument.Open(fs, false))
                        {
                            WorkbookPart workbookPart = doc.WorkbookPart;
                            SharedStringTablePart sstpart = workbookPart.GetPartsOfType<SharedStringTablePart>().First();
                            SharedStringTable sst = sstpart.SharedStringTable;
                            Stylesheet stylesheet = workbookPart.WorkbookStylesPart.Stylesheet;

                            var sheet_ = workbookPart.Workbook.Descendants<Sheet>().First(c => c.Name == CustomConfigSection.SheetName("RangePlan"));
                            var worksheet_part = (WorksheetPart)workbookPart.GetPartById(sheet_.Id);
                            logger.LogDebugMessage(string.Format("sheet_.Id: {0}", sheet_.Id));
                            var sheet = worksheet_part.Worksheet;

                            //rowIndex > 4  because data starts at 5th row
                            var rows = sheet.Descendants<Row>().Where(r => r.RowIndex > 4 && r.RowIndex < rowCount + 1);
                            foreach (var row in rows)
                            {
                                tempRow = result.NewRow();
                                int spreadsheetCellIndex = 0;
                                Cell cell;
                                var columns = row.Descendants<Cell>().Where(c => GetCellIndex(c) <= columnCount).ToList();
                                for (int i = 0; i < result.Columns.Count; i++)
                                {
                                    if (columns.Count > spreadsheetCellIndex)
                                    {
                                        cell = columns[spreadsheetCellIndex];
                                        if (GetCellIndex(regCellIndex.Match(cell.CellReference.Value).Groups[1].Value) == i + 1)
                                        {
                                            tempRow[i] = GetCellValueOpenXml(sst, cell, stylesheet);
                                            spreadsheetCellIndex++;
                                            continue;
                                        }
                                    }
                                    tempRow[i] = "";
                                }

                                logger.LogDebugMessage(string.Format("tempRow [0]", string.Join("<~>", tempRow.ItemArray)));
                                if (!NeedToExcludeRow(tempRow))
                                {
                                    result.Rows.Add(tempRow);
                                }
                            }
                        }
                    }
                }
                catch (Exception exception)
                {
                    logger.LogException(exception);
                    throw;
                }
            }
            //logger.LogDebugMessage(string.Format("{0}",result.))
            logger.LeaveMethod("GetDatatableFromRangePlan");
            //remove the duplicate
            return result.DefaultView.Table;
        }


        internal static int GetCellIndex(Cell cell)
        {
            int result = 0;
            string cellValue = regCellIndex.Match(cell.CellReference.Value).Groups[1].Value;
            cellValue = cellValue.ToUpper();
            //this.logger.LogDebugMessage(string.Format("Entered GetCellIndex using cellValue: {0}", cellValue));

            result = GetCellIndex(cellValue);
            //logger.LogDebugMessage(string.Format("Leaving GetCellIndex result: {0}", result));

            return result;
        }

        internal static int GetCellIndex(string cellRef)
        {
            int lInt = 0;
            if (cellRef.Length == 0)
            {
                lInt = 0;
            }
            else
            {
                char firstChar = cellRef[cellRef.Length - 1];
                lInt = ((int)firstChar - (int)'A' + 1) + GetCellIndex(cellRef.Substring(0, cellRef.Length - 1)) * 26;
            }
            //logger.LogDebugMessage(string.Format("GetCellIndex using cellRef: {0}", lInt.ToString()));
            return lInt;
        }

        internal static string GetCellReferenceZeroBased(int index)
        {
            if (index < 26)
            {
                return ((char)(index + (int)'A')).ToString();
            }
            return GetCellReferenceZeroBased((index / 26) - 1) + GetCellReferenceZeroBased(index % 26);
        }

        /// <summary>
        /// To exclude few Rows or Fully Table if not required
        /// or duplicate or few to some conditions
        /// </summary>
        /// <param name="propertyName"></param>
        /// <param name="tempFormula"></param>
        /// <returns></returns>
        private bool NeedToExcludeRow(DataRow tempRow)
        {
            logger.EnterMethod("NeedToExcludeRow");

            //if RaProductCode is blank
            string columnRef = CustomConfigSection.ReadColumnReference("RangePlan", "RaProductCode");
            string supplierRef = CustomConfigSection.ReadColumnReference("RangePlan", "Supplier");
            if ((tempRow[columnRef].ToString() == string.Empty) || (tempRow[supplierRef].ToString() == string.Empty))
            {
                logger.LeaveMethod("NeedToExcludeRow");
                return true;
            }
            return false;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using Log4NetLibrary;

namespace PaH.ImportExport.Import
{
    /// <summary>
    /// Representation of one
    /// Model or RangePlan
    /// </summary>
    public class OneEntity
    {
        //Create Logger object
        ILogService logger = new FileLogService(typeof(OneEntity));

        public OneEntity()
        {
        }

        public string SPName { get; set; }
        public string SqlCustomDataType { get; set; }
        //public string tableName { get; set; }

        /// <summary>
        /// set the Stored Procedure name we created for
        /// particular property
        /// </summary>
        /// <param name="expression"></param>
        /// <returns></returns>
        public OneEntity setSPName(Expression<Func<PaHDefined.SP, string>> expression)
        {
            logger.EnterMethod("setSPName");
            var property = (expression.Body as MemberExpression);
            if (property != null)
            {
                //tableName = SPName = property.Member.Name;                
                SPName = property.Member.Name;
                logger.LogDebugMessage(string.Format("SPName: {0}", SPName));
            }
            logger.LeaveMethod("setSPName");
            return this;
        }

        /// <summary>
        /// set the customSqlDataType we created for particular Property
        /// </summary>
        /// <param name="expression"></param>
        /// <returns></returns>
        public OneEntity setSqlCustomDataType(Expression<Func<PaHDefined.SqlDataType, string>> expression)
        {
            logger.EnterMethod("setSqlCustomDataType");
            var property = (expression.Body as MemberExpression);
            if (property != null)
            {
                SqlCustomDataType = property.Member.Name;
            }
            logger.LogDebugMessage(string.Format("SqlCustomDataType: {0}", SqlCustomDataType));
            logger.LeaveMethod("setSqlCustomDataType");
            return this;
        }
    }

    /// <summary>
    /// static class containing the mapping of CustomDataType and SP for Combo and 
    /// RangePlan
    /// </summary>
    public static class StoredProcedureAndTypeSetting
    {
        public static Dictionary<string, OneEntity> AllEntities = new Dictionary<string, OneEntity>();
        static StoredProcedureAndTypeSetting()
        {
            AllEntities["NewRi"] = new OneEntity()
                .setSqlCustomDataType(c => c.List_NewRI)
                .setSPName(c => c.Dump_NewRI);

            AllEntities["SubCategory"] = new OneEntity()
                .setSqlCustomDataType(c => c.List_RaCategory)
                .setSPName(c => c.Dump_RaCategory);

            AllEntities["Gender"] = new OneEntity()
                .setSqlCustomDataType(c => c.List_Gender)
                .setSPName(c => c.Dump_Gender);

            AllEntities["Age"] = new OneEntity()
                .setSqlCustomDataType(c => c.List_Age)
                .setSPName(c => c.Dump_Age);

            AllEntities["MainColour"] = new OneEntity()
                .setSqlCustomDataType(c => c.List_MainColour)
                .setSPName(c => c.Dump_MainColour);

            AllEntities["Vat"] = new OneEntity()
                .setSqlCustomDataType(c => c.List_VAT)
                .setSPName(c => c.Dump_VAT);

            AllEntities["BuyingCaseSize"] = new OneEntity()
                .setSqlCustomDataType(c => c.List_PackSize)
                .setSPName(c => c.Dump_PackSize);

            AllEntities["CoreSeasonalRange"] = new OneEntity()
                .setSqlCustomDataType(c => c.List_CoreSeasonalRange)
                .setSPName(c => c.Dump_CoreSeasonalRange);

            AllEntities["ExclusiveToRa"] = new OneEntity()
                .setSqlCustomDataType(c => c.List_YesNo)
                .setSPName(c => c.Dump_YesNo);

            AllEntities["Outlet"] = new OneEntity()
                .setSqlCustomDataType(c => c.List_Outlet)
                .setSPName(c => c.Dump_Outlet);

            AllEntities["WebCategory"] = new OneEntity()
                .setSqlCustomDataType(c => c.List_WebCategory)
                .setSPName(c => c.Dump_WebCategory);

            AllEntities["DualWebCategory"] = new OneEntity()
                .setSqlCustomDataType(c => c.List_WebCategory)
                .setSPName(c => c.Dump_WebCategory);

            AllEntities["SubCatelogueCategory"] = new OneEntity()
                .setSqlCustomDataType(c => c.List_CatalogueCategory)
                .setSPName(c => c.Dump_CatalogueCategory);

            AllEntities["Gbb"] = new OneEntity()
                .setSqlCustomDataType(c => c.List_GBB)
                .setSPName(c => c.Dump_GBB);

            AllEntities["NewFlash"] = new OneEntity()
                .setSqlCustomDataType(c => c.List_YesNo)
                .setSPName(c => c.Dump_YesNo);

            AllEntities["HeroProduct"] = new OneEntity()
                .setSqlCustomDataType(c => c.List_YesNo)
                .setSPName(c => c.Dump_YesNo);

            AllEntities["NewImageReq"] = new OneEntity()
                .setSqlCustomDataType(c => c.List_YesNo)
                .setSPName(c => c.Dump_YesNo);

            AllEntities["Shot"] = new OneEntity()
                .setSqlCustomDataType(c => c.List_Shot)
                .setSPName(c => c.Dump_Shot);

            AllEntities["SupplierPhotoMandatory"] = new OneEntity()
                .setSqlCustomDataType(c => c.List_YesNo)
                .setSPName(c => c.Dump_YesNo);

            AllEntities["SizeOptionChartReq"] = new OneEntity()
                .setSqlCustomDataType(c => c.List_YesNo)
                .setSPName(c => c.Dump_YesNo);

            AllEntities["ProductCategory"] = new OneEntity()
            .setSqlCustomDataType(c => c.List_ProductCategory)
                .setSPName(c => c.Dump_ProductCategory);

            AllEntities["FreeCode7"] = new OneEntity()
                .setSqlCustomDataType(c => c.List_YesNo)
                .setSPName(c => c.Dump_YesNo);

            AllEntities["Status"] = new OneEntity()
                .setSqlCustomDataType(c => c.List_Status)
                .setSPName(c => c.Dump_Status);

            AllEntities["DropdownDefiningAtt1"] = new OneEntity()
                .setSqlCustomDataType(c => c.List_DropDownDefiningAttribute)
                .setSPName(c => c.Dump_DropDownDefiningAttribute);


            AllEntities["DropdownDefiningAtt2"] = new OneEntity()
                .setSqlCustomDataType(c => c.List_DropDownDefiningAttribute)
                .setSPName(c => c.Dump_DropDownDefiningAttribute);

            AllEntities["DeliveryOption"] = new OneEntity()
            .setSqlCustomDataType(c => c.List_DeliveryOption)
                .setSPName(c => c.Dump_DeliveryOption);

            AllEntities["ClickAndCollect"] = new OneEntity()
            .setSqlCustomDataType(c => c.List_YesNo)
                .setSPName(c => c.Dump_YesNo);

            AllEntities["FoodNonFood"] = new OneEntity()
                .setSqlCustomDataType(c => c.List_FoodNonFood)
                .setSPName(c => c.Dump_FoodNonFood);

            // Combo from RangePlan header
            AllEntities["Supplier"] = new OneEntity()
                .setSqlCustomDataType(c => c.List_Supplier)
                .setSPName(c => c.Dump_Supplier);

            AllEntities["RangePlan"] = new OneEntity()
                .setSqlCustomDataType(c => c.List_RangePlan)
                .setSPName(c => c.Dump_RangePlan);
        }
    }
}
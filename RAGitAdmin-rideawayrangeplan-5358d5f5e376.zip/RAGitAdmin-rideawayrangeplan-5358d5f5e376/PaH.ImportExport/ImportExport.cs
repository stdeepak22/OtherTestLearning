﻿using System;
using System.Collections.Generic;
using System.IO;
using PaH.BL.Repository;
using PaH.ImportExport.Export;
using PaH.ImportExport.Import.List;
using PaH.ImportExport.Import.RangePlan;
using Log4NetLibrary;

namespace PaH.ImportExport
{
    /// <summary>
    /// Class for whole ImportExport operations
    /// </summary>
    public class ImportExport : IDisposable
    {
        ILogService logger = new FileLogService(typeof(ImportExport));
        private readonly string _fileName = String.Empty;
        private string _loggedInUser;
        private static readonly object ExportLock = new object();

        /// <summary>
        /// A Class to perform import/export operation
        /// Constructor takes fileName as string type
        /// </summary>
        /// <param name="filePath"></param>
        public ImportExport(string filePath)
        {
            logger.EnterMethod("ImportExport");
            _fileName = filePath;
            logger.LogDebugMessage(string.Format("_fileName: {0}", _fileName));
            logger.LeaveMethod("ImportExport");
        }

        /// <summary>
        /// Import method import the data from List and Range Plan
        /// sheet to database, we need to pass DbContext of the Database
        /// and Logged in User for logging purpose
        /// </summary>
        /// <param name="importComboData"></param>
        /// <param name="importRangePlanData"></param>
        /// <param name="repository"></param>
        /// <param name="loggedInUser"></param>
        public string[] Import(bool importComboData, bool importRangePlanData, IRepository repository, string loggedInUser, bool overwritePacketSize, bool overwriteRangePlanData)
        {
            logger.EnterMethod("Import");
            string successResult = String.Empty;
            string failurResult = String.Empty;
            _loggedInUser = loggedInUser;
            logger.LogDebugMessage(string.Format("_loggedInUser: {0},importComboData: {1},importRangePlanData {2}", _loggedInUser, importComboData, importRangePlanData));

            if (importComboData)
            {
                var comboProcessing = new ComboProcessing(_fileName);
                comboProcessing.InsertComboInDB(repository, loggedInUser, ref successResult, ref failurResult);                
            }
            if (importRangePlanData)
            {
                var rangePlan = new RangePlanProcessing(_fileName);
                rangePlan.overwritePacketSize = overwritePacketSize;
                rangePlan.overwriteRangePlanData = overwriteRangePlanData;

                rangePlan.InsertRangePlanInDB(repository, loggedInUser, ref successResult, ref failurResult);
            }
            logger.LogDebugMessage(string.Format("result: Success-{0}, Failure-{1}", successResult,failurResult));
            logger.LeaveMethod("Import");
            return new[]{successResult, failurResult};
        }

        /// <summary>
        /// Export Method -- to export the 3 types of report on rangePlan
        /// RangePlan, Create and Hanger7.  Takes list of GridFilter applied on GridMVC - extracted from QueryString
        /// Repository Object and Report Type
        /// </summary>
        /// <param name="filters"></param>
        /// <param name="repository"></param>
        /// <param name="reportType"></param>
        /// <returns></returns>
        public Stream Export(List<GridFilter> filters, IRepository repository, ReportType reportType)
        {
            logger.EnterMethod("Export");
            try
            {
                logger.LeaveMethod("Export");
                return new ExportReport().GetDownloadFileStream(filters, repository, reportType);
            }
            catch (Exception exception)
            {
                logger.LogException(exception);
                throw;
            }
        }

        /// <summary>
        /// because Implementing the IDisposible interface.
        /// </summary>
        public void Dispose()
        {
            logger.EnterMethod("Dispose");
            logger.LeaveMethod("Dispose");
        }
    }
}

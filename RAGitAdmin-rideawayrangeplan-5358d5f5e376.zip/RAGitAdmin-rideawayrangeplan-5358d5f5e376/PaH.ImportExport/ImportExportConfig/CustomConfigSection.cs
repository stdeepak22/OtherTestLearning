﻿using System;
using System.Configuration;
using System.Linq;
using PaH.UiModel.Resources;

namespace PaH.ImportExport.ImportExportConfig
{
    /// <summary>
    /// to read the Configuration defined inside the .config file for
    /// list and RangePlan (List.config & RangePlan.config)
    /// </summary>
    public class CustomConfigSection
    {
        /// <summary>
        /// representing the Top root node in Config file.
        /// returns the SheetName for passed in Section
        /// </summary>
        /// <param name="sectionName"></param>
        /// <returns></returns>
        public static string SheetName(string sectionName)
        {
            ImportExportConfigSectionSection section = null;

            try
            {
                section = ConfigurationManager.GetSection(sectionName)
                        as ImportExportConfigSectionSection;
            }
            catch (ConfigurationErrorsException)
            {
                throw;
            }

            if (section != null)
            {
                return section.SheetName;
            }
            else
            {
                throw new Exception(Message_Resource.Message_CustomConfigSection_Exception);
            }
        }

        /// <summary>
        /// Get the Range specified in Config file for particular property in case of List
        /// </summary>
        /// <param name="propertyName"></param>
        /// <param name="sectionName"></param>
        /// <returns></returns>
        public static string GetListSheetRange(string propertyName, string sectionName = "List")
        {
            ImportExportConfigSectionSection section = null;

            try
            {
                section = ConfigurationManager.GetSection(sectionName)
                        as ImportExportConfigSectionSection;
            }
            catch (ConfigurationErrorsException)
            {
                throw;
            }

            if (section != null)
            {
                var property =
                    section.PropertyCellCollection.Cast<PropertyCell>().First(
                        c => c.PropertyName == propertyName);
                if (property != null)
                {
                    return property.ListSheetRange;
                }
                else
                {
                    throw new Exception("Property[" + propertyName + "] not found under section name=[" + sectionName + "].  Please check the configuration file.");
                }
            }
            else
            {
                throw new Exception(Message_Resource.Message_CustomConfigSection_Exception);
            }
        }

        /// <summary>
        /// Get the Range specified in Config file for RangePlan section
        /// </summary>
        /// <param name="sectionName"></param>
        /// <returns></returns>
        public static string GetRangePlanSheetRange(string sectionName = "RangePlan")
        {
            ImportExportConfigSectionSection section = null;

            try
            {
                section = ConfigurationManager.GetSection(sectionName)
                        as ImportExportConfigSectionSection;
            }
            catch (ConfigurationErrorsException)
            {
                throw;
            }

            if (section != null)
            {
                return section.RangePlanSheetRange;
            }
            else
            {
                throw new Exception(Message_Resource.Message_CustomConfigSection_Exception);
            }
        }

        /// <summary>
        /// Get the ColoumnReference in Excel sheet specified in config file
        /// </summary>
        /// <param name="sectionName"></param>
        /// <param name="propertyName"></param>
        /// <returns></returns>
        public static string ReadColumnReference(string sectionName, string propertyName)
        {
            ImportExportConfigSectionSection section = null;

            try
            {
                section = ConfigurationManager.GetSection(sectionName)
                        as ImportExportConfigSectionSection;
            }
            catch (ConfigurationErrorsException)
            {
                throw;
            }

            if (section != null)
            {
                var property =
                    section.PropertyCellCollection.Cast<PropertyCell>().First(
                        c => c.PropertyName == propertyName);
                if (property != null)
                {
                    return property.ColumnReference;
                }
                else
                {
                    throw new Exception("Property[" + propertyName + "] not found under section name=[" + sectionName + "].  Please check the configuration file.");
                }
            }
            else
            {
                throw new Exception(Message_Resource.Message_CustomConfigSection_Exception);
            }
        }
    }
}

﻿using System.Configuration;
using Log4NetLibrary;

namespace PaH.ImportExport.ImportExportConfig
{
    /// <summary>
    /// to read the CustomConfig section defined inside the config files.
    /// </summary>
    public class ImportExportConfigSectionSection : ConfigurationSection
    {
        ILogService logger = new FileLogService(typeof(ImportExportConfigSectionSection));
        /// <summary>
        /// The name of this section in the app.config.
        /// </summary>        
        private const string propertyCellCollection = "PropertyCellCollection";

        [ConfigurationProperty(propertyCellCollection)]
        [ConfigurationCollection(typeof(PropertyCellCollection), AddItemName = "add")]
        public PropertyCellCollection PropertyCellCollection { get { return (PropertyCellCollection)base[propertyCellCollection]; } }

        /// <summary>
        /// Get the SheetName from the config section inside the config file
        /// </summary>
        [ConfigurationProperty("sheetName", IsKey = true, IsRequired = true)]
        public string SheetName
        {
            get
            {
                logger.LogDebugMessage(string.Format("Get Property SheetName: {0}", (string)base["sheetName"]));
                return (string)base["sheetName"];
            }
            set
            {
                base["sheetName"] = value;
                logger.LogDebugMessage(string.Format("Set Property SheetName: {0}", value));
            }
        }
        /// <summary>
        /// Get the RangePlanSheet colum range from the config section inside the config file
        /// </summary>
        [ConfigurationProperty("rangePlanSheetRange", IsRequired = false)]
        public string RangePlanSheetRange
        {
            get
            {
                logger.LogDebugMessage(string.Format("Get Property RangePlanSheetRange: {0}", (string)base["rangePlanSheetRange"]));
                return (string)base["rangePlanSheetRange"];
            }
            set
            {
                base["rangePlanSheetRange"] = value;
                logger.LogDebugMessage(string.Format("Get Property RangePlanSheetRange: {0}", value));
            }
        }
    }
    /// <summary>
    /// PropertyCollection class for Config file multiple sections
    /// </summary>
    public class PropertyCellCollection : ConfigurationElementCollection
    {
        ILogService logger = new FileLogService(typeof(PropertyCellCollection));

        protected override ConfigurationElement CreateNewElement()
        {
            logger.EnterMethod("CreateNewElement");
            return new PropertyCell();
        }

        protected override object GetElementKey(ConfigurationElement element)
        {
            string colReference = ((PropertyCell)element).ColumnReference;
            logger.LogDebugMessage(string.Format("GetElementKey ColumnReference: {0}", colReference));
            return colReference;
        }
    }

    /// <summary>
    /// representing one node inside the custom config files
    /// </summary>
    public class PropertyCell : ConfigurationElement
    {
        ILogService logger = new FileLogService(typeof(PropertyCellCollection));

        [ConfigurationProperty("propertyName", DefaultValue = "PropertyName", IsKey = true, IsRequired = true)]
        public string PropertyName
        {
            get
            {
                logger.LogDebugMessage(string.Format("Get Property PropertyName: {0}", (string)base["propertyName"]));
                return (string)base["propertyName"];
            }
            set
            {
                base["propertyName"] = value;
                logger.LogDebugMessage(string.Format("Set Property propertyName: {0}", value));
            }
        }

        [ConfigurationProperty("columnReference", DefaultValue = "A1", IsKey = false, IsRequired = true)]
        public string ColumnReference
        {
            get
            {
                logger.LogDebugMessage(string.Format("Get Property ColumnReference: {0}", (string)base["columnReference"]));
                return (string)base["columnReference"];
            }
            set
            {
                base["columnReference"] = value;
                logger.LogDebugMessage(string.Format("Set Property ColumnReference: {0}", value));
            }
        }

        [ConfigurationProperty("listSheetRange", IsRequired = false)]
        public string ListSheetRange
        {
            get
            {
                logger.LogDebugMessage(string.Format("Get Property ListSheetRange: {0}", (string)base["listSheetRange"]));
                return (string)base["listSheetRange"];
            }
            set
            {
                base["listSheetRange"] = value;
                logger.LogDebugMessage(string.Format("Set Property ListSheetRange: {0}", value));
            }
        }
    }
}

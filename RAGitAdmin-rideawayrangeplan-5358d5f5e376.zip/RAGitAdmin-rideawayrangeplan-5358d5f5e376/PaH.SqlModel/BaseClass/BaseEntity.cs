﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace PaH.SqlModel.BaseClass
{
    /// <summary>
    /// Base class for all List and Entity types.
    /// Common properties for all List and Entity types.
    /// </summary>
    public class BaseEntity
    {
        public BaseEntity()
        {
            IsEnabled = true;
            IsDeleted = false;
        }

        [Key]
        public int Id { get; set; }

        [Display(Name = "Is Enabled?")]
        public bool IsEnabled { get; set; }

        [Display(Name = " ")]
        public bool IsDeleted { get; set; }

        [Display(Name = " ")]
        [HiddenInput(DisplayValue = false)]
        public DateTime? CreatedOn { get; set; }

        [Display(Name = " ")]
        [HiddenInput(DisplayValue = false)]
        public string CreatedBy { get; set; }

        [Display(Name = " ")]
        [HiddenInput(DisplayValue = false)]
        public DateTime? UpdatedOn { get; set; }

        [Display(Name = " ")]
        [HiddenInput(DisplayValue = false)]
        public string UpdatedBy { get; set; }
    }
}

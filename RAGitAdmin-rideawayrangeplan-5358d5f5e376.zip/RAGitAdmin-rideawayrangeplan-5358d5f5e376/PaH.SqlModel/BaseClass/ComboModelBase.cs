﻿using System.ComponentModel.DataAnnotations;

namespace PaH.SqlModel.BaseClass
{
    /// <summary>
    /// a class derived from BaseEntity
    /// and used as Base entity for List
    /// </summary>
    public class ComboModelBase : BaseEntity
    {
        [MaxLength(1024)]
        [Display(Name = "Notes")]
        public string Description { get; set; }
    }
}

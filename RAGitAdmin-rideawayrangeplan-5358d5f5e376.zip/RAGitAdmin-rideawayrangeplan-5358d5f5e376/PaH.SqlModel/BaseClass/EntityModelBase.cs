﻿namespace PaH.SqlModel.BaseClass
{
    /// <summary>
    /// a class derived from BaseEntity
    /// and used as Base entity for EntityType (e.g. RangePlan)
    /// </summary>
    public class EntityModelBase : BaseEntity
    {
        //public string NotesIfAny { get; set; }
    }
}
 
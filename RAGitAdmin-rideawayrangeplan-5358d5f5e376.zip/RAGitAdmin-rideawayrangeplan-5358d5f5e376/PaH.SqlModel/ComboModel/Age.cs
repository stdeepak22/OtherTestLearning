﻿using System.ComponentModel.DataAnnotations;
using PaH.SqlModel.BaseClass;

namespace PaH.SqlModel.ComboModel
{
    /// <summary>
    /// Sql Model for Age List
    /// </summary>
    public class Age : ComboModelBase
    {
        [Required]
        [StringLength(256)]
        public string Value { get; set; }
    }
}

﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using PaH.SqlModel.BaseClass;

namespace PaH.SqlModel.ComboModel
{
    /// <summary>
    /// Sql Model for Catalogue Category List
    /// </summary>
    public class CatalogueCategory : ComboModelBase
    {
        public CatalogueCategory()
        {
            CatalogueSubCategories = new List<CatalogueSubCategory>();
        }

        [Required]
        [StringLength(256)]
        public string Name { get; set; }

        public virtual IList<CatalogueSubCategory> CatalogueSubCategories { get; set; }
    }
}

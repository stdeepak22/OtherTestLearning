﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using PaH.SqlModel.BaseClass;

namespace PaH.SqlModel.ComboModel
{
    /// <summary>
    /// Sql Model for Catalogue Sub Category List
    /// </summary>
    public class CatalogueSubCategory : ComboModelBase
    {
        [Required]
        [StringLength(256)]
        public string Name { get; set; }

        public virtual int CatalogueCategoryId { get; set; }

        [ForeignKey("CatalogueCategoryId")]
        public virtual CatalogueCategory CatalogueCategory { get; set; }
    }
}

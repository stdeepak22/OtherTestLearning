﻿using System.ComponentModel.DataAnnotations;
using PaH.SqlModel.BaseClass;

namespace PaH.SqlModel.ComboModel
{
    /// <summary>
    /// Sql Model for Core Seasonal Range List
    /// </summary>
    public class CoreSeasonalRange : ComboModelBase
    {
        [Required]
        [StringLength(256)]
        public string Name { get; set; }
    }
}

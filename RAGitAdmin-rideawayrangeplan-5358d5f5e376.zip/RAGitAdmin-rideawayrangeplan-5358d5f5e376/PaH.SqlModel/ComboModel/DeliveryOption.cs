﻿using System.ComponentModel.DataAnnotations;
using PaH.SqlModel.BaseClass;

namespace PaH.SqlModel.ComboModel
{
    /// <summary>
    /// Sql Model for Delivery Options List
    /// </summary>
    public class DeliveryOption : ComboModelBase
    {
        [Required]
        [StringLength(1024)]
        public string Option { get; set; }
    }
}

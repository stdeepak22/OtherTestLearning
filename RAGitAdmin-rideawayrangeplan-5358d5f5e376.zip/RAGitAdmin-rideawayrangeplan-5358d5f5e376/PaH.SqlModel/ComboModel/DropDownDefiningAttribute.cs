﻿using System.ComponentModel.DataAnnotations;
using PaH.SqlModel.BaseClass;

namespace PaH.SqlModel.ComboModel
{
    /// <summary>
    /// Sql Model for Dropdown Defining Attribute List
    /// </summary>
    public class DropDownDefiningAttribute : ComboModelBase
    {
        [Required]
        [StringLength(256)]
        public string AttributeName { get; set; }
    }
}

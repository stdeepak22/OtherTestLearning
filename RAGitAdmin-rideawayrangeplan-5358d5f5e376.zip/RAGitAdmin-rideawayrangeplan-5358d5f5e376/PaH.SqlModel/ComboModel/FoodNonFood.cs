﻿using System.ComponentModel.DataAnnotations;
using PaH.SqlModel.BaseClass;

namespace PaH.SqlModel.ComboModel
{
    /// <summary>
    /// Sql Model for Food Type - Food NonFood List
    /// </summary>
    public class FoodNonFood : ComboModelBase
    {
        [Required]
        [StringLength(256)]
        public string Type { get; set; }
    }
}

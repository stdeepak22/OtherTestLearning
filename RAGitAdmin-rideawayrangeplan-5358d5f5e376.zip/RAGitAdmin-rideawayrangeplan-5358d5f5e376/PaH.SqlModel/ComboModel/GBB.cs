﻿using System.ComponentModel.DataAnnotations;
using PaH.SqlModel.BaseClass;

namespace PaH.SqlModel.ComboModel
{
    /// <summary>
    /// Sql Model for Good Better Best List
    /// </summary>
    public class GBB : ComboModelBase
    {
        [Required]
        [StringLength(256)]
        public string Value { get; set; }
    }
}

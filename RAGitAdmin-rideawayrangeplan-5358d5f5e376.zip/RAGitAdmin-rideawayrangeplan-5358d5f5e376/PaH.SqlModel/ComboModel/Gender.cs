﻿using System.ComponentModel.DataAnnotations;
using PaH.SqlModel.BaseClass;

namespace PaH.SqlModel.ComboModel
{
    /// <summary>
    /// Sql Model for Gender List
    /// </summary>
    public class Gender : ComboModelBase
    {
        [Required]
        [StringLength(256)]
        public string Title { get; set; }
    }
}

﻿using System.ComponentModel.DataAnnotations;
using PaH.SqlModel.BaseClass;

namespace PaH.SqlModel.ComboModel
{
    /// <summary>
    /// Sql Model for Main Colour List
    /// </summary>
    public class MainColour : ComboModelBase
    {
        [Required]
        [StringLength(256)]
        public string Colour { get; set; }
    }
}
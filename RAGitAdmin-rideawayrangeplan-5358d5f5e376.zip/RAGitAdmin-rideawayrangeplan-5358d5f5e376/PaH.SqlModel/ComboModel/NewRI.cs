﻿using System.ComponentModel.DataAnnotations;
using PaH.SqlModel.BaseClass;

namespace PaH.SqlModel.ComboModel
{
    /// <summary>
    /// Sql Model for New/RI List
    /// </summary>
    public class NewRI : ComboModelBase
    {
        [Required]
        [StringLength(256)]
        public string Name { get; set; }
    }
}

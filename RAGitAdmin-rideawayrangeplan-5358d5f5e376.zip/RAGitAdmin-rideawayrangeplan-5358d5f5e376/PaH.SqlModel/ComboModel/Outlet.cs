﻿using System.ComponentModel.DataAnnotations;
using PaH.SqlModel.BaseClass;

namespace PaH.SqlModel.ComboModel
{
    /// <summary>
    /// Sql Model for Outlet List
    /// </summary>
    public class Outlet : ComboModelBase
    {
        [Required]
        [StringLength(256)]
        public string Type { get; set; }
    }
}

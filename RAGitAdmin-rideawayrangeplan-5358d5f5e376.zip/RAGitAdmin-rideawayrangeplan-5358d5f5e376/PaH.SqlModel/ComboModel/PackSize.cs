﻿using System.ComponentModel.DataAnnotations;
using PaH.SqlModel.BaseClass;

namespace PaH.SqlModel.ComboModel
{
    /// <summary>
    /// Sql Model for Pack Size(Buying Case Size) List
    /// </summary>
    public class PackSize : ComboModelBase
    {
        [Required]
        [StringLength(256)]
        public string Name { get; set; }

        [Required]
        public int? Quantity { get; set; }
    }
}

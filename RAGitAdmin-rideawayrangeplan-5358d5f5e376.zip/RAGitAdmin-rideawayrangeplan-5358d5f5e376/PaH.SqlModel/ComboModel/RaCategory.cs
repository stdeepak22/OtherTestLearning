﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using PaH.SqlModel.BaseClass;

namespace PaH.SqlModel.ComboModel
{
    /// <summary>
    /// Sql Model for Master Category List
    /// </summary>
    public class RaCategory : ComboModelBase
    {
        public RaCategory()
        {
            RaSubCategories = new List<RaSubCategory>();
        }

        [Required]
        [StringLength(256)]
        public string Name { get; set; }

        public virtual IList<RaSubCategory> RaSubCategories { get; set; }
    }
}

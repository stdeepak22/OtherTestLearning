﻿using System.ComponentModel.DataAnnotations;
using PaH.SqlModel.BaseClass;
using System.ComponentModel.DataAnnotations.Schema;

namespace PaH.SqlModel.ComboModel
{
    /// <summary>
    /// Sql Model for Sub Category List
    /// </summary>
    public class RaSubCategory : ComboModelBase
    {
        [Required]
        [StringLength(256)]
        public string AnalysisCode { get; set; }

        [Required]
        [StringLength(256)]
        public string Name { get; set; }

        [StringLength(256)]
        public string FirstPartShufti { get; set; }

        public virtual int RaCategoryId { get; set; }

        [ForeignKey("RaCategoryId")]
        public virtual RaCategory RaCategory { get; set; }
    }
}

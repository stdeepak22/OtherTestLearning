﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using PaH.SqlModel.BaseClass;

namespace PaH.SqlModel.ComboModel
{
    /// <summary>
    /// Sql Model for Sub Sub Category  List
    /// </summary>
    public class RaSubSubCategory : ComboModelBase
    {
        [Required]
        [StringLength(256)]
        public string Name { get; set; }

        public virtual int RaSubCategoryId { get; set; }
        [ForeignKey("RaSubCategoryId")]
        public virtual RaSubCategory RaSubCategory { get; set; }

        public virtual int RaCategoryId { get; set; }
        [ForeignKey("RaCategoryId")]
        public virtual RaCategory RaCategory { get; set; }
    }
}

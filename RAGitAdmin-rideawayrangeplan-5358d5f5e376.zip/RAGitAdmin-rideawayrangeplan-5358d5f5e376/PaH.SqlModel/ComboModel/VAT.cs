﻿using System.ComponentModel.DataAnnotations;
using PaH.SqlModel.BaseClass;

namespace PaH.SqlModel.ComboModel
{
    /// <summary>
    /// Sql Model for VAT/Free  List
    /// </summary>
    public class VAT : ComboModelBase
    {
        [Required]
        [StringLength(256)]
        public string Value { get; set; }
    }
}

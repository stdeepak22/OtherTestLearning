﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using PaH.SqlModel.BaseClass;

namespace PaH.SqlModel.ComboModel
{
    /// <summary>
    /// Sql Model for Web Sub Category List
    /// </summary>
    public class WebSubCategory : ComboModelBase
    {
        public WebSubCategory()
        {
            WebSubSubCategories = new List<WebSubSubCategory>();
        }

        [Required]
        [StringLength(256)]
        public string Name { get; set; }

        public virtual int WebCategoryId { get; set; }

        [ForeignKey("WebCategoryId")]
        public virtual WebCategory WebCategory { get; set; }

        public virtual IList<WebSubSubCategory> WebSubSubCategories { get; set; }
    }
}    


﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using PaH.SqlModel.BaseClass;

namespace PaH.SqlModel.ComboModel
{
    /// <summary>
    /// Sql Model for Web Sub Sub Category List
    /// </summary>
    public class WebSubSubCategory : ComboModelBase
    {
        [Required]
        [StringLength(256)]
        public string Name { get; set; }

        public virtual int WebSubCategoryId { get; set; }

        [ForeignKey("WebSubCategoryId")]
        public virtual WebSubCategory WebSubCategory { get; set; }

        public virtual int WebCategoryId { get; set; }

        [ForeignKey("WebCategoryId")]
        public virtual WebCategory WebCategory { get; set; }
    }
}

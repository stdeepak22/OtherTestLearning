﻿using System.ComponentModel.DataAnnotations;
using PaH.SqlModel.BaseClass;

namespace PaH.SqlModel.ComboModel
{
    /// <summary>
    /// Sql Model for YesNo List  - Used in ExclusiveToRA, HeroProduct, FreeCode7, ClickandCollect and others
    /// </summary>
    public class YesNo : ComboModelBase
    {
        [Required]
        [StringLength(256)]
        public string Value { get; set; }
    }
}

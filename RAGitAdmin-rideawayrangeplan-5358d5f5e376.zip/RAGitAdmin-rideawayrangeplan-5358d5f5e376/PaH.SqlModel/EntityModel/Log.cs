﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PaH.SqlModel.BaseClass;

namespace PaH.SqlModel.EntityModel
{
    /// <summary>
    /// Sql Model for Log entity
    /// Just to create the LOG table.  Not using from the UI project
    /// so No ViewModel Required in UiModel project
    /// </summary>
    public class Log
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public DateTime DateTime { get; set; }

        [MaxLength(255)]
        public string Thread { get; set; }
        
        [Required]
        [MaxLength(50)]
        public string Level { get; set; }
        
        [Required]
        [MaxLength(255)]
        public string Logger { get; set; }	            
        
        [Required]
        [MaxLength(50)]
        public string Host { get; set; }	            
        
        [Required]
        [MaxLength(4000)]
        public string Message { get; set; }
        
        [MaxLength(2000)]
        public string Exception { get; set; }	            
    }
}

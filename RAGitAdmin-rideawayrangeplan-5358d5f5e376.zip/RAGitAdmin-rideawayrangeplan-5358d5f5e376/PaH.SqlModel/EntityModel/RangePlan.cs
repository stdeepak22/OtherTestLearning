﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using PaH.SqlModel.BaseClass;
using PaH.SqlModel.ComboModel;

namespace PaH.SqlModel.EntityModel
{
    /// <summary>
    /// Sql Model for Range Plan entity
    /// </summary>
    public class RangePlan : EntityModelBase
    {
        [Required]
        [StringLength(256)]
        public string Season { get; set; }

        public virtual int SuppId { get; set; }
        [ForeignKey("SuppId")]
        public virtual Supplier Supplier { get; set; }

        [StringLength(256)]
        public string SupplierProductCode { get; set; }

        public virtual int? NewRIId { get; set; }
        [ForeignKey("NewRIId")]
        public virtual NewRI NewRI { get; set; }

        public string FirstPartShufti { get; set; }

        [StringLength(256)]
        public string SecondPartShufti { get; set; }

        [Required]
        [StringLength(256)]
        [Index("IX_RaProductCodeIndexing", IsUnique = true)]
        public string RAProductCodeNew { get; set; }

        [StringLength(256)]
        public string RaSubSubCategory { get; set; }

        public virtual int? RaSubCategoryId { get; set; }
        [ForeignKey("RaSubCategoryId")]
        public virtual RaSubCategory RaSubCategory { get; set; }

        public string RaCategory { get; set; }

        public virtual int? GenderId { get; set; }
        [ForeignKey("GenderId")]
        public virtual Gender Gender { get; set; }

        public virtual int? AgeId { get; set; }
        [ForeignKey("AgeId")]
        public virtual Age Age { get; set; }

        [StringLength(256)]
        public string Brand { get; set; }

        [StringLength(256)]
        public string Description { get; set; }

        public virtual int? MainColourId { get; set; }
        [ForeignKey("MainColourId")]
        public virtual MainColour MainColour { get; set; }

        [StringLength(256)]
        public string ActualColour { get; set; }
        
        // BEGIN Change Request 01
        //[StringLength(256)]
        //public string Size { get; set; }

        public virtual int? SizeTypeId { get; set; }
        [ForeignKey("SizeTypeId")]
        public virtual SizeType SizeType { get; set; }

        [StringLength(256)]
        public string Size { get; set; }

        [StringLength(256)]
        public string SizeAttribute1 { get; set; }

        [StringLength(256)]
        public string SizeAttribute2 { get; set; }

        [StringLength(256)]
        public string SizeAttribute3 { get; set; }
        // END Change Request 01

        public string Personalised { get; set; }

        [StringLength(1024)]
        public string MaterialComposition { get; set; }

        public decimal? TradeCost { get; set; }

        public decimal? RRP { get; set; }

        [Range(0, 100, ErrorMessage = "The value must be between 0 to 100")]
        public decimal? SupplierStandardDiscount { get; set; }

        [Range(0, 100, ErrorMessage = "The value must be between 0 to 100")]
        public decimal? SupplierForwardOrderDiscount { get; set; }

        public decimal? SRPLessVAT { get; set; }

        public decimal? CostLessSTDSupplierDiscount { get; set; }

        public decimal? CostLessFWDSupplierDiscount { get; set; }

        public decimal? MarginPound { get; set; }

        public decimal? MarginPercentage { get; set; }

        public decimal? RideAwayRetail { get; set; }

        public decimal? OldCostLessSTDDiscount { get; set; }

        public decimal? OldRideawayRetail { get; set; }

        public virtual int? VATId { get; set; }
        [ForeignKey("VATId")]
        public virtual VAT VAT { get; set; }

        public decimal? RideAwayRetailLessVAT { get; set; }

        public decimal? RideAwayMarginPound { get; set; }

        public decimal? RideAwayMarginPercentSTDcost { get; set; }

        public decimal? RideAwayMarginPercentFWDcost { get; set; }

        public virtual int? PackSizeId { get; set; }
        [ForeignKey("PackSizeId")]
        public virtual PackSize BuyingCaseSize { get; set; }

        [StringLength(256)]
        public string StockedDD { get; set; }

        public virtual int? CoreSeasonalRangeId { get; set; }
        [ForeignKey("CoreSeasonalRangeId")]
        public virtual CoreSeasonalRange CoreSeasonalRange { get; set; }

        public virtual int? ExclusiveToRAId { get; set; }
        [ForeignKey("ExclusiveToRAId")]
        public virtual YesNo ExclusiveToRA { get; set; }

        public virtual int? OutletId { get; set; }
        [ForeignKey("OutletId")]
        public virtual Outlet Outlet { get; set; }

        public virtual int? WebSubSubCategoryId { get; set; }
        [ForeignKey("WebSubSubCategoryId")]
        public virtual WebSubSubCategory WebCategory { get; set; }

        public virtual int? DualWebSubSubCategoryId { get; set; }
        [ForeignKey("DualWebSubSubCategoryId")]
        public virtual WebSubSubCategory DualWebCategory { get; set; }

        public decimal? SalesExVAT { get; set; }

        public decimal? SalesUnits { get; set; }

        public decimal? SalesPoundMargin { get; set; }

        public decimal? SalesForecastExVAT { get; set; }

        public decimal? SalesForecastUnits { get; set; }

        public decimal? SalesForecastPoundMargin { get; set; }

        public decimal? EstimateValExVATAve { get; set; }

        public decimal? EstimateQty { get; set; }

        public decimal? RoundedEstimateQTY { get; set; }

        public int? RetailEstimateSTDCost { get; set; }

        public int? RetailEstimateFWDCost { get; set; }

        public decimal? RetailEstimateExVAT { get; set; }

        public decimal? RetailEstimateIncVAT { get; set; }

        public int? CurrentStock { get; set; }

        public decimal? CurrentSeasonEstimate { get; set; }

        public decimal? CurrentSeasonClosingStock { get; set; }

        public decimal? CurrentSeasonClosingStockRounded { get; set; }

        public int? ForwardOrderQty { get; set; }

        public int? ForwardOrderCPStdDisc { get; set; }

        public int? ForwardOrderCPFwdDisc { get; set; }

        public decimal? ForwardOrderRetailExVAT { get; set; }

        public decimal? ForwardOrderRetailINCVAT { get; set; }

        public int? FirstDROP { get; set; }

        public int? SecondDROP { get; set; }

        public int? ThirdDROP { get; set; }

        public int? FourthDROP { get; set; }

        public int? FifthDROP { get; set; }

        public int? SixthDROP { get; set; }

        public string SplitCheck { get; set; }

        [StringLength(1024)]
        public string Comments { get; set; }

        public string CatalogueCategory { get; set; }

        public virtual int? SubCatalogueCategoryId { get; set; }
        [ForeignKey("SubCatalogueCategoryId")]
        public virtual CatalogueSubCategory CatalogueSubCategory { get; set; }

        public virtual int? GBBId { get; set; }
        [ForeignKey("GBBId")]
        public virtual GBB GBB { get; set; }

        public virtual int? HeroProductId { get; set; }
        [ForeignKey("HeroProductId")]
        public virtual YesNo HeroProduct { get; set; }

        [StringLength(1024)]
        public string ProductText { get; set; }

        [StringLength(256)]
        public string AnalysisCode { get; set; }

        public string AnalysisCodeDescription { get; set; }

        public string SupplierCode { get; set; }

        public virtual int? ProdCategoryId { get; set; }
        [ForeignKey("ProdCategoryId")]
        public virtual ProductCategory ProductCategory { get; set; }

        public virtual int? FreeCode7Id { get; set; }
        [ForeignKey("FreeCode7Id")]
        public virtual YesNo FreeCode7 { get; set; }

        public string VATCode { get; set; }

        public string ProductCategoryCode { get; set; }

        public string PrimaryPickWarehouse { get; set; }

        public string PrimaryPickLocation { get; set; }

        public string BuyingPackQTY { get; set; }

        public decimal? M4BuyingPackCost { get; set; }

        public decimal? ProductLeadtime { get; set; }

        public int? ReOrderLevel { get; set; }

        public int? ReOrderQuantity { get; set; }

        public int? ShopReOrderLevel { get; set; }

        public int? ShopReOrderQuantity { get; set; }

        public virtual int? StatusId { get; set; }
        [ForeignKey("StatusId")]
        public virtual Status Status { get; set; }

        public virtual int? DropDownDefiningAttributeId1 { get; set; }
        [ForeignKey("DropDownDefiningAttributeId1")]
        public virtual DropDownDefiningAttribute DropDownDefiningAttribute1 { get; set; }

        public string DefiningAtributeValue1 { get; set; }

        public string DropDownSequence1 { get; set; }

        public virtual int? DropDownDefiningAttributeId2 { get; set; }
        [ForeignKey("DropDownDefiningAttributeId2")]
        public virtual DropDownDefiningAttribute DropDownDefiningAttribute2 { get; set; }

        public string DefiningAtributeValue2 { get; set; }

        public string DropDownSequence2 { get; set; }

        public string InStoreOnly { get; set; }

        public virtual int? DeliveryOptionId { get; set; }
        [ForeignKey("DeliveryOptionId")]
        public virtual DeliveryOption DeliveryOption { get; set; }

        public string Keywords { get; set; }

        public virtual int? ClickandCollectId { get; set; }
        [ForeignKey("ClickandCollectId")]
        public virtual YesNo ClickandCollect { get; set; }

        public decimal? ThresholdQTYforClickAndCollect { get; set; }

        public virtual int? ProductTypeId { get; set; }
        [ForeignKey("ProductTypeId")]
        public virtual FoodNonFood FoodNonFood { get; set; }

        public string WebCategory1 { get; set; }

        public string WebCategory2 { get; set; }

        public string WebCategory3 { get; set; }

        public string WebCategory4 { get; set; }

        public string WebCategory5 { get; set; }

        public string WebCategory6 { get; set; }

        public string WebCategory7 { get; set; }

        public string WebCategory8 { get; set; }

        public string WebCategory9 { get; set; }

        public string WebCategory10 { get; set; }

        public decimal? ProductWeightKG { get; set; }

        public decimal? ProductDimensionsCMLxWxH { get; set; }        
    }
}

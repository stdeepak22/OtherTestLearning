﻿using System.ComponentModel.DataAnnotations;
using PaH.UiModel.Resources;

namespace PaH.UiModel.BaseClass
{
    /// <summary>
    /// ViewModel of Base Entity
    /// </summary>
    public class BaseEntity
    {
        public BaseEntity()
        {
            IsEnabled = true;
        }
        [Key]
        public int Id { get; set; }

        [Display(Name = "BaseEntity_IsEnabled", ResourceType = typeof(Combo_Resource))]
        public bool IsEnabled { get; set; }
    }
}

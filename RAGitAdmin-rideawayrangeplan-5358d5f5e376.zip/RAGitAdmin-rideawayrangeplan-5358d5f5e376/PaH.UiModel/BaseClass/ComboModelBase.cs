﻿using System.ComponentModel.DataAnnotations;
using PaH.UiModel.Resources;

namespace PaH.UiModel.BaseClass
{
    /// <summary>
    /// ViewModel for ComboModelBase class
    /// derived from BaseEntity and 
    /// used for All Dropdown
    /// </summary>
    public class ComboModelBase : BaseEntity
    {
        [MaxLength(1024)]
        [Display(Name = "ComboModelBase_Notes", ResourceType = typeof(Combo_Resource))]
        public string Description { get; set; }
    }
}

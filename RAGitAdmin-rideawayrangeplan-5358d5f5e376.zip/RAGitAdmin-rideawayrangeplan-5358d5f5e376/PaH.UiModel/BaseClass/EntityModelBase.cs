﻿namespace PaH.UiModel.BaseClass
{
    /// <summary>
    /// ViewModel of EntityModelBase Entity
    /// Derived from BaseEntity
    /// and used in Entity model (e.g. RangePlan)
    /// </summary>
    public class EntityModelBase : BaseEntity
    {
        //public string NotesIfAny { get; set; }
    }
}
 
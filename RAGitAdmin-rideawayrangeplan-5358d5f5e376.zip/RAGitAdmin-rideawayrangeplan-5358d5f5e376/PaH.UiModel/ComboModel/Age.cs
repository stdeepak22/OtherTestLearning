﻿using System.ComponentModel.DataAnnotations;
using PaH.UiModel.BaseClass;
using PaH.UiModel.CustomAttribute;
using PaH.UiModel.Resources;

namespace PaH.UiModel.ComboModel
{
    /// <summary>
    /// ViewModel for Age List
    /// </summary>
    public class Age : ComboModelBase
    {
        [Required]
        [PaH_ConvertToActionLink("Details")]
        [Display(Name = "Age_Value", ResourceType = typeof(Combo_Resource))]
        [StringLength(256, ErrorMessageResourceName = "Message_StringLength", ErrorMessageResourceType = typeof(Message_Resource))]
        public string Value { get; set; }
    }
}

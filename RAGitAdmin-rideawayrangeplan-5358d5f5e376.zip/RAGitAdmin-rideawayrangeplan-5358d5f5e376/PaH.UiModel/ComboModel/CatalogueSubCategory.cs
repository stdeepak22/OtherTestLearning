﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using PaH.UiModel.BaseClass;
using PaH.UiModel.CustomAttribute;
using PaH.UiModel.Resources;

namespace PaH.UiModel.ComboModel
{
    /// <summary>
    /// ViewModel for Catalogue Sub Category List
    /// </summary>
    public class CatalogueSubCategory : ComboModelBase
    {
        [Required]
        [PaH_ConvertToActionLink("Details")]
        [Display(Name = "CatalogueSubCategory_Name", ResourceType = typeof(Combo_Resource))]
        [StringLength(256, ErrorMessageResourceName = "Message_StringLength", ErrorMessageResourceType = typeof(Message_Resource))]
        public string Name { get; set; }

        [Display(Name = "CatalogueSubCategory_CatelogueCategory", ResourceType = typeof(Combo_Resource))]
        public virtual int CatalogueCategoryId { get; set; }

        [Display(Name = "CatalogueSubCategory_CatelogueCategory", ResourceType = typeof(Combo_Resource))]
        [ForeignKey("CatalogueCategoryId")]
        public virtual CatalogueCategory CatalogueCategory { get; set; }
    }
}

﻿using System.ComponentModel.DataAnnotations;
using PaH.UiModel.BaseClass;
using PaH.UiModel.CustomAttribute;
using PaH.UiModel.Resources;

namespace PaH.UiModel.ComboModel
{
    /// <summary>
    /// ViewModel for Delivery Options List
    /// </summary>
    public class DeliveryOption : ComboModelBase
    {
        [Required]
        [PaH_ConvertToActionLink("Details")]
        [Display(Name = "DeliveryOption_Option", ResourceType = typeof(Combo_Resource))]
        [StringLength(1024, ErrorMessageResourceName = "Message_StringLength1", ErrorMessageResourceType = typeof(Message_Resource))]
        [System.Web.Mvc.AllowHtml]
        public string Option { get; set; }
    }
}

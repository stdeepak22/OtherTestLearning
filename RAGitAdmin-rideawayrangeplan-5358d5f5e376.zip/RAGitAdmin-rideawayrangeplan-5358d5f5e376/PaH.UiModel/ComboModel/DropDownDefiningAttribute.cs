﻿using System.ComponentModel.DataAnnotations;
using PaH.UiModel.BaseClass;
using PaH.UiModel.CustomAttribute;
using PaH.UiModel.Resources;

namespace PaH.UiModel.ComboModel
{
    /// <summary>
    /// ViewModel for DropDown Defining Attribute  List
    /// </summary>
    public class DropDownDefiningAttribute : ComboModelBase
    {
        [Required]
        [PaH_ConvertToActionLink("Details")]
        [Display(Name = "DropDownDefiningAttribute_AttributeName", ResourceType = typeof(Combo_Resource))]
        [StringLength(256, ErrorMessageResourceName = "Message_StringLength", ErrorMessageResourceType = typeof(Message_Resource))]
        public string AttributeName { get; set; }
    }
}

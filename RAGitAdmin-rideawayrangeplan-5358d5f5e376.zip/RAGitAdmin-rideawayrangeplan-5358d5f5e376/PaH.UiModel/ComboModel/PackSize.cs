﻿using System.ComponentModel.DataAnnotations;
using PaH.UiModel.BaseClass;
using PaH.UiModel.CustomAttribute;
using PaH.UiModel.Resources;

namespace PaH.UiModel.ComboModel
{
    /// <summary>
    /// ViewModel for Pack Size (Buying Case Size) List
    /// </summary>
    public class PackSize : ComboModelBase
    {
        [Required]
        [PaH_ConvertToActionLink("Details")]
        [Display(Name = "PackSize_Name", ResourceType = typeof(Combo_Resource))]
        [StringLength(256, ErrorMessageResourceName = "Message_StringLength", ErrorMessageResourceType = typeof(Message_Resource))]
        public string Name { get; set; }

        [Required]
        [Display(Name = "PackSize_Quantity", ResourceType = typeof(Combo_Resource))]
        [Range(0, 9999999, ErrorMessageResourceName = "Message_IntegerRange", ErrorMessageResourceType = typeof(Message_Resource))]
        public int? Quantity { get; set; }
    }
}

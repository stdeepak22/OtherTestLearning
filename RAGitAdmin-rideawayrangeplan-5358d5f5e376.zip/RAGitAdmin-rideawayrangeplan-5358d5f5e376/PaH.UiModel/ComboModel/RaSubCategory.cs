﻿using System.ComponentModel.DataAnnotations;
using PaH.UiModel.CustomAttribute;
using System.ComponentModel.DataAnnotations.Schema;
using PaH.UiModel.BaseClass;
using PaH.UiModel.Resources;

namespace PaH.UiModel.ComboModel
{
    /// <summary>
    /// ViewModel for Sub Category List
    /// </summary>
    public class RaSubCategory : ComboModelBase
    {
        [Required]
        [Display(Name = "RaSubCategory_AnalysisCode", ResourceType = typeof(Combo_Resource))]
        [StringLength(256, ErrorMessageResourceName = "Message_StringLength", ErrorMessageResourceType = typeof(Message_Resource))]
        public string AnalysisCode { get; set; }

        [Required]
        [PaH_ConvertToActionLink("Details")]
        [Display(Name = "RaSubCategory_Name", ResourceType = typeof(Combo_Resource))]
        [StringLength(256, ErrorMessageResourceName = "Message_StringLength", ErrorMessageResourceType = typeof(Message_Resource))]
        public string Name { get; set; }

        [Display(Name = "RaSubCategory_FirstPartShufti", ResourceType = typeof(Combo_Resource))]
        [StringLength(256, ErrorMessageResourceName = "Message_StringLength", ErrorMessageResourceType = typeof(Message_Resource))]
        public string FirstPartShufti { get; set; }

        [Display(Name = "RaSubCategory_RaCategory", ResourceType = typeof(Combo_Resource))]
        public virtual int RaCategoryId { get; set; }

        [ForeignKey("RaCategoryId")]
        [Display(Name = "RaSubCategory_RaCategory", ResourceType = typeof(Combo_Resource))]
        public virtual RaCategory RaCategory { get; set; }
    }
}

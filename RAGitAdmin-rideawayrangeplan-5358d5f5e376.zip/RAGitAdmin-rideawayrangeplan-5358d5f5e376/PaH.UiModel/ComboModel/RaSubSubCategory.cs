﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using PaH.UiModel.BaseClass;
using PaH.UiModel.CustomAttribute;
using PaH.UiModel.Resources;

namespace PaH.UiModel.ComboModel
{
    /// <summary>
    /// ViewModel for Sub Sub Category List
    /// </summary>
    public class RaSubSubCategory : ComboModelBase
    {
        [Required]
        [PaH_ConvertToActionLink("Details")]
        [Display(Name = "RaSubSubCategory_Name", ResourceType = typeof(Combo_Resource))]
        [StringLength(256, ErrorMessageResourceName = "Message_StringLength", ErrorMessageResourceType = typeof(Message_Resource))]
        public string Name { get; set; }

        [Display(Name = "RaSubSubCategory_RaSubCategory", ResourceType = typeof(Combo_Resource))]
        public virtual int RaSubCategoryId { get; set; }

        [ForeignKey("RaSubCategoryId")]
        [Display(Name = "RaSubSubCategory_RaSubCategory", ResourceType = typeof(Combo_Resource))]
        public virtual RaSubCategory RaSubCategory { get; set; }

        [Display(Name = "RaSubSubCategory_RaCategory", ResourceType = typeof(Combo_Resource))]
        public virtual int RaCategoryId { get; set; }

        [ForeignKey("RaCategoryId")]
        [Display(Name = "RaSubSubCategory_RaCategory", ResourceType = typeof(Combo_Resource))]
        public virtual RaCategory RaCategory { get; set; }
    }
}

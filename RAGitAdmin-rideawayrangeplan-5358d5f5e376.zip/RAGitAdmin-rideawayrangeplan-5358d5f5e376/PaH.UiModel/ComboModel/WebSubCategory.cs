﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using PaH.UiModel.BaseClass;
using PaH.UiModel.CustomAttribute;
using PaH.UiModel.Resources;

namespace PaH.UiModel.ComboModel
{
    /// <summary>
    /// ViewModel for Web Sub Category List
    /// </summary>
    public class WebSubCategory : ComboModelBase
    {
        public WebSubCategory()
        {
            WebSubSubCategories = new List<WebSubSubCategory>();
        }

        [Required]
        [PaH_ConvertToActionLink("Details")]
        [Display(Name = "WebSubCategory_Name", ResourceType = typeof(Combo_Resource))]
        [StringLength(256, ErrorMessageResourceName = "Message_StringLength", ErrorMessageResourceType = typeof(Message_Resource))]
        public string Name { get; set; }

        [Display(Name = "WebSubCategory_WebCategory", ResourceType = typeof(Combo_Resource))]
        public virtual int WebCategoryId { get; set; }

        [ForeignKey("WebCategoryId")]
        [Display(Name = "WebSubCategory_WebCategory", ResourceType = typeof(Combo_Resource))]
        public virtual WebCategory WebCategory { get; set; }

        public virtual IList<WebSubSubCategory> WebSubSubCategories { get; set; }
    }
}

﻿using System;

namespace PaH.UiModel.CustomAttribute
{
    /// <summary>
    /// Custom Attribute to create the Hyperlink on Property in ViewModel.
    /// pass the ActionName like  e.g. [PaH_ConvertToActionLink("Details")]
    /// </summary>
    [System.AttributeUsage(System.AttributeTargets.Property)]
    public class PaH_ConvertToActionLink : Attribute
    {
        public string ControllerName { get; set; }
        private string ActionName { get; set; }

        public PaH_ConvertToActionLink(string actionName)
        {
            this.ActionName = actionName;
            ControllerName = String.Empty;
        }
        public string GetActionName()
        {
            return ActionName;
        }
    }
}

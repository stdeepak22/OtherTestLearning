﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using PaH.UiModel.BaseClass;
using PaH.UiModel.ComboModel;
using PaH.UiModel.Resources;

namespace PaH.UiModel.EntityModel
{
    /// <summary>
    /// ViewModel for Index view for RangePlan entity. added under CR01
    /// </summary>
    public class RangePlanIndexView : EntityModelBase
    {
        [Display(Name = "RangePlan_Season", ResourceType = typeof(RangePlan_Resource))]
        public string Season { get; set; }

        [Display(Name = "RangePlan_Supplier", ResourceType = typeof(RangePlan_Resource))]
        public virtual int SuppId { get; set; }
        [ForeignKey("SuppId")]
        public virtual Supplier Supplier { get; set; }

        [Display(Name = "RangePlan_SupplierProductCode", ResourceType = typeof(RangePlan_Resource))]
        public string SupplierProductCode { get; set; }

        [Display(Name = "RangePlan_NewRI", ResourceType = typeof(RangePlan_Resource))]
        public virtual int? NewRIId { get; set; }
        [ForeignKey("NewRIId")]
        public virtual NewRI NewRI { get; set; }

        [Display(Name = "RangePlan_1stPartRideAwayShufti", ResourceType = typeof(RangePlan_Resource))]
        public string FirstPartShufti { get; set; }

        [Display(Name = "RangePlan_2ndPartRideAwayShufti", ResourceType = typeof(RangePlan_Resource))]
        public string SecondPartShufti { get; set; }

        [Display(Name = "RangePlan_RAProductCodeNEW", ResourceType = typeof(RangePlan_Resource))]
        public string RAProductCodeNew { get; set; }

        [Display(Name = "RangePlan_SubSubCategory", ResourceType = typeof(RangePlan_Resource))]
        public string RaSubSubCategory { get; set; }

        [Display(Name = "RangePlan_SubCategory", ResourceType = typeof(RangePlan_Resource))]
        public virtual int? RaSubCategoryId { get; set; }
        [ForeignKey("RaSubCategoryId")]
        public virtual RaSubCategory RaSubCategory { get; set; }

        [Display(Name = "RangePlan_MasterCategory", ResourceType = typeof(RangePlan_Resource))]
        public string RaCategory { get; set; }

        [Display(Name = "RangePlan_Gender", ResourceType = typeof(RangePlan_Resource))]
        public virtual int? GenderId { get; set; }
        [ForeignKey("GenderId")]
        public virtual Gender Gender { get; set; }

        [Display(Name = "RangePlan_Age", ResourceType = typeof(RangePlan_Resource))]
        public virtual int? AgeId { get; set; }
        [ForeignKey("AgeId")]
        public virtual Age Age { get; set; }

        [Display(Name = "RangePlan_Brand", ResourceType = typeof(RangePlan_Resource))]

        public string Brand { get; set; }

        [Display(Name = "RangePlan_Description", ResourceType = typeof(RangePlan_Resource))]
        public string Description { get; set; }

        [Display(Name = "RangePlan_MainColour", ResourceType = typeof(RangePlan_Resource))]
        public virtual int? MainColourId { get; set; }
        [ForeignKey("MainColourId")]
        public virtual MainColour MainColour { get; set; }

        [Display(Name = "RangePlan_ActualColour", ResourceType = typeof(RangePlan_Resource))]        
        public string ActualColour { get; set; }

        //CR01        
        [Display(Name = "RangePlan_Size", ResourceType = typeof(RangePlan_Resource))]        
        public string Size1 { get; set; }

        [Display(Name = "RangePlan_SizeAttribute1", ResourceType = typeof(RangePlan_Resource))]
        public string Size1Attribute1 { get; set; }

        [Display(Name = "RangePlan_SizeAttribute2", ResourceType = typeof(RangePlan_Resource))]
        public string Size1Attribute2 { get; set; }





        [Display(Name = "RangePlan_Size", ResourceType = typeof(RangePlan_Resource))]
        public string Size2 { get; set; }

        [Display(Name = "RangePlan_SizeAttribute1", ResourceType = typeof(RangePlan_Resource))]
        public string Size2Attribute1 { get; set; }

        [Display(Name = "RangePlan_SizeAttribute2", ResourceType = typeof(RangePlan_Resource))]
        public string Size2Attribute2 { get; set; }

        [Display(Name = "RangePlan_SizeAttribute3", ResourceType = typeof(RangePlan_Resource))]
        public string Size2Attribute3 { get; set; }






        [Display(Name = "RangePlan_Size", ResourceType = typeof(RangePlan_Resource))]
        public string Size3 { get; set; }





        [Display(Name = "RangePlan_Size", ResourceType = typeof(RangePlan_Resource))]
        public string Size4 { get; set; }

        [Display(Name = "RangePlan_SizeAttribute1", ResourceType = typeof(RangePlan_Resource))]
        public string Size4Attribute1 { get; set; }

        [Display(Name = "RangePlan_SizeAttribute2", ResourceType = typeof(RangePlan_Resource))]
        public string Size4Attribute2 { get; set; }




        [Display(Name = "RangePlan_Size", ResourceType = typeof(RangePlan_Resource))]
        public string Size5 { get; set; }



        [Display(Name = "RangePlan_Size", ResourceType = typeof(RangePlan_Resource))]
        public string Size6 { get; set; }



        [Display(Name = "RangePlan_Size", ResourceType = typeof(RangePlan_Resource))]
        public string Size7 { get; set; }




        [Display(Name = "RangePlan_Size", ResourceType = typeof(RangePlan_Resource))]
        public string Size8 { get; set; }


        //CR01

        [Display(Name = "RangePlan_Personalised", ResourceType = typeof(RangePlan_Resource))]        
        public string Personalised { get; set; }

        [Display(Name = "RangePlan_MaterialComposition", ResourceType = typeof(RangePlan_Resource))]
        public string MaterialComposition { get; set; }

        [Display(Name = "RangePlan_TradeCost", ResourceType = typeof(RangePlan_Resource))]        
        public decimal? TradeCost { get; set; }

        [Display(Name = "RangePlan_RRP", ResourceType = typeof(RangePlan_Resource))]        
        public decimal? RRP { get; set; }

        [Display(Name = "RangePlan_SupplierStandardDiscount", ResourceType = typeof(RangePlan_Resource))]        
        public decimal? SupplierStandardDiscount { get; set; }

        [Display(Name = "RangePlan_SupplierForwardOrderDiscount", ResourceType = typeof(RangePlan_Resource))]        
        public decimal? SupplierForwardOrderDiscount { get; set; }

        [Display(Name = "RangePlan_SRPLessVAT", ResourceType = typeof(RangePlan_Resource))]
        public decimal? SRPLessVAT { get; set; }

        [Display(Name = "RangePlan_CostLessSTDSupplierDiscount", ResourceType = typeof(RangePlan_Resource))]
        public decimal? CostLessSTDSupplierDiscount { get; set; }

        [Display(Name = "RangePlan_CostLessFWDSupplierDiscount", ResourceType = typeof(RangePlan_Resource))]
        public decimal? CostLessFWDSupplierDiscount { get; set; }

        [Display(Name = "RangePlan_MarginPound", ResourceType = typeof(RangePlan_Resource))]
        public decimal? MarginPound { get; set; }

        [Display(Name = "RangePlan_MarginPercentage", ResourceType = typeof(RangePlan_Resource))]
        public decimal? MarginPercentage { get; set; }

        [Display(Name = "RangePlan_RideAwayRetail", ResourceType = typeof(RangePlan_Resource))]        
        public decimal? RideAwayRetail { get; set; }

        [Display(Name = "RangePlan_OldCostLessSTDDiscount", ResourceType = typeof(RangePlan_Resource))]        
        public decimal? OldCostLessSTDDiscount { get; set; }

        [Display(Name = "RangePlan_OldRideawayRetail", ResourceType = typeof(RangePlan_Resource))]        
        public decimal? OldRideawayRetail { get; set; }

        [Display(Name = "RangePlan_VAT", ResourceType = typeof(RangePlan_Resource))]
        public virtual int? VATId { get; set; }
        [ForeignKey("VATId")]
        public virtual VAT VAT { get; set; }

        [Display(Name = "RangePlan_RideAwayRetailLessVAT", ResourceType = typeof(RangePlan_Resource))]
        public decimal? RideAwayRetailLessVAT { get; set; }

        [Display(Name = "RangePlan_RideAwayMarginPound", ResourceType = typeof(RangePlan_Resource))]
        public decimal? RideAwayMarginPound { get; set; }

        [Display(Name = "RangePlan_RideAwayMarginPercentSTDCost", ResourceType = typeof(RangePlan_Resource))]
        public decimal? RideAwayMarginPercentSTDcost { get; set; }

        [Display(Name = "RangePlan_RideAwayMarginPercentFWDcost", ResourceType = typeof(RangePlan_Resource))]
        public decimal? RideAwayMarginPercentFWDcost { get; set; }

        [Display(Name = "RangePlan_BuyingCaseSize", ResourceType = typeof(RangePlan_Resource))]
        public virtual int? PackSizeId { get; set; }
        [ForeignKey("PackSizeId")]
        public virtual PackSize BuyingCaseSize { get; set; }

        [Display(Name = "RangePlan_StockedDD", ResourceType = typeof(RangePlan_Resource))]        
        public string StockedDD { get; set; }

        [Display(Name = "RangePlan_CoreSeasonalRange", ResourceType = typeof(RangePlan_Resource))]
        public virtual int? CoreSeasonalRangeId { get; set; }
        [ForeignKey("CoreSeasonalRangeId")]
        public virtual CoreSeasonalRange CoreSeasonalRange { get; set; }

        [Display(Name = "RangePlan_ExclusivetoRA", ResourceType = typeof(RangePlan_Resource))]
        public virtual int? ExclusiveToRAId { get; set; }
        [ForeignKey("ExclusiveToRAId")]
        public virtual YesNo ExclusiveToRA { get; set; }

        [Display(Name = "RangePlan_Outlet", ResourceType = typeof(RangePlan_Resource))]
        public virtual int? OutletId { get; set; }
        [ForeignKey("OutletId")]
        public virtual Outlet Outlet { get; set; }

        [Display(Name = "RangePlan_SalesExVAT", ResourceType = typeof(RangePlan_Resource))]        
        public decimal? SalesExVAT { get; set; }

        [Display(Name = "RangePlan_SalesUnits", ResourceType = typeof(RangePlan_Resource))]        
        public decimal? SalesUnits { get; set; }

        [Display(Name = "RangePlan_SalesPoundMargin", ResourceType = typeof(RangePlan_Resource))]        
        public decimal? SalesPoundMargin { get; set; }

        [Display(Name = "RangePlan_SalesForecastExVAT", ResourceType = typeof(RangePlan_Resource))]        
        public decimal? SalesForecastExVAT { get; set; }

        [Display(Name = "RangePlan_SalesForecastUnits", ResourceType = typeof(RangePlan_Resource))]        
        public decimal? SalesForecastUnits { get; set; }

        [Display(Name = "RangePlan_SalesForecastPoundMargin", ResourceType = typeof(RangePlan_Resource))]        
        public decimal? SalesForecastPoundMargin { get; set; }

        [Display(Name = "RangePlan_EstimateValExVATAve", ResourceType = typeof(RangePlan_Resource))]        
        public decimal? EstimateValExVATAve { get; set; }

        [Display(Name = "RangePlan_EstimateQty", ResourceType = typeof(RangePlan_Resource))]
        public decimal? EstimateQty { get; set; }

        [Display(Name = "RangePlan_RoundedEstimateQTY", ResourceType = typeof(RangePlan_Resource))]
        public decimal? RoundedEstimateQTY { get; set; }

        [Display(Name = "RangePlan_RetailEstimateSTDCost", ResourceType = typeof(RangePlan_Resource))]
        public int? RetailEstimateSTDCost { get; set; }

        [Display(Name = "RangePlan_RetailEstimateFWDCost", ResourceType = typeof(RangePlan_Resource))]
        public int? RetailEstimateFWDCost { get; set; }

        [Display(Name = "RangePlan_RetailEstimateExVAT", ResourceType = typeof(RangePlan_Resource))]
        public decimal? RetailEstimateExVAT { get; set; }

        [Display(Name = "RangePlan_RetailEstimateIncVAT", ResourceType = typeof(RangePlan_Resource))]
        public decimal? RetailEstimateIncVAT { get; set; }

        [Display(Name = "RangePlan_CurrentStock", ResourceType = typeof(RangePlan_Resource))]        
        public int? CurrentStock { get; set; }

        [Display(Name = "RangePlan_CurrentSeasonEstimate", ResourceType = typeof(RangePlan_Resource))]
        public decimal? CurrentSeasonEstimate { get; set; }

        [Display(Name = "RangePlan_CurrentSeasonClosingStock", ResourceType = typeof(RangePlan_Resource))]
        public decimal? CurrentSeasonClosingStock { get; set; }

        [Display(Name = "RangePlan_CurrentSeasonClosingStockRounded", ResourceType = typeof(RangePlan_Resource))]
        public decimal? CurrentSeasonClosingStockRounded { get; set; }

        [Display(Name = "RangePlan_ForwardOrderQty", ResourceType = typeof(RangePlan_Resource))]        
        public int? ForwardOrderQty { get; set; }

        [Display(Name = "RangePlan_ForwardOrderCPStdDisc", ResourceType = typeof(RangePlan_Resource))]
        public int? ForwardOrderCPStdDisc { get; set; }

        [Display(Name = "RangePlan_ForwardOrderCPFwdDisc", ResourceType = typeof(RangePlan_Resource))]
        public int? ForwardOrderCPFwdDisc { get; set; }

        [Display(Name = "RangePlan_ForwardOrderRetailExVAT", ResourceType = typeof(RangePlan_Resource))]
        public decimal? ForwardOrderRetailExVAT { get; set; }

        [Display(Name = "RangePlan_ForwardOrderRetailINCVAT", ResourceType = typeof(RangePlan_Resource))]
        public decimal? ForwardOrderRetailINCVAT { get; set; }

        [Display(Name = "RangePlan_FirstDrop", ResourceType = typeof(RangePlan_Resource))]        
        public int? FirstDROP { get; set; }

        [Display(Name = "RangePlan_SecondDrop", ResourceType = typeof(RangePlan_Resource))]        
        public int? SecondDROP { get; set; }

        [Display(Name = "RangePlan_ThirdDrop", ResourceType = typeof(RangePlan_Resource))]        
        public int? ThirdDROP { get; set; }

        [Display(Name = "RangePlan_FourthDrop", ResourceType = typeof(RangePlan_Resource))]        
        public int? FourthDROP { get; set; }

        [Display(Name = "RangePlan_FifthDrop", ResourceType = typeof(RangePlan_Resource))]        
        public int? FifthDROP { get; set; }

        [Display(Name = "RangePlan_SixthDrop", ResourceType = typeof(RangePlan_Resource))]        
        public int? SixthDROP { get; set; }

        [Display(Name = "RangePlan_SplitCheck", ResourceType = typeof(RangePlan_Resource))]        
        public string SplitCheck { get; set; }

        [Display(Name = "RangePlan_Comments", ResourceType = typeof(RangePlan_Resource))]        
        public string Comments { get; set; }

        [Display(Name = "RangePlan_MasterCatalogueCategory", ResourceType = typeof(RangePlan_Resource))]        
        public string CatalogueCategory { get; set; }

        [Display(Name = "RangePlan_SubCatalogueCategory", ResourceType = typeof(RangePlan_Resource))]
        public virtual int? SubCatalogueCategoryId { get; set; }
        [ForeignKey("SubCatalogueCategoryId")]
        public virtual CatalogueSubCategory CatalogueSubCategory { get; set; }

        [Display(Name = "RangePlan_GoodBetterBest", ResourceType = typeof(RangePlan_Resource))]
        public virtual int? GBBId { get; set; }
        [ForeignKey("GBBId")]
        public virtual GBB GBB { get; set; }

        [Display(Name = "RangePlan_HeroProduct", ResourceType = typeof(RangePlan_Resource))]
        public virtual int? HeroProductId { get; set; }
        [ForeignKey("HeroProductId")]
        public virtual YesNo HeroProduct { get; set; }

        [Display(Name = "RangePlan_ProductText", ResourceType = typeof(RangePlan_Resource))]        
        public string ProductText { get; set; }

        [Display(Name = "RangePlan_AnalysisCode", ResourceType = typeof(RangePlan_Resource))]        
        public string AnalysisCode { get; set; }

        [Display(Name = "RangePlan_AnalysisCodeDescription", ResourceType = typeof(RangePlan_Resource))]
        public string AnalysisCodeDescription { get; set; }

        [Display(Name = "RangePlan_SupplierCode", ResourceType = typeof(RangePlan_Resource))]        
        public string SupplierCode { get; set; }

        [Display(Name = "RangePlan_ProductCategory", ResourceType = typeof(RangePlan_Resource))]
        public virtual int? ProdCategoryId { get; set; }
        [ForeignKey("ProdCategoryId")]
        public virtual ProductCategory ProductCategory { get; set; }

        [Display(Name = "RangePlan_FreeCode7", ResourceType = typeof(RangePlan_Resource))]
        public virtual int? FreeCode7Id { get; set; }
        [ForeignKey("FreeCode7Id")]
        public virtual YesNo FreeCode7 { get; set; }

        [Display(Name = "RangePlan_VatCode", ResourceType = typeof(RangePlan_Resource))]        
        public string VATCode { get; set; }

        [Display(Name = "RangePlan_ProductCategoryCode", ResourceType = typeof(RangePlan_Resource))]        
        public string ProductCategoryCode { get; set; }

        [Display(Name = "RangePlan_PrimaryPickWarehouse", ResourceType = typeof(RangePlan_Resource))]        
        public string PrimaryPickWarehouse { get; set; }

        [Display(Name = "RangePlan_PrimaryPickLocation", ResourceType = typeof(RangePlan_Resource))]        
        public string PrimaryPickLocation { get; set; }

        [Display(Name = "RangePlan_BuyingPackQTY", ResourceType = typeof(RangePlan_Resource))]        
        public string BuyingPackQTY { get; set; }

        [Display(Name = "RangePlan_M4BuyingPackCost", ResourceType = typeof(RangePlan_Resource))]
        public decimal? M4BuyingPackCost { get; set; }

        [Display(Name = "RangePlan_ProductLeadtime", ResourceType = typeof(RangePlan_Resource))]
        public decimal? ProductLeadtime { get; set; }

        [Display(Name = "RangePlan_ReOrderLevel", ResourceType = typeof(RangePlan_Resource))]
        public int? ReOrderLevel { get; set; }

        [Display(Name = "RangePlan_ReOrderQuantity", ResourceType = typeof(RangePlan_Resource))]
        public int? ReOrderQuantity { get; set; }

        [Display(Name = "RangePlan_ShopReOrderLevel", ResourceType = typeof(RangePlan_Resource))]
        public int? ShopReOrderLevel { get; set; }

        [Display(Name = "RangePlan_ShopReOrderQuantity", ResourceType = typeof(RangePlan_Resource))]
        public int? ShopReOrderQuantity { get; set; }

    }
}

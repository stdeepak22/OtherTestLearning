﻿using System;
using System.IO;
using System.Data;
using System.Linq;
using log4net;
using log4net.Appender;
using System.Configuration;
using log4net.Config;
using System.Globalization;
using log4net.Core;
using log4net.Repository.Hierarchy;

namespace Log4NetLibrary
{
    /// <summary>
    /// 
    /// </summary>
    public sealed class FileLogService : ILogService
    {
        // Level 
        //1. Debug
        //2. Information
        //3. Warnings
        //4. Error
        //5. Fatal

        /// <summary>
        /// Set Log directory Path
        /// </summary>
        readonly ILog _logger = null;
        static FileLogService()
        {
            string Log4netConnectionString = "PaHContext";
            // Gets directory path of the calling application
            // RelativeSearchPath is null if the executing assembly i.e. calling assembly is a
            // stand alone exe file (Console, WinForm, etc). 
            // RelativeSearchPath is not null if the calling assembly is a web hosted application i.e. a web site
            var log4NetConfigDirectory = AppDomain.CurrentDomain.RelativeSearchPath ?? AppDomain.CurrentDomain.BaseDirectory;
            var log4NetConfigFilePath = Path.Combine(log4NetConfigDirectory, "log4net.config");
            XmlConfigurator.ConfigureAndWatch(new FileInfo(log4NetConfigFilePath));

            var hier = (Hierarchy)LogManager.GetRepository();
            if (hier != null)
            {
                var appenders = hier.GetAppenders().OfType<AdoNetAppender>();
                foreach (var appender in appenders)
                {
                    appender.ConnectionString = ConfigurationManager.ConnectionStrings[Log4netConnectionString].ConnectionString;
                    appender.ActivateOptions();
                }
            }
        }

        /// <summary>
        /// Initiates FileLogService for the passed in logClass and 
        /// sets GlobalContext Host property.
        /// </summary>
        /// <param name="logClass"></param>
        public FileLogService(Type logClass)
        {
            _logger = LogManager.GetLogger(logClass);
            GlobalContext.Properties["host"] = Environment.MachineName;
        }

        #region ILogger Members
        /// <summary>
        /// Write an Info log, use when function is executed
        /// </summary>
        /// <param name="methodName"></param>
        public void EnterMethod(string methodName)
        {
            if (_logger.IsInfoEnabled)
                _logger.Info(string.Format(CultureInfo.InvariantCulture, "Entering Method {0}", methodName));
        }

        /// <summary>
        /// Write an Info log, use when execution leaves function.
        /// </summary>
        /// <param name="methodName"></param>
        public void LeaveMethod(string methodName)
        {
            if (_logger.IsInfoEnabled)
                _logger.Info(string.Format(CultureInfo.InvariantCulture, "Leaving Method {0}", methodName));
        }

        /// <summary>
        /// Write a Error log with Exception Message and Exception detail
        /// </summary>
        /// <param name="exception"></param>
        public void LogException(Exception exception)
        {
            if (_logger.IsErrorEnabled)
                _logger.Error(string.Format(CultureInfo.InvariantCulture, "{0}", exception.Message), exception);
        }

        /// <summary>
        /// Write an Error log with a string message passed.
        /// </summary>
        /// <param name="message"></param>
        public void LogError(string message)
        {
            if (_logger.IsErrorEnabled)
                _logger.Error(string.Format(CultureInfo.InvariantCulture, "{0}", message));
        }

        /// <summary>
        /// Write a Warn log with the passed in string message
        /// </summary>
        /// <param name="message"></param>
        public void LogWarningMessage(string message)
        {
            if (_logger.IsWarnEnabled)
                _logger.Warn(string.Format(CultureInfo.InvariantCulture, "{0}", message));
        }

        /// <summary>
        /// Write a Info log with the passed in string message
        /// </summary>
        /// <param name="message"></param>
        public void LogInfoMessage(string message)
        {
            if (_logger.IsInfoEnabled)
                _logger.Info(string.Format(CultureInfo.InvariantCulture, "{0}", message));
        }

        /// <summary>
        /// Write a Fatal log with the passed in string message
        /// </summary>
        /// <param name="message"></param>
        public void LogFatalMessage(string message)
        {
            if (_logger.IsFatalEnabled)
                _logger.Fatal(string.Format(CultureInfo.InvariantCulture, "{0}", message));
        }

        /// <summary>
        /// Write a Debug log for most information
        /// </summary>
        /// <param name="message"></param>
        public void LogDebugMessage(string message)
        {
            if (_logger.IsDebugEnabled)
                _logger.Debug(string.Format(CultureInfo.InvariantCulture, "{0}", message));
        }

        #endregion
    }

    public class MssqlAppender : AdoNetAppender
    {
        private const string Log4netConnectionString = "PaHContext";
        private string conn = System.Configuration.ConfigurationManager.ConnectionStrings[Log4netConnectionString].ConnectionString;
        public new string ConnectionString
        {
            get { return base.ConnectionString; }
            set
            {
                base.ConnectionString = conn;
            }
        }
    }

    class CustomErrorHandler : IErrorHandler
    {
        #region IErrorHandler Members
        public void Error(string message)
        {

        }
        public void Error(string message, Exception e)
        {

        }
        public void Error(string message, Exception e, ErrorCode errorCode)
        {

        }
        #endregion
    }
}

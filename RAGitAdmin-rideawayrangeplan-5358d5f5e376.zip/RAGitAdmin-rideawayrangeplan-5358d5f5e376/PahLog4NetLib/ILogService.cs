﻿using System;
namespace Log4NetLibrary
{
    public interface ILogService
    {
        //void Fatal(string message);
        //void Error(string message);
        //void Warn(string message);
        //void Info(string message);
        //void Debug(string message);

        /// <summary>
        /// Writes a log entry when entering the method.
        /// </summary>
        /// <param name="methodName">Name of the method.</param>
        void EnterMethod(string methodName);

        /// <summary>
        /// Writes a log entry when leaving the method.
        /// </summary>
        /// <param name="methodName">Name of the method.</param>
        void LeaveMethod(string methodName);

        /// <summary>
        /// Logs the exception.
        /// </summary>
        /// <param name="exception">The exception.</param>
        void LogException(Exception exception);

        /// <summary>
        /// Logs the error.
        /// </summary>
        /// <param name="message">The message.</param>
        void LogError(string message);

        /// <summary>
        /// Logs the warning message.
        /// </summary>
        /// <param name="message">The message.</param>
        void LogWarningMessage(string message);

        /// <summary>
        /// Logs the info message.
        /// </summary>
        /// <param name="message">The message.</param>
        void LogInfoMessage(string message);

        /// <summary>
        /// Logs the Debug Info.
        /// </summary>
        /// <param name="message">The message.</param>
        void LogDebugMessage(string message);

        /// <summary>
        /// Logs Fatal Info
        /// </summary>
        /// <param name="message"></param>
        void LogFatalMessage(string message);
    }
}

﻿using System;
using System.Configuration;
using System.IO;
using log4net.Appender;

namespace Log4NetLibrary
{

}

﻿using System.Web.Optimization;

namespace Pet_home
{
    /// <summary>
    /// Bundling configuration class fir Javascript and CSS
    /// </summary>
    public class BundleConfig
    {
        // For more information on bundling, visit http://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                        "~/Scripts/jquery-{version}.js"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryval").Include(
                        "~/Scripts/jquery.validate*"));

            bundles.Add(new ScriptBundle("~/bundles/bootstrap_checkbox_select").Include(
                      "~/Scripts/bootstrap.min.js",
                      "~/Scripts/bootstrap-checkbox.js",
                      "~/Scripts/bootstrap-select.min.js"));

            bundles.Add(new StyleBundle("~/Content/BootstrapCss").Include(
                      "~/Content/bootstrap.min.css",
                      "~/Content/Style.css",
                      "~/Content/bootstrap-responsive.css",
                      "~/Content/bootstrap-checkbox.css",
                      "~/Content/bootstrap-select.css"
                      ));

        }
    }
}

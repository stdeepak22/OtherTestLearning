﻿using System;
using System.Web.Mvc;
using PaH.BL.Repository;
using Log4NetLibrary;

namespace Pet_home.App_Start
{
    /// <summary>
    /// Custome ControllerFactory,
    /// Overrided the defautl factory so that we can inject the repository IoC
    /// </summary>
    public class ControllerFactoryConfig
    {
        public static void RegisterCustomControllerFactory()
        {
            ControllerBuilder.Current.SetControllerFactory(new CustomControllerFactory());
        }

        class CustomControllerFactory : DefaultControllerFactory
        {
            ILogService logger = new FileLogService(typeof(CustomControllerFactory));
            protected override IController GetControllerInstance(System.Web.Routing.RequestContext requestContext, Type controllerType)
            {
                logger.EnterMethod("GetControllerInstance");
                var routeValueDic = requestContext.RouteData.Values;
                logger.LogDebugMessage(string.Format("Controller : {0}, Action : {1}, Parameters : {2}",
                    routeValueDic["controller"].ToString(),
                    routeValueDic["action"].ToString(),
                    requestContext.HttpContext.Request.RawUrl
                    ));
                IRepository repository = new BasicRepository();

                //if controller Type is null, mean user try to enter the url not exists.
                if (controllerType == null)
                {
                    routeValueDic["controller"] = "Error";
                    routeValueDic["action"] = "Index";
                    Type errorController = typeof(Pet_home.Controllers.ErrorController);
                    return base.GetControllerInstance(requestContext, errorController);
                }
                else
                {
                    try
                    {
                        logger.LogInfoMessage("Repository Injected.");
                        logger.LeaveMethod("GetControllerInstance");
                        return Activator.CreateInstance(controllerType, repository) as IController;
                    }
                    catch
                    {
                        logger.LogInfoMessage("not suitable contructor found. Repository not Injected.");
                        logger.LeaveMethod("GetControllerInstance");
                        return base.GetControllerInstance(requestContext, controllerType);
                    }
                }
            }
        }
    }
}
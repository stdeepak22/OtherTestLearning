﻿using System;
using System.Configuration;
using System.DirectoryServices;
using System.Linq;
using System.Security.Principal;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using PaH.UiModel.Resources;
using Log4NetLibrary;
using PaH.BL.Repository;
using System.DirectoryServices.AccountManagement;

namespace Pet_home.Controllers
{
    /// <summary>
    /// Class to authenticate a user using LDAP
    /// </summary>
    public class LdapAuthentication
    {
        // Create an object for logger
        ILogService logger = new FileLogService(typeof(LdapAuthentication));

        private string _path;
        private string _filterAttribute;
        private string _memberOf;
        public string _givenName;
        public string _sn;

        /// <summary>
        /// Set global LDAP Path
        /// </summary>
        /// <param name="path"></param>
        public LdapAuthentication(string path)
        {
            logger.EnterMethod("LdapAuthentication");
            _path = path;
            logger.LogDebugMessage(string.Format("LDAP Path: {0}", _path));
            logger.LeaveMethod("LdapAuthentication");
        }

        /// <summary>
        /// Get configuration value of passed attribute value from AppSettings
        /// </summary>
        /// <param name="configurationAttribute"></param>
        /// <returns></returns>
        public string getConfigurationValue(string configurationAttribute)
        {
            logger.EnterMethod("getConfigurationValue");
            string configValue = "";
            try
            {
                if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings[configurationAttribute]))
                {
                    configValue = ConfigurationManager.AppSettings[configurationAttribute].ToString();
                    logger.LogDebugMessage(string.Format("{0}: {1}", configurationAttribute,configValue));
                }
                else
                {
                    logger.LogDebugMessage(string.Format("Incorrect {0} value, review configuration file.",configurationAttribute));
                    throw new Exception(Message_Resource.Message_getConfigurationValue_Exception);
                }
            }
            catch (Exception ex)
            {
                logger.LogException(ex);
            }
            logger.LeaveMethod("getConfigurationValue");
            return configValue;
        }

        /// <summary>
        /// Function to authenticate a user using LDAP. 
        /// User can be authenticated either by Simple/Active Directory binding,
        /// The web.config needs to be set correctly for LDAP entries.
        /// </summary>
        /// <param name="username"></param>
        /// <param name="pwd"></param>
        /// <returns>True/False as per User is authenticated or not</returns>
        public bool isAuthenticated(string username, string password)
        {
            string tempConfigurationValue = string.Empty;
            string container = string.Empty;
            string ldapType = string.Empty;
            string ldapDomain = string.Empty;
            string ldapFilter = string.Empty;
            string ldapPropertiesToLoad = string.Empty;
            string ldapPartition = string.Empty;

            // Read LDAP configuration values
            if (ConfigurationManager.AppSettings.Count <= 0)
            {
                throw new Exception(Message_Resource.Message_Missing_AppSetting);
            }

            // Set LDAP Container
            container = getConfigurationValue("LDAPContainer");

            // Set LDAPType
            ldapType = getConfigurationValue("LDAPType");

            // Set LDAP Domain
            ldapDomain = getConfigurationValue("LDAPDomain");

            // Set LDAPFilter
            ldapFilter = getConfigurationValue("LDAPFilter");

            // Set LDAPPartition 
            ldapPartition = getConfigurationValue("LDAPPartition");

            // Set LDAPPropertiesToLoad
            ldapPropertiesToLoad = getConfigurationValue("LDAPPropertiesToLoad");

            // Convert LDAPPropertiesToLoad to Array
            string[] ldapProp = ldapPropertiesToLoad.Split(';').ToArray();
            string samAccountName = String.Empty;
            string dn = String.Empty;
            bool blnSamAccountName = false;

            try
            {
                logger.LogDebugMessage(string.Format("Username: {0}", username));
                // Validate using Simple Bind Else using AD
                if (ldapType == "Simple")
                {
                    dn = "CN=" + username + "," + container + "," + ldapPartition;
                    using (DirectoryEntry dirEntry = new DirectoryEntry(_path, dn, password, AuthenticationTypes.None))
                    using (DirectorySearcher dirSearch = new DirectorySearcher(dirEntry, string.Concat("(CN=" + username + ")"), new string[] { "cn" }, SearchScope.Subtree))
                    {
                        SearchResult result = dirSearch.FindOne();
                        if (result != null)
                        {
                            _path = result.Path;
                            logger.LogDebugMessage(string.Format("_path: {0}", _path));

                            _filterAttribute = (String)result.Properties["cn"][0];
                            logger.LogDebugMessage(string.Format("_filterAttribute: {0}", _filterAttribute));
                        }
                        else
                            return false;
                    }
                }
                else if (ldapType == "ActiveDirectory")
                {
                    dn = ldapDomain + @"\" + username;
                    using (DirectoryEntry dirEntry = new DirectoryEntry(_path, dn, password, AuthenticationTypes.Secure))
                    using (DirectorySearcher dirSearch = new DirectorySearcher(dirEntry, string.Concat("(objectClass=" + ldapFilter + ")"), ldapProp, SearchScope.Subtree))
                    {
                        SearchResultCollection results = dirSearch.FindAll();
                        if (results != null)
                        {
                            foreach (SearchResult result in results)
                            {
                                if (result.Properties.Contains("cn") && result.Properties.Contains("memberOf"))
                                {
                                    foreach (string property in result.Properties.PropertyNames)
                                    {
                                        if (property.ToLower() == "objectsid")
                                        {
                                            if (result.Properties["objectSid"][0] != null && result.Properties["objectClass"].Contains("foreignSecurityPrincipal"))
                                            {
                                                PrincipalContext _principalContext = new PrincipalContext(ContextType.Domain, ldapDomain);
                                                UserPrincipal _userPrincipal = UserPrincipal.FindByIdentity(_principalContext, username);
                                                if (_userPrincipal != null)
                                                {
                                                    _givenName = _userPrincipal.GivenName;
                                                    samAccountName = _userPrincipal.SamAccountName;
                                                }
                                                else
                                                {
                                                    SecurityIdentifier sid = new SecurityIdentifier((byte[])result.Properties["objectSid"][0], 0);
                                                    NTAccount account = (NTAccount)sid.Translate(typeof(NTAccount));
                                                    samAccountName = account.ToString();
                                                }
                                                logger.LogDebugMessage(string.Format("NTAccount samAccountName: {0}", samAccountName));
                                                if (dn.ToLower() == samAccountName.ToLower())
                                                {
                                                    _path = result.Path;
                                                    logger.LogDebugMessage(string.Format("_path: {0}", _path));

                                                    _filterAttribute = (String)result.Properties["cn"][0];
                                                    logger.LogDebugMessage(string.Format("_filterAttribute: {0}", _filterAttribute));

                                                    _memberOf = (String)result.Properties["memberOf"][0];
                                                    logger.LogDebugMessage(string.Format("_memberOf: {0}", _memberOf));

                                                    blnSamAccountName = true;
                                                    break;
                                                }
                                                else
                                                {
                                                    _path = String.Empty;
                                                    _filterAttribute = String.Empty;
                                                    _memberOf = String.Empty;
                                                    blnSamAccountName = false;
                                                }
                                            }
                                        }
                                    }
                                    if (dn.ToLower() == samAccountName.ToLower())
                                    {
                                        blnSamAccountName = true;
                                        break;
                                    }
                                    else
                                        blnSamAccountName = false;
                                }
                            }
                        }
                        else
                            blnSamAccountName = false;
                    }
                }
                else
                {
                    //LDAP configuration incorrect
                    blnSamAccountName = false;
                }
                if (!string.IsNullOrEmpty(samAccountName))
                    blnSamAccountName = true;
                logger.LogDebugMessage(string.Format("blnSamAccountName: {0}", blnSamAccountName));
                return blnSamAccountName;
            }
            catch (Exception ex)
            {
                throw new Exception(Message_Resource.Message_LoginError1 + ex.Message);
            }
        }
    }

    /// <summary>
    /// Controller for login and logout purpose.
    /// </summary>
    public class AccountController : Controller
    {
        private readonly IRepository _repository = null;
        // Create an object for logger
        ILogService logger = new FileLogService(typeof(LdapAuthentication));

        public AccountController(IRepository repository)
        {
            _repository = repository;
            logger.LogDebugMessage(string.Format("_repository: {0}", _repository));
        }
        /// <summary>
        /// Redirect Index to Login view
        /// </summary>
        /// <returns></returns>
        public ActionResult Index()
        {
            return RedirectToAction("Login");
        }

        /// <summary>
        /// Get method for Login View
        /// </summary>
        /// <param name="ReturnUrl"></param>
        /// <returns></returns>
        [HttpGet]
        public ActionResult Login(string ReturnUrl = "")
        {
            // Build database 
            _repository.GetAll<PaH.UiModel.ComboModel.Age>();

            if (User.Identity.Name != String.Empty)
            {
                if (ReturnUrl == String.Empty)
                {
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    return Redirect(ReturnUrl);
                }
            }
            return View();
        }

        /// <summary>
        /// Post method for Login View,
        /// this authenticate the user and send back the authCookies back to client
        /// </summary>
        /// <param name="User"></param>
        /// <param name="Password"></param>
        /// <param name="ReturnUrl"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(string User, string Password, string ReturnUrl = "~/")
        {
            string hostName = getConfigurationValue("LDAPSrvrNm");
            string appDirPartition = getConfigurationValue("LDAPPartition");
            string adPath = "LDAP://" + hostName + "/" + appDirPartition;
            string userGivenName = string.Empty;
            LdapAuthentication adAuth = new LdapAuthentication(adPath);

            try
            {
                if (true == adAuth.isAuthenticated(User, Password))
                {
                    // Create the authentication ticket
                    userGivenName = string.IsNullOrEmpty(adAuth._givenName)? User : adAuth._givenName;                    
                    FormsAuthenticationTicket authTicket = new FormsAuthenticationTicket(1, User.ToLower(), DateTime.Now,
                        DateTime.Now.AddMinutes(FormsAuthentication.Timeout.TotalMinutes),
                        false,
                        userGivenName, FormsAuthentication.FormsCookiePath);
                    //Now encrypt the ticket                    
                    string encryptedTicket = FormsAuthentication.Encrypt(authTicket);
                    // Create a cookie and add the encrypted ticket to the cookie as data
                    HttpCookie authCookie = new HttpCookie(FormsAuthentication.FormsCookieName, encryptedTicket);
                    // Add the Cookie to outgoing cookies collection
                    Response.Cookies.Add(authCookie);
                    return Redirect(ReturnUrl);
                }
                else
                {
                    ViewBag.Error = Message_Resource.Message_LoginError2;
                }

            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
            }

            return View();
        }

        /// <summary>
        /// Get configuration value of passed attribute value from AppSettings
        /// </summary>
        /// <param name="configurationAttribute"></param>
        /// <returns></returns>
        public string getConfigurationValue(string configurationAttribute)
        {
            logger.EnterMethod("getConfigurationValue");
            string configValue = "";
            try
            {
                if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings[configurationAttribute]))
                {
                    configValue = ConfigurationManager.AppSettings[configurationAttribute].ToString();
                    logger.LogDebugMessage(string.Format("{0}: {1}", configurationAttribute, configValue));
                }
                else
                {
                    logger.LogDebugMessage(string.Format("Incorrect {0} value, review configuration file.", configurationAttribute));
                    throw new Exception(Message_Resource.Message_getConfigurationValue_Exception);
                }
            }
            catch (Exception ex)
            {
                logger.LogException(ex);
            }
            logger.LeaveMethod("getConfigurationValue");
            return configValue;
        }

        /// <summary>
        /// Logout, remove the authCookies.
        /// </summary>
        /// <returns></returns>
        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Login", "Account");
        }
    }
}
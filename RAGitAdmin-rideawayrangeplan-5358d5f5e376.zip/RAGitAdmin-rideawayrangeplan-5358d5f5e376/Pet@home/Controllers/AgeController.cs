﻿using System.Net;
using System.Web.Mvc;
using PaH.BL.Repository;
using PaH.UiModel.ComboModel;
using PaH.UiModel.Resources;

namespace Pet_home.Controllers
{
    /// <summary>
    /// Controller for CRUD operation on Age entity
    /// </summary>
    [Authorize]
    public class AgeController : Controller
    {
        private readonly IRepository _repository;

        public AgeController(IRepository repository)
        {
            _repository = repository;
        }

        // GET: /Age/
        public ActionResult Index()
        {
            return View(_repository.GetAll<Age>());
        }

        // GET: /Age/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            Age age = _repository.Find<Age>(id);
            if (age == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            return View(age);
        }

        // GET: /Age/Create
        public ActionResult Create()
        {
            return View(new Age());
        }

        // POST: /Age/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Value,Description,IsEnabled")] Age age)
        {
            if (ModelState.IsValid)
            {
                age = _repository.Add(age);
                if (age.Id != 0)
                {
                    TempData["Success"] = Message_Resource.Message_Created;
                    return RedirectToAction("Details", null, new { Id = age.Id });
                }
            }

            return View(age);
        }

        // GET: /Age/Edit/5  
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            Age age = _repository.Find<Age>(id);
            if (age == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            return View(age);
        }

        // POST: /Age/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Value,Description,IsEnabled")] Age age)
        {
            if (ModelState.IsValid)
            {
                if (_repository.Save(age))
                {
                    TempData["Success"] = Message_Resource.Message_Updated;
                    return RedirectToAction("Details", null, new { Id = age.Id });
                }
            }
            return View(age);
        }

        // POST: /Age/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int? id)
        {
            Age age = _repository.Find<Age>(id);
            if (age == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            _repository.Delete<Age>(id);
            return RedirectToAction("Index");
        }

        //dispose the repository and other object.
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _repository.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}

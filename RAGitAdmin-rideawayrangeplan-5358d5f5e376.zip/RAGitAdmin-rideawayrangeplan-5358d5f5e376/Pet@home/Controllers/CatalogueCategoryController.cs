﻿using System.Net;
using System.Web.Mvc;
using PaH.BL.Repository;
using PaH.UiModel.ComboModel;
using PaH.UiModel.Resources;

namespace Pet_home.Controllers
{
    /// <summary>
    /// Controller for CRUD operations on Catalogue Category
    /// </summary>
    [Authorize]
    public class CatalogueCategoryController : Controller
    {
        private readonly IRepository _repository;

        public CatalogueCategoryController(IRepository repository)
        {
            _repository = repository;
        }

        // GET: /CatalogueCategory/
        public ActionResult Index()
        {
            return View(_repository.GetAll<CatalogueCategory>());
        }

        // GET: /CatalogueCategory/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            CatalogueCategory cataloguecategory = _repository.Find<CatalogueCategory>(id);
            if (cataloguecategory == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            return View(cataloguecategory);
        }

        // GET: /CatalogueCategory/Create
        public ActionResult Create()
        {
            return View(new CatalogueCategory());
        }

        // POST: /CatalogueCategory/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Name,Description,IsEnabled")] CatalogueCategory cataloguecategory)
        {
            if (ModelState.IsValid)
            {
                cataloguecategory = _repository.Add(cataloguecategory);
                if (cataloguecategory.Id != 0)
                {
                    TempData["Success"] = Message_Resource.Message_Created;
                    return RedirectToAction("Details", null, new { Id = cataloguecategory.Id });
                }
            }

            return View(cataloguecategory);
        }

        // GET: /CatalogueCategory/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            CatalogueCategory cataloguecategory = _repository.Find<CatalogueCategory>(id);
            if (cataloguecategory == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            return View(cataloguecategory);
        }

        // POST: /CatalogueCategory/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Name,Description,IsEnabled")] CatalogueCategory cataloguecategory)
        {
            if (ModelState.IsValid)
            {
                if (_repository.Save(cataloguecategory))
                {
                    TempData["Success"] = Message_Resource.Message_Updated;
                    return RedirectToAction("Details", null, new { Id = cataloguecategory.Id });
                }
            }
            return View(cataloguecategory);
        }

        // POST: /CatalogueCategory/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int? id)
        {
            CatalogueCategory cataloguecategory = _repository.Find<CatalogueCategory>(id);
            if (cataloguecategory == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            _repository.Delete<CatalogueCategory>(id);
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _repository.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}

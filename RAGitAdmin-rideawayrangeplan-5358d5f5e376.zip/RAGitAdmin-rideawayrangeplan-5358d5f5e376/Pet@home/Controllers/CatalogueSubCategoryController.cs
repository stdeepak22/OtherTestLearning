﻿using System.Net;
using System.Web.Mvc;
using PaH.BL.Repository;
using PaH.UiModel.ComboModel;
using PaH.UiModel.Resources;

namespace Pet_home.Controllers
{
    /// <summary>
    /// Controller for CRUD operation on Catalogue Sub Category
    /// </summary>
    [Authorize]
    public class CatalogueSubCategoryController : Controller
    {
        private readonly IRepository _repository;

        public CatalogueSubCategoryController(IRepository repository)
        {
            _repository = repository;
        }

        // GET: /CatalogueSubCategory/
        public ActionResult Index()
        {
            return View(_repository.GetAll<CatalogueSubCategory>());
        }

        // GET: /CatalogueSubCategory/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            CatalogueSubCategory cataloguesubcategory = _repository.Find<CatalogueSubCategory>(id);
            if (cataloguesubcategory == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            return View(cataloguesubcategory);
        }

        // GET: /CatalogueSubCategory/Create
        public ActionResult Create()
        {
            ViewBag.CatalogueCategoryId = new SelectList(_repository.GetComboForNew<CatalogueCategory>(), "Id", "Name");
            return View(new CatalogueSubCategory());
        }

        // POST: /CatalogueSubCategory/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Name,CatalogueCategoryId,Description,IsEnabled")] CatalogueSubCategory cataloguesubcategory)
        {
            if (ModelState.IsValid)
            {
                cataloguesubcategory = _repository.Add(cataloguesubcategory);
                if (cataloguesubcategory.Id != 0)
                {
                    TempData["Success"] = Message_Resource.Message_Created;
                    return RedirectToAction("Details", null, new { Id = cataloguesubcategory.Id });
                }
            }

            ViewBag.CatalogueCategoryId = new SelectList(_repository.GetComboForNew<CatalogueCategory>(), "Id", "Name", cataloguesubcategory.CatalogueCategoryId);
            return View(cataloguesubcategory);
        }

        // GET: /CatalogueSubCategory/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            CatalogueSubCategory cataloguesubcategory = _repository.Find<CatalogueSubCategory>(id);
            if (cataloguesubcategory == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            ViewBag.CatalogueCategoryId = new SelectList(_repository.GetComboForEdit<CatalogueCategory>(cataloguesubcategory.CatalogueCategoryId),
                    "Id", "Name", cataloguesubcategory.CatalogueCategoryId);

            return View(cataloguesubcategory);
        }

        // POST: /CatalogueSubCategory/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Name,CatalogueCategoryId,Description,IsEnabled")] CatalogueSubCategory cataloguesubcategory)
        {
            if (ModelState.IsValid)
            {
                if (!_repository.IsEnabled<CatalogueCategory>(cataloguesubcategory.CatalogueCategoryId))
                {
                    ModelState.AddModelError("CatalogueCategoryId", Message_Resource.Message_ModelError);
                }
                else if (_repository.Save(cataloguesubcategory))
                {
                    TempData["Success"] = Message_Resource.Message_Updated;
                    return RedirectToAction("Details", null, new { Id = cataloguesubcategory.Id });
                }
            }
            ViewBag.CatalogueCategoryId = new SelectList(_repository.GetComboForEdit<CatalogueCategory>(cataloguesubcategory.CatalogueCategoryId), "Id", "Name", cataloguesubcategory.CatalogueCategoryId);
            return View(cataloguesubcategory);
        }

        // POST: /CatalogueSubCategory/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int? id)
        {
            CatalogueSubCategory cataloguesubcategory = _repository.Find<CatalogueSubCategory>(id);
            if (cataloguesubcategory == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            _repository.Delete<CatalogueSubCategory>(id);
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _repository.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}

﻿using System.Net;
using System.Web.Mvc;
using PaH.BL.Repository;
using PaH.UiModel.ComboModel;
using PaH.UiModel.Resources;

namespace Pet_home.Controllers
{
    /// <summary>
    /// Controller for CRUD operations on Core Seasonal Range
    /// </summary>
    [Authorize]
    public class CoreSeasonalRangeController : Controller
    {
        private readonly IRepository _repository;

        public CoreSeasonalRangeController(IRepository repository)
        {
            _repository = repository;
        }
        // GET: /CoreSeasonalRange/
        public ActionResult Index()
        {
            return View(_repository.GetAll<CoreSeasonalRange>());
        }

        // GET: /CoreSeasonalRange/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            CoreSeasonalRange coreseasonalrange = _repository.Find<CoreSeasonalRange>(id);
            if (coreseasonalrange == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            return View(coreseasonalrange);
        }

        // GET: /CoreSeasonalRange/Create
        public ActionResult Create()
        {
            return View(new CoreSeasonalRange());
        }

        // POST: /CoreSeasonalRange/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Name,Description,IsEnabled")] CoreSeasonalRange coreseasonalrange)
        {
            if (ModelState.IsValid)
            {
                coreseasonalrange = _repository.Add(coreseasonalrange);
                if (coreseasonalrange.Id != 0)
                {
                    TempData["Success"] = Message_Resource.Message_Created;
                    return RedirectToAction("Details", null, new { Id = coreseasonalrange.Id });
                }
            }

            return View(coreseasonalrange);
        }

        // GET: /CoreSeasonalRange/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            CoreSeasonalRange coreseasonalrange = _repository.Find<CoreSeasonalRange>(id);
            if (coreseasonalrange == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            return View(coreseasonalrange);
        }

        // POST: /CoreSeasonalRange/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Name,Description,IsEnabled")] CoreSeasonalRange coreseasonalrange)
        {
            if (ModelState.IsValid)
            {
                if (_repository.Save(coreseasonalrange))
                {
                    TempData["Success"] = Message_Resource.Message_Updated;
                    return RedirectToAction("Details", null, new { Id = coreseasonalrange.Id });
                }
            }
            return View(coreseasonalrange);
        }

        // POST: /CoreSeasonalRange/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int? id)
        {
            CoreSeasonalRange coreseasonalrange = _repository.Find<CoreSeasonalRange>(id);
            if (coreseasonalrange == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            _repository.Delete<CoreSeasonalRange>(id);
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _repository.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}

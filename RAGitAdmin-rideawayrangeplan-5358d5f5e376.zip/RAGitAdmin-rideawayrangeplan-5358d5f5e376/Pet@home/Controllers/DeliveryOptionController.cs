﻿using System.Net;
using System.Web.Mvc;
using PaH.BL.Repository;
using PaH.UiModel.ComboModel;
using PaH.UiModel.Resources;

namespace Pet_home.Controllers
{
    /// <summary>
    /// Controller for CRUD operations on Delivery Operations
    /// </summary>
    [Authorize]
    public class DeliveryOptionController : Controller
    {
        private readonly IRepository _repository;

        public DeliveryOptionController(IRepository repository)
        {
            _repository = repository;
        }

        // GET: /DeliveryOption/
        public ActionResult Index()
        {
            return View(_repository.GetAll<DeliveryOption>());
        }

        // GET: /DeliveryOption/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            DeliveryOption deliveryoption = _repository.Find<DeliveryOption>(id);
            if (deliveryoption == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            return View(deliveryoption);
        }

        // GET: /DeliveryOption/Create
        public ActionResult Create()
        {
            return View(new DeliveryOption());
        }

        // POST: /DeliveryOption/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Option,Description,IsEnabled")] DeliveryOption deliveryoption)
        {
            if (ModelState.IsValid)
            {
                deliveryoption = _repository.Add(deliveryoption);
                if (deliveryoption.Id != 0)
                {
                    TempData["Success"] = Message_Resource.Message_Created;
                    return RedirectToAction("Details", null, new { Id = deliveryoption.Id });
                }
            }

            return View(deliveryoption);
        }

        // GET: /DeliveryOption/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            DeliveryOption deliveryoption = _repository.Find<DeliveryOption>(id);
            if (deliveryoption == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            return View(deliveryoption);
        }

        // POST: /DeliveryOption/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Option,Description,IsEnabled")] DeliveryOption deliveryoption)
        {
            if (ModelState.IsValid)
            {
                if (_repository.Save(deliveryoption))
                {
                    TempData["Success"] = Message_Resource.Message_Updated;
                    return RedirectToAction("Details", null, new { Id = deliveryoption.Id });
                }
            }
            return View(deliveryoption);
        }

        // POST: /DeliveryOption/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int? id)
        {
            DeliveryOption deliveryoption = _repository.Find<DeliveryOption>(id);
            if (deliveryoption == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            _repository.Delete<DeliveryOption>(id);
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _repository.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}

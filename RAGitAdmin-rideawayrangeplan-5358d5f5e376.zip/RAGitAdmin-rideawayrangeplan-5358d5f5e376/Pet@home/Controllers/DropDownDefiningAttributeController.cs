﻿using System.Net;
using System.Web.Mvc;
using PaH.BL.Repository;
using PaH.UiModel.ComboModel;
using PaH.UiModel.Resources;

namespace Pet_home.Controllers
{
    /// <summary>
    /// Controller for CRUD operations on DropDown Defining Attribute
    /// </summary>
    [Authorize]
    public class DropDownDefiningAttributeController : Controller
    {
        private readonly IRepository _repository;

        public DropDownDefiningAttributeController(IRepository repository)
        {
            _repository = repository;
        }

        // GET: /DropDownDefiningAttribute/
        public ActionResult Index()
        {
            return View(_repository.GetAll<DropDownDefiningAttribute>());
        }

        // GET: /DropDownDefiningAttribute/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            DropDownDefiningAttribute dropdowndefiningattribute = _repository.Find<DropDownDefiningAttribute>(id);
            if (dropdowndefiningattribute == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            return View(dropdowndefiningattribute);
        }

        // GET: /DropDownDefiningAttribute/Create
        public ActionResult Create()
        {
            return View(new DropDownDefiningAttribute());
        }

        // POST: /DropDownDefiningAttribute/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,AttributeName,Description,IsEnabled")] DropDownDefiningAttribute dropdowndefiningattribute)
        {
            if (ModelState.IsValid)
            {
                dropdowndefiningattribute = _repository.Add(dropdowndefiningattribute);
                if (dropdowndefiningattribute.Id != 0)
                {
                    TempData["Success"] = Message_Resource.Message_Created;
                    return RedirectToAction("Details", null, new { Id = dropdowndefiningattribute.Id });
                }
            }

            return View(dropdowndefiningattribute);
        }

        // GET: /DropDownDefiningAttribute/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            DropDownDefiningAttribute dropdowndefiningattribute = _repository.Find<DropDownDefiningAttribute>(id);
            if (dropdowndefiningattribute == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            return View(dropdowndefiningattribute);
        }

        // POST: /DropDownDefiningAttribute/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,AttributeName,Description,IsEnabled")] DropDownDefiningAttribute dropdowndefiningattribute)
        {
            if (ModelState.IsValid)
            {
                if (_repository.Save(dropdowndefiningattribute))
                {
                    TempData["Success"] = Message_Resource.Message_Updated;
                    return RedirectToAction("Details", null, new { Id = dropdowndefiningattribute.Id });
                }
            }
            return View(dropdowndefiningattribute);
        }

        // POST: /DropDownDefiningAttribute/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int? id)
        {
            DropDownDefiningAttribute dropdowndefiningattribute = _repository.Find<DropDownDefiningAttribute>(id);
            if (dropdowndefiningattribute == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }

            _repository.Delete<DropDownDefiningAttribute>(id);

            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _repository.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}

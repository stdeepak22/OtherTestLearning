﻿using System.Web.Mvc;

namespace Pet_home.Controllers
{
    /// <summary>
    /// Controller for showing the Error Page only.
    /// </summary>
    public class ErrorController : Controller
    {
        public ActionResult Index()
        {
            return RedirectToAction("ModelNotFound");
        }

        public ActionResult ModelNotFound(string cntrlName = "RangePlan")
        {
            ViewBag.CntrlName = cntrlName;
            return View();
        }
    }
}
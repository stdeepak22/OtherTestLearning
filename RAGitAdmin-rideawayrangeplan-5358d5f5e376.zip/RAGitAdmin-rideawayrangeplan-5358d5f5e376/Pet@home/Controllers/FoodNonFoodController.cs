﻿using System.Net;
using System.Web.Mvc;
using PaH.BL.Repository;
using PaH.UiModel.ComboModel;
using PaH.UiModel.Resources;

namespace Pet_home.Controllers
{
    /// <summary>
    /// Controller for CRUD operations on Food - NonFood type
    /// </summary>
    [Authorize]
    public class FoodNonFoodController : Controller
    {
        private readonly IRepository _repository;

        public FoodNonFoodController(IRepository repository)
        {
            _repository = repository;
        }

        // GET: /FoodNonFood/
        public ActionResult Index()
        {
            return View(_repository.GetAll<FoodNonFood>());
        }

        // GET: /FoodNonFood/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            FoodNonFood foodnonfood = _repository.Find<FoodNonFood>(id);
            if (foodnonfood == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            return View(foodnonfood);
        }

        // GET: /FoodNonFood/Create
        public ActionResult Create()
        {
            return View(new FoodNonFood());
        }

        // POST: /FoodNonFood/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Type,Description,IsEnabled")] FoodNonFood foodnonfood)
        {
            if (ModelState.IsValid)
            {
                foodnonfood = _repository.Add(foodnonfood);
                if (foodnonfood.Id != 0)
                {
                    TempData["Success"] = Message_Resource.Message_Created;
                    return RedirectToAction("Details", null, new { Id = foodnonfood.Id });
                }
            }

            return View(foodnonfood);
        }

        // GET: /FoodNonFood/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            FoodNonFood foodnonfood = _repository.Find<FoodNonFood>(id);
            if (foodnonfood == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            return View(foodnonfood);
        }

        // POST: /FoodNonFood/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Type,Description,IsEnabled")] FoodNonFood foodnonfood)
        {
            if (ModelState.IsValid)
            {
                if (_repository.Save(foodnonfood))
                {
                    TempData["Success"] = Message_Resource.Message_Updated;
                    return RedirectToAction("Details", null, new { Id = foodnonfood.Id });
                }
            }
            return View(foodnonfood);
        }

        // POST: /FoodNonFood/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int? id)
        {
            FoodNonFood foodnonfood = _repository.Find<FoodNonFood>(id);
            if (foodnonfood == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            _repository.Delete<FoodNonFood>(id);
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _repository.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}

﻿using System.Net;
using System.Web.Mvc;
using PaH.BL.Repository;
using PaH.UiModel.ComboModel;
using PaH.UiModel.Resources;

namespace Pet_home.Controllers
{
    /// <summary>
    /// Controller for CRUD operations on Good Better Best
    /// </summary>
    [Authorize]
    public class GBBController : Controller
    {
        private readonly IRepository _repository;

        public GBBController(IRepository repository)
        {
            _repository = repository;
        }

        // GET: /GBB/
        public ActionResult Index()
        {
            return View(_repository.GetAll<GBB>());
        }

        // GET: /GBB/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            GBB gbb = _repository.Find<GBB>(id);
            if (gbb == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            return View(gbb);
        }

        // GET: /GBB/Create
        public ActionResult Create()
        {
            return View(new GBB());
        }

        // POST: /GBB/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Value,Description,IsEnabled")] GBB gbb)
        {
            if (ModelState.IsValid)
            {
                gbb = _repository.Add(gbb);
                if (gbb.Id != 0)
                {
                    TempData["Success"] = Message_Resource.Message_Created;
                    return RedirectToAction("Details", null, new { Id = gbb.Id });
                }
            }
            return View(gbb);
        }

        // GET: /GBB/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            GBB gbb = _repository.Find<GBB>(id);
            if (gbb == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            return View(gbb);
        }

        // POST: /GBB/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Value,Description,IsEnabled")] GBB gbb)
        {
            if (ModelState.IsValid)
            {
                if (_repository.Save(gbb))
                {
                    TempData["Success"] = Message_Resource.Message_Updated;
                    return RedirectToAction("Details", null, new { Id = gbb.Id });
                }
            }
            return View(gbb);
        }

        // POST: /GBB/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int? id)
        {
            GBB gbb = _repository.Find<GBB>(id);
            if (gbb == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            _repository.Delete<GBB>(id);
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _repository.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}

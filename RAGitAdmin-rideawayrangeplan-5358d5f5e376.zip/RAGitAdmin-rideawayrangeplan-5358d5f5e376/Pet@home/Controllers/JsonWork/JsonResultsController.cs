﻿using System.Linq;
using System.Web.Mvc;
using PaH.BL.Repository;
using PaH.UiModel.ComboModel;

namespace Pet_home.Controllers.JsonWork
{
    /// <summary>
    /// a separate controller for Json work
    /// </summary>
    public class JsonResultsController : Controller
    {
        private readonly IRepository _repository;

        public JsonResultsController(IRepository repository)
        {
            _repository = repository;
        }

        /// <summary>
        /// this method takes the RaSubCategoryId and returns
        /// the FirstPartShuftyCode
        /// </summary>
        /// <param name="raSubCatId"></param>
        /// <returns></returns>
        public JsonResult GetAllParentRaCategory(int? raSubCatId)
        {
            object item = null;

            if (raSubCatId != null)
            {

                var sub = _repository.Find<RaSubCategory>(raSubCatId);
                var ra = sub.RaCategory;

                item =
                    new
                        {
                            Name = ra.Name,
                            SubName = sub.Name,
                            AnalysisCode = sub.AnalysisCode,
                            FirstPartShufti = sub.FirstPartShufti
                        };
            }
            return Json(item, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// this method takes Supplier Id and
        /// returns Supplier Code
        /// </summary>
        /// <param name="supplierId"></param>
        /// <returns></returns>
        public JsonResult GetSupplierCode(int? supplierId)
        {
            object item = null;
            if (supplierId != null)
            {
                item = new { _repository.Find<Supplier>(supplierId).Code };
            }

            return Json(item, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// takes ProductCategoryId
        /// and returns Code
        /// </summary>
        /// <param name="prodCatId"></param>
        /// <returns></returns>
        public JsonResult GetProductCategoryCode(int? productCatId)
        {
            object item = null;
            if (productCatId != null)
            {
                item = new { _repository.Find<ProductCategory>(productCatId).Code };
            }
            return Json(item, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetCatalogueCategory(int? subCatalogueCatId)
        {
            object item = null;
            if (subCatalogueCatId != null)
            {
                item = new { _repository.Find<CatalogueSubCategory>(subCatalogueCatId).CatalogueCategory.Name };
            }

            return Json(item, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// it takes packsize id and returns
        /// PackSize Quantity
        /// </summary>
        /// <param name="packSizeId"></param>
        /// <returns></returns>
        public JsonResult GetBuyingPackQuantity(int? packSizeId)
        {
            object item = null;
            if (packSizeId != null)
            {
                item = new { _repository.Find<PackSize>(packSizeId).Quantity };
            }
            return Json(item, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// takes the RaCategoryId and returns the RaSubCategories
        /// </summary>
        /// <param name="raCatId"></param>
        /// <returns></returns>
        //JsonResults/RaSubCategoryList/RaCategoryId
        public JsonResult RaSubCategoryList(int? raCatId)
        {
            object item = null;
            if (raCatId != null)
            {
                var items = _repository.GetComboForNew<RaSubCategory>()
                                       .Where(c => c.RaCategoryId == raCatId)
                                       .ToList();
                item = new SelectList(items, "Id", "Name");
            }
            return Json(item, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// takes the WebCategoryId and returns the WebSubCategories
        /// </summary>
        /// <param name="webCatId"></param>
        /// <returns></returns>
        //JsonResults/WebSubCategoryList/WebCategoryId
        public JsonResult WebSubCategoryList(int? webCatId)
        {
            object item = null;
            if (webCatId != null)
            {
                var items = _repository.GetComboForNew<WebSubCategory>()
                                       .Where(c => c.WebCategoryId == webCatId)
                                       .ToList();
                item = new SelectList(items, "Id", "Name");
            }
            return Json(item, JsonRequestBehavior.AllowGet);
        }
    }
}
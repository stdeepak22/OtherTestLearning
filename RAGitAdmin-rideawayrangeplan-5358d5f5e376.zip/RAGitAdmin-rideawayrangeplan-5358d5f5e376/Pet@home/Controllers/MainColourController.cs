﻿using System.Net;
using System.Web.Mvc;
using PaH.BL.Repository;
using PaH.UiModel.ComboModel;
using PaH.UiModel.Resources;

namespace Pet_home.Controllers
{
    /// <summary>
    /// Controller for CRUD operations on Main Colours List
    /// </summary>
    [Authorize]
    public class MainColourController : Controller
    {
        private readonly IRepository _repository;

        public MainColourController(IRepository repository)
        {
            _repository = repository;
        }

        // GET: /MainColour/
        public ActionResult Index()
        {
            return View(_repository.GetAll<MainColour>());
        }

        // GET: /MainColour/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            MainColour maincolour = _repository.Find<MainColour>(id);
            if (maincolour == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            return View(maincolour);
        }

        // GET: /MainColour/Create
        public ActionResult Create()
        {
            return View(new MainColour());
        }

        // POST: /MainColour/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Colour,Description,IsEnabled")] MainColour maincolour)
        {
            if (ModelState.IsValid)
            {
                maincolour = _repository.Add(maincolour);
                if (maincolour.Id != 0)
                {
                    TempData["Success"] = Message_Resource.Message_Created;
                    return RedirectToAction("Details", null, new { Id = maincolour.Id });
                }
            }
            return View(maincolour);
        }

        // GET: /MainColour/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            MainColour maincolour = _repository.Find<MainColour>(id);
            if (maincolour == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            return View(maincolour);
        }

        // POST: /MainColour/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Colour,Description,IsEnabled")] MainColour maincolour)
        {
            if (ModelState.IsValid)
            {
                if (_repository.Save(maincolour))
                {
                    TempData["Success"] = Message_Resource.Message_Updated;
                    return RedirectToAction("Details", null, new { Id = maincolour.Id });
                }
            }
            return View(maincolour);
        }

        // POST: /MainColour/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int? id)
        {
            MainColour maincolour = _repository.Find<MainColour>(id);
            if (maincolour == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            _repository.Delete<MainColour>(id);
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _repository.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}

﻿using System.Net;
using System.Web.Mvc;
using PaH.BL.Repository;
using PaH.UiModel.ComboModel;
using PaH.UiModel.Resources;

namespace Pet_home.Controllers
{
    /// <summary>
    /// Controller for CRUD operations on Outlet
    /// </summary>
    [Authorize]
    public class OutletController : Controller
    {
        private readonly IRepository _repository;

        public OutletController(IRepository repository)
        {
            _repository = repository;
        }

        // GET: /Outlet/
        public ActionResult Index()
        {
            return View(_repository.GetAll<Outlet>());
        }

        // GET: /Outlet/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            Outlet outlet = _repository.Find<Outlet>(id);
            if (outlet == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            return View(outlet);
        }

        // GET: /Outlet/Create
        public ActionResult Create()
        {
            return View(new Outlet());
        }

        // POST: /Outlet/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Type,Description,IsEnabled")] Outlet outlet)
        {
            if (ModelState.IsValid)
            {
                outlet = _repository.Add(outlet);
                if (outlet.Id != 0)
                {
                    TempData["Success"] = Message_Resource.Message_Created;
                    return RedirectToAction("Details", null, new { Id = outlet.Id });
                }
            }
            return View(outlet);
        }

        // GET: /Outlet/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            Outlet outlet = _repository.Find<Outlet>(id);
            if (outlet == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            return View(outlet);
        }

        // POST: /Outlet/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Type,Description,IsEnabled")] Outlet outlet)
        {
            if (ModelState.IsValid)
            {
                if (_repository.Save(outlet))
                {
                    TempData["Success"] = Message_Resource.Message_Updated;
                    return RedirectToAction("Details", null, new { Id = outlet.Id });
                }
            }
            return View(outlet);
        }

        // POST: /Outlet/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int? id)
        {
            Outlet outlet = _repository.Find<Outlet>(id);
            if (outlet == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            _repository.Delete<Outlet>(id);
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _repository.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}

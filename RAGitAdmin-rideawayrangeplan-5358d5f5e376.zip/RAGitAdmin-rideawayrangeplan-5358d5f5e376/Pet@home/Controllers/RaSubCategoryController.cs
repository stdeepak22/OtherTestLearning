﻿using System.Net;
using System.Web.Mvc;
using PaH.BL.Repository;
using PaH.UiModel.ComboModel;
using PaH.UiModel.Resources;

namespace Pet_home.Controllers
{
    /// <summary>
    /// Controller for CRUD operations on Ra Sub Category
    /// </summary>
    [Authorize]
    public class RaSubCategoryController : Controller
    {
        private readonly IRepository _repository;

        public RaSubCategoryController(IRepository repository)
        {
            _repository = repository;
        }

        // GET: /RaSubCategory/
        public ActionResult Index()
        {
            return View(_repository.GetAll<RaSubCategory>());
        }

        // GET: /RaSubCategory/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            RaSubCategory rasubcategory = _repository.Find<RaSubCategory>(id);
            if (rasubcategory == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            return View(rasubcategory);
        }

        // GET: /RaSubCategory/Create
        public ActionResult Create()
        {
            ViewBag.RaCategoryId = new SelectList(_repository.GetComboForNew<RaCategory>(), "Id", "Name");
            return View(new RaSubCategory());
        }

        // POST: /RaSubCategory/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,AnalysisCode,Name,FirstPartShufti,RaCategoryId,Description,IsEnabled")] RaSubCategory rasubcategory)
        {
            if (ModelState.IsValid)
            {
                rasubcategory = _repository.Add(rasubcategory);
                if (rasubcategory.Id != 0)
                {
                    TempData["Success"] = Message_Resource.Message_Created;
                    return RedirectToAction("Details", null, new { Id = rasubcategory.Id });
                }
            }
            ViewBag.RaCategoryId = new SelectList(_repository.GetComboForNew<RaCategory>(), "Id", "Name", rasubcategory.RaCategoryId);
            return View(rasubcategory);
        }

        // GET: /RaSubCategory/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            RaSubCategory rasubcategory = _repository.Find<RaSubCategory>(id);
            if (rasubcategory == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            ViewBag.RaCategoryId = new SelectList(_repository.GetComboForEdit<RaCategory>(rasubcategory.RaCategoryId), "Id", "Name", rasubcategory.RaCategoryId);
            return View(rasubcategory);
        }

        // POST: /RaSubCategory/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,AnalysisCode,Name,FirstPartShufti,RaCategoryId,Description,IsEnabled")] RaSubCategory rasubcategory)
        {
            if (ModelState.IsValid)
            {
                if (!_repository.IsEnabled<RaCategory>(rasubcategory.RaCategoryId))
                {
                    ModelState.AddModelError("RaCategoryId", Message_Resource.Message_ModelError);
                }
                else if (_repository.Save(rasubcategory))
                {
                    TempData["Success"] = Message_Resource.Message_Updated;
                    return RedirectToAction("Details", null, new { Id = rasubcategory.Id });
                }
            }
            ViewBag.RaCategoryId = new SelectList(_repository.GetComboForEdit<RaCategory>(rasubcategory.RaCategoryId), "Id", "Name", rasubcategory.RaCategoryId);
            return View(rasubcategory);
        }

        // POST: /RaSubCategory/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int? id)
        {
            RaSubCategory rasubcategory = _repository.Find<RaSubCategory>(id);
            if (rasubcategory == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            _repository.Delete<RaSubCategory>(id);
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _repository.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}

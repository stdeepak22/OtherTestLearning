﻿using System.Linq;
using System.Net;
using System.Web.Mvc;
using PaH.BL.Repository;
using PaH.UiModel.ComboModel;
using PaH.UiModel.Resources;

namespace Pet_home.Controllers
{
    /// <summary>
    /// Controller for CRUD operations on Ra sub Sub Category
    /// </summary>
    [Authorize]
    public class RaSubSubCategoryController : Controller
    {
        private readonly IRepository _repository;

        public RaSubSubCategoryController(IRepository repository)
        {
            _repository = repository;
        }

        // GET: /RaSubSubCategory/
        public ActionResult Index()
        {
            return View(_repository.GetAll<RaSubSubCategory>());
        }

        // GET: /RaSubSubCategory/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            RaSubSubCategory rasubsubcategory = _repository.Find<RaSubSubCategory>(id);

            if (rasubsubcategory == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            return View(rasubsubcategory);
        }

        // GET: /RaSubSubCategory/Create
        public ActionResult Create()
        {
            ViewBag.RaCategoryId = new SelectList(_repository.GetComboForNew<RaCategory>(), "Id", "Name");
            ViewBag.RaSubCategoryId = new SelectList(_repository.GetComboForNew<RaSubCategory>().Where(c => c.Id < 0), "Id", "Name");
            return View(new RaSubSubCategory());
        }

        // POST: /RaSubSubCategory/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Name,RaSubCategoryId,RaCategoryId,Description,IsEnabled")] RaSubSubCategory rasubsubcategory)
        {
            if (ModelState.IsValid)
            {
                rasubsubcategory = _repository.Add(rasubsubcategory);
                if (rasubsubcategory.Id != 0)
                {
                    TempData["Success"] = Message_Resource.Message_Created;
                    return RedirectToAction("Details", null, new { Id = rasubsubcategory.Id });
                }
            }
            ViewBag.RaCategoryId = new SelectList(_repository.GetComboForNew<RaCategory>(), "Id", "Name", rasubsubcategory.RaCategoryId);
            ViewBag.RaSubCategoryId = new SelectList(_repository.GetComboForNew<RaSubCategory>().Where(c => c.RaCategoryId == rasubsubcategory.RaCategoryId), "Id", "Name", rasubsubcategory.RaSubCategoryId);
            return View(rasubsubcategory);
        }

        // GET: /RaSubSubCategory/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            RaSubSubCategory rasubsubcategory = _repository.Find<RaSubSubCategory>(id);
            if (rasubsubcategory == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            ViewBag.RaCategoryId = new SelectList(_repository.GetComboForEdit<RaCategory>(rasubsubcategory.RaCategoryId), "Id", "Name", rasubsubcategory.RaCategoryId);
            ViewBag.RaSubCategoryId = new SelectList(
                _repository.GetComboForEdit<RaSubCategory>(rasubsubcategory.RaSubCategoryId)
                .Where(c => c.RaCategoryId == rasubsubcategory.RaCategoryId)
                , "Id", "Name", rasubsubcategory.RaSubCategoryId);
            return View(rasubsubcategory);
        }

        // POST: /RaSubSubCategory/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(RaSubSubCategory rasubsubcategory)
        {
            if (ModelState.IsValid)
            {
                if (!_repository.IsEnabled<RaCategory>(rasubsubcategory.RaCategoryId))
                {
                    ModelState.AddModelError("RaCategoryId", Message_Resource.Message_ModelError);
                }
                else if (!_repository.IsEnabled<RaSubCategory>(rasubsubcategory.RaSubCategoryId))
                {
                    ModelState.AddModelError("RaSubCategoryId", Message_Resource.Message_ModelError);
                }
                else if (_repository.Save(rasubsubcategory))
                {
                    TempData["Success"] = Message_Resource.Message_Updated;
                    return RedirectToAction("Details", null, new { Id = rasubsubcategory.Id });
                }
            }
            ViewBag.RaCategoryId = new SelectList(_repository.GetComboForEdit<RaCategory>(rasubsubcategory.RaCategoryId), "Id", "Name", rasubsubcategory.RaCategoryId);
            ViewBag.RaSubCategoryId = new SelectList(
                _repository.GetComboForEdit<RaSubCategory>(rasubsubcategory.RaSubCategoryId)
                .Where(c => c.RaCategoryId == rasubsubcategory.RaCategoryId)
                , "Id", "Name", rasubsubcategory.RaSubCategoryId);
            return View(rasubsubcategory);
        }

        // POST: /RaSubSubCategory/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int? id)
        {
            RaSubSubCategory rasubsubcategory = _repository.Find<RaSubSubCategory>(id);
            if (rasubsubcategory == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            _repository.Delete<RaSubSubCategory>(id);
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _repository.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}

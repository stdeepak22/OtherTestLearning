﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using PaH.BL.Repository;
using PaH.ImportExport;
using PaH.ImportExport.Export;
using PaH.UiModel.EntityModel;
using PaH.UiModel.ComboModel;
using PaH.UiModel.Resources;

namespace Pet_home.Controllers
{
    /// <summary>
    /// Controller for CRUD operations on Range Plan
    /// </summary>
    [Authorize]
    public class RangePlanController : Controller
    {
        private readonly IRepository _repository;

        public RangePlanController(IRepository repository)
        {
            _repository = repository;
        }

        // GET: /RangePlan/
        public ActionResult Index()
        {
            var paginationSize = Request.QueryString.GetValues("PageSize");
            if ((paginationSize == null) || (paginationSize.Length == 0))
            {
                ViewBag.PageSize = 10;
            }
            else
            {
                try
                {
                    ViewBag.PageSize = int.Parse(paginationSize[0]);
                }
                catch (Exception)
                {
                    ViewBag.PageSize = 10;
                }
            }
            
            return View(_repository.GetAllRangePlanIndexView<RangePlanIndexView>());
        }

        public ActionResult Export()
        {
            var filterString = Request.QueryString.GetValues("grid-filter");
            var reportType = "RangePlan";

            List<GridFilter> gridFilters = new List<GridFilter>();
            try
            {
                if (Request.QueryString.GetValues("ReportType") != null)
                {
                    reportType = Request.QueryString.GetValues("ReportType")[0];
                }
                if (filterString != null)
                {
                    IEnumerable<string[]> srtArr =
                        filterString[0].Split('&').Select(c => c.Split(new string[] { "__" }, StringSplitOptions.None));

                    gridFilters = srtArr.Select(c =>
                                                new GridFilter
                                                    {
                                                        FilterOn = c[0],
                                                        FilterType =
                                                            (SearchType)
                                                            System.Enum.GetValues(typeof(SearchType))
                                                                  .GetValue(int.Parse(c[1]) - 1),
                                                        FilterValue = c[2].Replace("%","[%]")
                                                    }).ToList();
                }

                var item = new ImportExport("");
                var reportTypeEnum = ReportType.RangePlan;
                switch (reportType)
                {
                    case "RangePlan":
                        reportTypeEnum = ReportType.RangePlan;
                        break;
                    case "Create":
                        reportTypeEnum = ReportType.Create;
                        break;
                    case "Hanger7":
                        reportTypeEnum = ReportType.Hanger7;
                        break;
                }

                var stream = item.Export(gridFilters, _repository, reportTypeEnum) as MemoryStream;
                if (stream != null)
                {
                    return File(stream.ToArray(), "application/vnd.ms-excel", "Export_" + reportType + ".xlsx");
                }
                else
                {
                    ViewBag.ErrorMessge = Message_Resource.Message_WentWrong;
                    return View("Export");
                }
            }
            catch (Exception e)
            {
                ViewBag.ErrorMessge = e.Message;
                return View("Export");
            }
        }

        // GET: /RangePlan/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            RangePlan rangeplan = _repository.Find<RangePlan>(id);
            if (rangeplan == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            return View(rangeplan);
        }

        // GET: /RangePlan/Create
        public ActionResult Create()
        {
            ViewBag.AgeId = new SelectList(_repository.GetComboForNew<Age>(), "Id", "Value");
            // make text box like web sub cat.
            ViewBag.SubCatalogueCategoryId = new SelectList(_repository.GetSpecialComboOfCatalogueCategoryNew(), "Item1", "Item2");
            ViewBag.GBBId = new SelectList(_repository.GetComboForNew<GBB>(), "Id", "Value");
            ViewBag.GenderId = new SelectList(_repository.GetComboForNew<Gender>(), "Id", "Title");
            ViewBag.MainColourId = new SelectList(_repository.GetComboForNew<MainColour>(), "Id", "Colour");

            #region  Changes under CR01
            ViewBag.SizeTypeId = new SelectList(_repository.GetComboForNew<SizeType>(), "Id", "Value");
            #endregion

            ViewBag.NewRIId = new SelectList(_repository.GetComboForNew<NewRI>(), "Id", "Name");
            ViewBag.OutletId = new SelectList(_repository.GetComboForNew<Outlet>(), "Id", "Type");
            ViewBag.ProdCategoryId = new SelectList(_repository.GetComboForNew<ProductCategory>(), "Id", "Name");
            // make text box like web sub cat.
            ViewBag.RaSubCategoryId = new SelectList(_repository.GetSpecialComboOfRaCatNew(), "Item1", "Item2");
            // its entabled
            ViewBag.SuppId = new SelectList(_repository.GetComboForNew<Supplier>(), "Id", "Name");
            ViewBag.VATId = new SelectList(_repository.GetComboForNew<VAT>(), "Id", "Value");
            ViewBag.FreeCode7Id = new SelectList(_repository.GetComboForNew<YesNo>(), "Id", "Value");
            ViewBag.HeroProductId = new SelectList(_repository.GetComboForNew<YesNo>(), "Id", "Value");
            ViewBag.PackSizeId = new SelectList(_repository.GetComboForNew<PackSize>(), "Id", "Name");
            ViewBag.CoreSeasonalRangeId = new SelectList(_repository.GetComboForNew<CoreSeasonalRange>(), "Id", "Name");
            ViewBag.ExclusiveToRAId = new SelectList(_repository.GetComboForNew<YesNo>(), "Id", "Value");
            return View(new RangePlan());
        }

        // POST: /RangePlan/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(RangePlan rangeplan)
        {
            if (ModelState.IsValid)
            {
                if (_repository.IsRaProductCodeUnique(rangeplan.RAProductCodeNew))
                {
                    rangeplan = _repository.Add(rangeplan);
                    if (rangeplan.Id != 0)
                    {
                        TempData["Success"] = Message_Resource.Message_Created;
                        return RedirectToAction("Details", null, new { Id = rangeplan.Id });
                    }
                }
                else
                {
                    ModelState.AddModelError("RAProductCodeNew", Message_Resource.Message_NotUnique);
                }
            }

            ViewBag.AgeId = new SelectList(_repository.GetComboForNew<Age>(), "Id", "Value", rangeplan.AgeId);
            // make text box like web sub cat.
            ViewBag.SubCatalogueCategoryId = new SelectList(_repository.GetSpecialComboOfCatalogueCategoryNew(), "Item1", "Item2", rangeplan.SubCatalogueCategoryId);
            ViewBag.GBBId = new SelectList(_repository.GetComboForNew<GBB>(), "Id", "Value", rangeplan.GBBId);
            ViewBag.GenderId = new SelectList(_repository.GetComboForNew<Gender>(), "Id", "Title", rangeplan.GenderId);
            ViewBag.MainColourId = new SelectList(_repository.GetComboForNew<MainColour>(), "Id", "Colour", rangeplan.MainColourId);
            #region  Changes under CR01
            ViewBag.SizeTypeId = new SelectList(_repository.GetComboForNew<SizeType>(), "Id", "Value", rangeplan.SizeTypeId);
            #endregion
            ViewBag.NewRIId = new SelectList(_repository.GetComboForNew<NewRI>(), "Id", "Name", rangeplan.NewRIId);
            ViewBag.OutletId = new SelectList(_repository.GetComboForNew<Outlet>(), "Id", "Type", rangeplan.OutletId);
            ViewBag.ProdCategoryId = new SelectList(_repository.GetComboForNew<ProductCategory>(), "Id", "Name", rangeplan.ProdCategoryId);
            // make text box like web sub cat.
            ViewBag.RaSubCategoryId = new SelectList(_repository.GetSpecialComboOfRaCatNew(), "Item1", "Item2", rangeplan.RaSubCategoryId);
            ViewBag.SuppId = new SelectList(_repository.GetComboForNew<Supplier>(), "Id", "Name", rangeplan.SuppId);
            ViewBag.VATId = new SelectList(_repository.GetComboForNew<VAT>(), "Id", "Value", rangeplan.VATId);
            ViewBag.HeroProductId = new SelectList(_repository.GetComboForNew<YesNo>(), "Id", "Value", rangeplan.HeroProductId);
            ViewBag.FreeCode7Id = new SelectList(_repository.GetComboForNew<YesNo>(), "Id", "Value", rangeplan.FreeCode7Id);
            ViewBag.PackSizeId = new SelectList(_repository.GetComboForNew<PackSize>(), "Id", "Name", rangeplan.PackSizeId);
            ViewBag.CoreSeasonalRangeId = new SelectList(_repository.GetComboForNew<CoreSeasonalRange>(), "Id", "Name", rangeplan.CoreSeasonalRangeId);
            ViewBag.ExclusiveToRAId = new SelectList(_repository.GetComboForNew<YesNo>(), "Id", "Value", rangeplan.ExclusiveToRAId);
            ViewBag.IsErrorOccured = true;
            return View(rangeplan);
        }

        // GET: /RangePlan/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            RangePlan rangeplan = _repository.Find<RangePlan>(id);

            if (rangeplan == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            ViewBag.AgeId = new SelectList(_repository.GetComboForEdit<Age>(rangeplan.AgeId), "Id", "Value", rangeplan.AgeId);
            // make text box like web sub cat.
            ViewBag.SubCatalogueCategoryId = new SelectList(_repository.GetSpecialComboOfCatalogueCategoryEdit(rangeplan.SubCatalogueCategoryId), "Item1", "Item2", rangeplan.SubCatalogueCategoryId);
            ViewBag.GBBId = new SelectList(_repository.GetComboForEdit<GBB>(rangeplan.GBBId), "Id", "Value", rangeplan.GBBId);
            ViewBag.GenderId = new SelectList(_repository.GetComboForEdit<Gender>(rangeplan.GenderId), "Id", "Title", rangeplan.GenderId);
            ViewBag.MainColourId = new SelectList(_repository.GetComboForEdit<MainColour>(rangeplan.MainColourId), "Id", "Colour", rangeplan.MainColourId);
            #region  Changes under CR01
            ViewBag.SizeTypeId = new SelectList(_repository.GetComboForNew<SizeType>(), "Id", "Value", rangeplan.SizeTypeId);
            #endregion
            ViewBag.NewRIId = new SelectList(_repository.GetComboForEdit<NewRI>(rangeplan.NewRIId), "Id", "Name", rangeplan.NewRIId);
            ViewBag.OutletId = new SelectList(_repository.GetComboForEdit<Outlet>(rangeplan.OutletId), "Id", "Type", rangeplan.OutletId);
            ViewBag.ProdCategoryId = new SelectList(_repository.GetComboForEdit<ProductCategory>(rangeplan.ProdCategoryId), "Id", "Name", rangeplan.ProdCategoryId);
            // make text box like web sub cat.
            ViewBag.RaSubCategoryId = new SelectList(_repository.GetSpecialComboOfRaCatEdit(rangeplan.RaSubCategoryId), "Item1", "Item2", rangeplan.RaSubCategoryId);
            ViewBag.SuppId = new SelectList(_repository.GetComboForEdit<Supplier>(rangeplan.SuppId), "Id", "Name", rangeplan.SuppId);
            ViewBag.VATId = new SelectList(_repository.GetComboForEdit<VAT>(rangeplan.VATId), "Id", "Value", rangeplan.VATId);
            ViewBag.FreeCode7Id = new SelectList(_repository.GetComboForEdit<YesNo>(rangeplan.FreeCode7Id), "Id", "Value", rangeplan.FreeCode7Id);
            ViewBag.HeroProductId = new SelectList(_repository.GetComboForEdit<YesNo>(rangeplan.HeroProductId), "Id", "Value", rangeplan.HeroProductId);
            ViewBag.PackSizeId = new SelectList(_repository.GetComboForEdit<PackSize>(rangeplan.PackSizeId), "Id", "Name", rangeplan.PackSizeId);
            ViewBag.CoreSeasonalRangeId = new SelectList(_repository.GetComboForEdit<CoreSeasonalRange>(rangeplan.CoreSeasonalRangeId), "Id", "Name", rangeplan.CoreSeasonalRangeId);
            ViewBag.ExclusiveToRAId = new SelectList(_repository.GetComboForEdit<YesNo>(rangeplan.ExclusiveToRAId), "Id", "Value", rangeplan.ExclusiveToRAId);
            return View(rangeplan);
        }

        // POST: /RangePlan/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(RangePlan rangeplan)
        {
            if (ModelState.IsValid)
            {
                if (!_repository.IsEnabled<Age>(rangeplan.AgeId))
                {
                    ModelState.AddModelError("AgeId", Message_Resource.Message_ModelError);
                }
                else if (!_repository.IsEnabled<CatalogueSubCategory>(rangeplan.SubCatalogueCategoryId))
                {
                    ModelState.AddModelError("SubCatalogueCategoryId", Message_Resource.Message_ModelError);
                }
                else if (!_repository.IsEnabled<GBB>(rangeplan.GBBId))
                {
                    ModelState.AddModelError("GBBId", Message_Resource.Message_ModelError);
                }
                else if (!_repository.IsEnabled<Gender>(rangeplan.GenderId))
                {
                    ModelState.AddModelError("GenderId", Message_Resource.Message_ModelError);
                }
                else if (!_repository.IsEnabled<MainColour>(rangeplan.MainColourId))
                {
                    ModelState.AddModelError("MainColourId", Message_Resource.Message_ModelError);
                }
                #region  Changes under CR01
                else if (!_repository.IsEnabled<SizeType>(rangeplan.SizeTypeId))
                {
                    ModelState.AddModelError("SizeTypeId", Message_Resource.Message_ModelError);
                }            
                #endregion
                else if (!_repository.IsEnabled<NewRI>(rangeplan.NewRIId))
                {
                    ModelState.AddModelError("NewRIId", Message_Resource.Message_ModelError);
                }
                else if (!_repository.IsEnabled<Outlet>(rangeplan.OutletId))
                {
                    ModelState.AddModelError("OutletId", Message_Resource.Message_ModelError);
                }
                else if (!_repository.IsEnabled<ProductCategory>(rangeplan.ProdCategoryId))
                {
                    ModelState.AddModelError("ProdCategoryId", Message_Resource.Message_ModelError);
                }
                // make text box like web sub cat.
                else if (!_repository.IsEnabled<RaSubCategory>(rangeplan.RaSubCategoryId))
                {
                    ModelState.AddModelError("RaSubCategoryId", Message_Resource.Message_ModelError);
                }
                else if (!_repository.IsEnabled<Supplier>(rangeplan.SuppId))
                {
                    ModelState.AddModelError("SuppId", Message_Resource.Message_ModelError);
                }
                else if (!_repository.IsEnabled<VAT>(rangeplan.VATId))
                {
                    ModelState.AddModelError("VATId", Message_Resource.Message_ModelError);
                }
                else if (!_repository.IsEnabled<YesNo>(rangeplan.FreeCode7Id))
                {
                    ModelState.AddModelError("FreeCode7Id", Message_Resource.Message_ModelError);
                }
                else if (!_repository.IsEnabled<YesNo>(rangeplan.HeroProductId))
                {
                    ModelState.AddModelError("HeroProductId", Message_Resource.Message_ModelError);
                }
                else if (!_repository.IsEnabled<PackSize>(rangeplan.PackSizeId))
                {
                    ModelState.AddModelError("PackSizeId", Message_Resource.Message_ModelError);
                }
                else if (!_repository.IsEnabled<CoreSeasonalRange>(rangeplan.CoreSeasonalRangeId))
                {
                    ModelState.AddModelError("CoreSeasonalRangeId", Message_Resource.Message_ModelError);
                }
                else if (!_repository.IsEnabled<YesNo>(rangeplan.ExclusiveToRAId))
                {
                    ModelState.AddModelError("ExclusiveToRAId", Message_Resource.Message_ModelError);
                }
                else if (_repository.Save(rangeplan))
                {
                    TempData["Success"] = Message_Resource.Message_Updated;
                    return RedirectToAction("Details", null, new { Id = rangeplan.Id });
                }
            }

            ViewBag.AgeId = new SelectList(_repository.GetComboForEdit<Age>(rangeplan.AgeId), "Id", "Value", rangeplan.AgeId);
            // make text box like web sub cat.
            ViewBag.SubCatalogueCategoryId = new SelectList(_repository.GetSpecialComboOfCatalogueCategoryEdit(rangeplan.SubCatalogueCategoryId), "Item1", "Item2", rangeplan.SubCatalogueCategoryId);
            ViewBag.GBBId = new SelectList(_repository.GetComboForEdit<GBB>(rangeplan.GBBId), "Id", "Value", rangeplan.GBBId);
            ViewBag.GenderId = new SelectList(_repository.GetComboForEdit<Gender>(rangeplan.GenderId), "Id", "Title", rangeplan.GenderId);
            ViewBag.MainColourId = new SelectList(_repository.GetComboForEdit<MainColour>(rangeplan.MainColourId), "Id", "Colour", rangeplan.MainColourId);
            #region  Changes under CR01
            ViewBag.SizeTypeId = new SelectList(_repository.GetComboForNew<SizeType>(), "Id", "Value", rangeplan.SizeTypeId);
            #endregion
            ViewBag.NewRIId = new SelectList(_repository.GetComboForEdit<NewRI>(rangeplan.NewRIId), "Id", "Name", rangeplan.NewRIId);
            ViewBag.OutletId = new SelectList(_repository.GetComboForEdit<Outlet>(rangeplan.OutletId), "Id", "Type", rangeplan.OutletId);
            ViewBag.ProdCategoryId = new SelectList(_repository.GetComboForEdit<ProductCategory>(rangeplan.ProdCategoryId), "Id", "Name", rangeplan.ProdCategoryId);
            // make text box like web sub cat.
            ViewBag.RaSubCategoryId = new SelectList(_repository.GetSpecialComboOfRaCatEdit(rangeplan.RaSubCategoryId), "Item1", "Item2", rangeplan.RaSubCategoryId);
            ViewBag.SuppId = new SelectList(_repository.GetComboForEdit<Supplier>(rangeplan.SuppId), "Id", "Name", rangeplan.SuppId);
            ViewBag.VATId = new SelectList(_repository.GetComboForEdit<VAT>(rangeplan.VATId), "Id", "Value", rangeplan.VATId);
            ViewBag.FreeCode7Id = new SelectList(_repository.GetComboForEdit<YesNo>(rangeplan.FreeCode7Id), "Id", "Value", rangeplan.FreeCode7Id);
            ViewBag.HeroProductId = new SelectList(_repository.GetComboForEdit<YesNo>(rangeplan.HeroProductId), "Id", "Value", rangeplan.HeroProductId);
            ViewBag.PackSizeId = new SelectList(_repository.GetComboForEdit<PackSize>(rangeplan.PackSizeId), "Id", "Name", rangeplan.PackSizeId);
            ViewBag.CoreSeasonalRangeId = new SelectList(_repository.GetComboForEdit<CoreSeasonalRange>(rangeplan.CoreSeasonalRangeId), "Id", "Name", rangeplan.CoreSeasonalRangeId);
            ViewBag.ExclusiveToRAId = new SelectList(_repository.GetComboForEdit<YesNo>(rangeplan.ExclusiveToRAId), "Id", "Value", rangeplan.ExclusiveToRAId);
            ViewBag.IsErrorOccured = true;
            return View(rangeplan);
        }

        // POST: /RangePlan/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int? id)
        {
            RangePlan rangeplan = _repository.Find<RangePlan>(id);
            if (rangeplan == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            _repository.Delete<RangePlan>(id);
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _repository.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}

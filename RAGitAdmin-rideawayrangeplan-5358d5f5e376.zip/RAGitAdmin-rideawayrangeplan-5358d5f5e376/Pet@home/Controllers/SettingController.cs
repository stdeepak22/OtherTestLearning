﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Mvc;
using PaH.BL.Repository;
using PaH.ImportExport;
using PaH.UiModel.BaseClass;
using PaH.UiModel.Resources;

namespace Pet_home.Controllers
{
    /// <summary>
    /// Controller for File Upload and Setting up the Master Data (Combos)
    /// </summary>
    [Authorize]
    public class SettingController : Controller
    {
        private readonly IRepository _repository;

        public SettingController(IRepository repository)
        {
            _repository = repository;
        }

        //
        // GET: /Setting/
        public ActionResult Index()
        {
            Assembly modelAssembly = typeof(BaseEntity).Assembly;
            var allDropdown = modelAssembly.GetTypes().Where(c => c.IsSubclassOf(typeof(ComboModelBase)));
            ViewBag.Param = allDropdown;
            return View();
        }

        [HttpGet]
        public ActionResult FileImport()
        {
            return RedirectToAction("Index");
            //return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult FileImport(bool importList, bool importRangePlan, bool overwritePacketSize, bool overwriteRangePlanData)
        {

            string excelSaveAsFileName = String.Empty;
            string dtWithOutSpacesSymbols = String.Empty;
            dtWithOutSpacesSymbols = DateTime.Now.ToString("yyyy-MM-dd HH.mm").Replace(".", string.Empty).Replace("-", string.Empty).Replace(" ", string.Empty);
            #region save inside application itself else can face permission issue
            //const string path = @"D:\Temp\";
            var path = HttpContext.Server.MapPath("~/App_Data") + "\\Import"; //+ DateTime.Now.ToString("yyyy-MM-dd HH.mm");
            #endregion

            try
            {
                //Directory Check
                var uploadDirectory = !Directory.Exists(path) ? Directory.CreateDirectory(path) : new DirectoryInfo(path);
                HttpPostedFileBase excelFile = Request.Files["fileName"];

                if ((excelFile != null) && (excelFile.FileName.Substring(excelFile.FileName.LastIndexOf('.')).ToLower() == ".xlsx"))
                {

                    excelSaveAsFileName = excelFile.FileName.Substring(excelFile.FileName.LastIndexOf('\\') + 1, excelFile.FileName.LastIndexOf('.') - excelFile.FileName.LastIndexOf('\\') - 1) + '-' + dtWithOutSpacesSymbols + excelFile.FileName.Substring(excelFile.FileName.LastIndexOf('.'));
                    excelFile.SaveAs(uploadDirectory.FullName + @"\" + excelSaveAsFileName);

                    //excelFile.SaveAs(Server.MapPath("~\\App_Data\\Import\\" + excelSaveAsFileName));
                    if (importList || importRangePlan)
                    {
                        using (var obj = new ImportExport(uploadDirectory.FullName + @"\" + excelSaveAsFileName))
                        {
                            try
                            {
                                ViewBag.Message = obj.Import(importList, importRangePlan, _repository, User.Identity.Name, overwritePacketSize, overwriteRangePlanData);
                                ViewBag.Result = "success";
                            }
                            catch (Exception ex)
                            {
                                ViewBag.Result = "danger";
                                ViewBag.Message = new[] { string.Empty, ex.Message };
                            }
                        }
                    }
                }
                else
                {
                    ViewBag.Message = new[] { string.Empty, Message_Resource.Message_XLSXFile };
                }
            }
            catch (Exception ex)
            {
                ViewBag.Message = new[] { string.Empty, ex.Message };
            }
            return View();
        }

        [ValidateAntiForgeryToken]
        public ActionResult ListMaintenance(string modelSelected)
        {
            string str = modelSelected;
            var controllerName = GetControllerName(str);
            return RedirectToAction("Index", controllerName.Substring(0, controllerName.Length - "Controller".Length));
        }

        private static string GetControllerName(string modelName)
        {
            string result = String.Empty;
            Assembly assembly = Assembly.GetExecutingAssembly();
            IEnumerable<Type> controllers = assembly.GetTypes().Where(c => c.IsSubclassOf(typeof(Controller)));
            var targetController = controllers.FirstOrDefault(c => IsControllerOfModel(c, modelName));

            if (targetController != null)
            {
                result = targetController.Name;
            }
            return result;
        }

        private static bool IsControllerOfModel(Type controllerType, string modelName)
        {
            bool result = false;

            var createMethodPost = controllerType.GetMethods()
                                    .FirstOrDefault(method => method.GetParameters().Any() && method.Name == "Create");
            if (createMethodPost != null && createMethodPost.GetParameters().Count() == 1)
            {
                if (createMethodPost.GetParameters()[0].ParameterType.Name == modelName)
                    result = true;
            }
            return result;
        }
    }
}
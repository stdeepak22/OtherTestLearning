﻿using System.Net;
using System.Web.Mvc;
using PaH.BL.Repository;
using PaH.UiModel.ComboModel;
using PaH.UiModel.Resources;

namespace Pet_home.Controllers
{
    /// <summary>
    /// Controller for CRUD operations on Web Category
    /// </summary>
    [Authorize]
    public class WebCategoryController : Controller
    {
        private readonly IRepository _repository;

        public WebCategoryController(IRepository repository)
        {
            _repository = repository;
        }

        // GET: /WebCategory/
        public ActionResult Index()
        {
            return View(_repository.GetAll<WebCategory>());
        }

        // GET: /WebCategory/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            WebCategory webcategory = _repository.Find<WebCategory>(id);
            if (webcategory == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            return View(webcategory);
        }

        // GET: /WebCategory/Create
        public ActionResult Create()
        {
            return View(new WebCategory());
        }

        // POST: /WebCategory/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Name,Description,IsEnabled")] WebCategory webcategory)
        {
            if (ModelState.IsValid)
            {
                webcategory = _repository.Add(webcategory);
                if (webcategory.Id != 0)
                {
                    TempData["Success"] = Message_Resource.Message_Created;
                    return RedirectToAction("Details", null, new { Id = webcategory.Id });
                }
            }
            return View(webcategory);
        }

        // GET: /WebCategory/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            WebCategory webcategory = _repository.Find<WebCategory>(id);
            if (webcategory == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            return View(webcategory);
        }

        // POST: /WebCategory/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Name,Description,IsEnabled")] WebCategory webcategory)
        {
            if (ModelState.IsValid)
            {
                if (_repository.Save(webcategory))
                {
                    TempData["Success"] = Message_Resource.Message_Updated;
                    return RedirectToAction("Details", null, new { Id = webcategory.Id });
                }
            }
            return View(webcategory);
        }

        // POST: /WebCategory/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int? id)
        {
            WebCategory webcategory = _repository.Find<WebCategory>(id);
            if (webcategory == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            _repository.Delete<WebCategory>(id);
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _repository.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}

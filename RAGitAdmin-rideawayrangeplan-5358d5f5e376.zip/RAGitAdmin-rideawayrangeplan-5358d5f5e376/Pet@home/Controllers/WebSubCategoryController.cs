﻿using System.Net;
using System.Web.Mvc;
using PaH.BL.Repository;
using PaH.UiModel.ComboModel;
using PaH.UiModel.Resources;

namespace Pet_home.Controllers
{
    /// <summary>
    /// Controller for CRUD operations on Web Sub Category
    /// </summary>
    [Authorize]
    public class WebSubCategoryController : Controller
    {
        private readonly IRepository _repository;

        public WebSubCategoryController(IRepository repository)
        {
            _repository = repository;
        }

        // GET: /WebSubCategory/
        public ActionResult Index()
        {
            return View(_repository.GetAll<WebSubCategory>());
        }

        // GET: /WebSubCategory/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            WebSubCategory websubcategory = _repository.Find<WebSubCategory>(id);

            if (websubcategory == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            return View(websubcategory);
        }

        // GET: /WebSubCategory/Create
        public ActionResult Create()
        {
            ViewBag.WebCategoryId = new SelectList(_repository.GetComboForNew<WebCategory>(), "Id", "Name");
            return View(new WebSubCategory());
        }

        // POST: /WebSubCategory/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Name,WebCategoryId,Description,IsEnabled")] WebSubCategory websubcategory)
        {
            if (ModelState.IsValid)
            {
                websubcategory = _repository.Add(websubcategory);
                if (websubcategory.Id != 0)
                {
                    TempData["Success"] = Message_Resource.Message_Created;
                    return RedirectToAction("Details", null, new { Id = websubcategory.Id });
                }
            }
            ViewBag.WebCategoryId = new SelectList(_repository.GetComboForNew<WebCategory>(), "Id", "Name", websubcategory.WebCategoryId);
            return View(websubcategory);
        }

        // GET: /WebSubCategory/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            WebSubCategory websubcategory = _repository.Find<WebSubCategory>(id);
            if (websubcategory == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            ViewBag.WebCategoryId = new SelectList(_repository.GetComboForEdit<WebCategory>(websubcategory.WebCategoryId),
                    "Id", "Name", websubcategory.WebCategoryId);
            return View(websubcategory);
        }

        // POST: /WebSubCategory/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Name,WebCategoryId,Description,IsEnabled")] WebSubCategory websubcategory)
        {
            if (ModelState.IsValid)
            {
                if (!_repository.IsEnabled<WebCategory>(websubcategory.WebCategoryId))
                {
                    ModelState.AddModelError("WebCategoryId", Message_Resource.Message_ModelError);
                }
                else if (_repository.Save(websubcategory))
                {
                    TempData["Success"] = Message_Resource.Message_Updated;
                    return RedirectToAction("Details", null, new { Id = websubcategory.Id });
                }
            }
            ViewBag.WebCategoryId = new SelectList(_repository.GetComboForEdit<WebCategory>(websubcategory.WebCategoryId), "Id", "Name", websubcategory.WebCategoryId);
            return View(websubcategory);
        }

        // POST: /WebSubCategory/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int? id)
        {
            WebSubCategory websubcategory = _repository.Find<WebSubCategory>(id);
            if (websubcategory == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            _repository.Delete<WebSubCategory>(id);
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _repository.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}

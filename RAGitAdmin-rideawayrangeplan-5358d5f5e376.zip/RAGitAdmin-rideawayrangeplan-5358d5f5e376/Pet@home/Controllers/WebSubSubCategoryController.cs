﻿using System.Linq;
using System.Net;
using System.Web.Mvc;
using PaH.BL.Repository;
using PaH.UiModel.ComboModel;
using PaH.UiModel.Resources;

namespace Pet_home.Controllers
{
    /// <summary>
    /// Controller for CRUD operations on Web Sub Sub Category
    /// </summary>
    [Authorize]
    public class WebSubSubCategoryController : Controller
    {
        private readonly IRepository _repository;

        public WebSubSubCategoryController(IRepository repository)
        {
            _repository = repository;
        }

        // GET: /WebSubSubCategory/
        public ActionResult Index()
        {
            return View(_repository.GetAll<WebSubSubCategory>());
        }

        // GET: /WebSubSubCategory/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            WebSubSubCategory websubsubcategory = _repository.Find<WebSubSubCategory>(id);
            if (websubsubcategory == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            return View(websubsubcategory);
        }

        // GET: /WebSubSubCategory/Create
        public ActionResult Create()
        {
            ViewBag.WebCategoryId = new SelectList(_repository.GetComboForNew<WebCategory>(), "Id", "Name");
            ViewBag.WebSubCategoryId = new SelectList(_repository.GetComboForNew<WebSubCategory>().Where(c => c.Id < 0), "Id", "Name");
            return View(new WebSubSubCategory());
        }

        // POST: /WebSubSubCategory/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Name,WebSubCategoryId,WebCategoryId,Description,IsEnabled")] WebSubSubCategory websubsubcategory)
        {
            if (ModelState.IsValid)
            {
                websubsubcategory = _repository.Add(websubsubcategory);
                if (websubsubcategory.Id != 0)
                {
                    TempData["Success"] = Message_Resource.Message_Created;
                    return RedirectToAction("Details", null, new { Id = websubsubcategory.Id });
                }
            }
            ViewBag.WebCategoryId = new SelectList(_repository.GetComboForNew<WebCategory>(), "Id", "Name", websubsubcategory.WebCategoryId);
            ViewBag.WebSubCategoryId = new SelectList(_repository.GetComboForNew<WebSubCategory>().Where(c => c.WebCategoryId == websubsubcategory.WebCategoryId), "Id", "Name", websubsubcategory.WebSubCategoryId);
            return View(websubsubcategory);
        }

        // GET: /WebSubSubCategory/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            WebSubSubCategory websubsubcategory = _repository.Find<WebSubSubCategory>(id);
            if (websubsubcategory == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            ViewBag.WebCategoryId = new SelectList(_repository.GetComboForEdit<WebCategory>(websubsubcategory.WebCategoryId), "Id", "Name", websubsubcategory.WebCategoryId);
            ViewBag.WebSubCategoryId = new SelectList(_repository.GetComboForEdit<WebSubCategory>(websubsubcategory.WebSubCategoryId)
                .Where(c => c.WebCategoryId == websubsubcategory.WebCategoryId)
                , "Id", "Name", websubsubcategory.WebSubCategoryId);
            return View(websubsubcategory);
        }

        // POST: /WebSubSubCategory/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Name,WebSubCategoryId,WebCategoryId,Description,IsEnabled")] WebSubSubCategory websubsubcategory)
        {
            if (ModelState.IsValid)
            {
                if (!_repository.IsEnabled<WebCategory>(websubsubcategory.WebCategoryId))
                {
                    ModelState.AddModelError("WebCategoryId", Message_Resource.Message_ModelError);
                }
                else if (!_repository.IsEnabled<WebSubCategory>(websubsubcategory.WebSubCategoryId))
                {
                    ModelState.AddModelError("WebSubCategoryId", Message_Resource.Message_ModelError);
                }
                else if (_repository.Save(websubsubcategory))
                {
                    TempData["Success"] = Message_Resource.Message_Updated;
                    return RedirectToAction("Details", null, new { Id = websubsubcategory.Id });
                }
            }
            ViewBag.WebCategoryId = new SelectList(_repository.GetComboForEdit<WebCategory>(websubsubcategory.WebCategoryId), "Id", "Name", websubsubcategory.WebCategoryId);
            ViewBag.WebSubCategoryId = new SelectList(_repository.GetComboForEdit<WebSubCategory>(websubsubcategory.WebSubCategoryId)
                .Where(c => c.WebCategoryId == websubsubcategory.WebCategoryId)
                , "Id", "Name", websubsubcategory.WebSubCategoryId);
            return View(websubsubcategory);
        }

        // POST: /WebSubSubCategory/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int? id)
        {
            WebSubSubCategory websubsubcategory = _repository.Find<WebSubSubCategory>(id);
            if (websubsubcategory == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            _repository.Delete<WebSubSubCategory>(id);
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _repository.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}

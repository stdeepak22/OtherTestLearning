﻿using System.Net;
using System.Web.Mvc;
using PaH.BL.Repository;
using PaH.UiModel.ComboModel;
using PaH.UiModel.Resources;

namespace Pet_home.Controllers
{
    /// <summary>
    /// Controller for CRUD operations on Yes/No combo 
    /// used in  - ExclusiveToRA, HeroProduct, FreeCode7, ClickandCollect and others
    /// </summary>
    [Authorize]
    public class YesNoController : Controller
    {
        private readonly IRepository _repository;

        public YesNoController(IRepository repository)
        {
            _repository = repository;
        }

        // GET: /YesNo/
        public ActionResult Index()
        {
            return View(_repository.GetAll<YesNo>());
        }

        // GET: /YesNo/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            YesNo yesno = _repository.Find<YesNo>(id);
            if (yesno == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            return View(yesno);
        }

        // GET: /YesNo/Create
        public ActionResult Create()
        {
            return View(new YesNo());
        }

        // POST: /YesNo/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Value,Description,IsEnabled")] YesNo yesno)
        {
            if (ModelState.IsValid)
            {
                yesno = _repository.Add(yesno);
                if (yesno.Id != 0)
                {
                    TempData["Success"] = Message_Resource.Message_Created;
                    return RedirectToAction("Details", null, new { Id = yesno.Id });
                }
            }
            return View(yesno);
        }

        // GET: /YesNo/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            YesNo yesno = _repository.Find<YesNo>(id);
            if (yesno == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            return View(yesno);
        }

        // POST: /YesNo/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Value,Description,IsEnabled")] YesNo yesno)
        {
            if (ModelState.IsValid)
            {
                if (_repository.Save(yesno))
                {
                    TempData["Success"] = Message_Resource.Message_Updated;
                    return RedirectToAction("Details", null, new { Id = yesno.Id });
                }
            }
            return View(yesno);
        }

        // POST: /YesNo/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int? id)
        {
            YesNo yesno = _repository.Find<YesNo>(id);
            if (yesno == null)
            {
                return RedirectToAction("ModelNotFound", controllerName: "Error", routeValues: new { @CntrlName = this.ControllerContext.RouteData.Values["controller"].ToString() });
            }
            _repository.Delete<YesNo>(id);
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _repository.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}

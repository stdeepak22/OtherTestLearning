﻿using System;
using System.Linq.Expressions;
using System.Reflection;
using System.Web.Mvc;
using System.Web.Mvc.Html;

namespace Pet_home.Extension
{
    /// <summary>
    /// Custom HtmlHelper extension methods for Dropdown List
    ///  </summary>
    public static class MVC_DropdownList
    {
        public static MvcHtmlString PAH_DropDownList_Old<TModel, TValue>(this HtmlHelper<TModel> html, Expression<Func<TModel, TValue>> expression, string name, string optionLabel, object htmlAttributes, bool extendAttributes)
        {
            string Combovalue = html.DropDownList(name, optionLabel).ToString();
            Combovalue = Combovalue.Replace("select", "datalist");
            Combovalue = Combovalue.Replace("id=\"" + name + "\"", "id=\"" + name + "_datalist\"");
            string value = html.EditorFor(expression).ToString();
            value = value.Replace("type=\"number\"", "type=\"text\"");
            value = value.Replace("value=\"0\"", "value=\"\"");
            value = value.Insert(value.Length - (value.EndsWith("/>") ? 2 : 1), "list" + "=\"" + name + "_datalist\"");
            PropertyInfo[] properties = htmlAttributes.GetType().GetProperties();
            int index = -1;
            foreach (PropertyInfo info in properties)
            {
                index = value.ToLower().IndexOf(info.Name.ToLower() + "=");
                if (index < 0)
                {
                    value = value.Insert(value.Length - (value.EndsWith("/>") ? 2 : 1), info.Name.ToLower() + "=\"" + info.GetValue(htmlAttributes, null) + "\"");
                }
                else if (extendAttributes)
                {
                    value = value.Insert(index + info.Name.Length + 2, info.GetValue(htmlAttributes, null) + " ");
                }
            }
            value += Combovalue;
            return MvcHtmlString.Create(value);
        }

        public static MvcHtmlString PAH_DropDownList(this HtmlHelper html, string name, string optionLabel, object htmlAttributes, bool extendAttributes)
        {
            string value = html.DropDownList(name, optionLabel).ToString();
            PropertyInfo[] properties = htmlAttributes.GetType().GetProperties();
            int index = -1;
            foreach (PropertyInfo info in properties)
            {
                index = value.ToLower().IndexOf(info.Name.ToLower().Replace("_", "-") + "=");
                if (index < 0)
                {
                    value = value.Insert(value.IndexOf(">"), info.Name.ToLower().Replace("_", "-") + "=\"" + info.GetValue(htmlAttributes, null) + "\"");
                }
                else if (extendAttributes)
                {
                    value = value.Insert(index + info.Name.Length + 2, info.GetValue(htmlAttributes, null) + " ");
                }
            }
            return MvcHtmlString.Create(value);
        }

        public static MvcHtmlString PAH_DropDownListOptionalLabel(this HtmlHelper html, string name, string optionLabel, object htmlAttributes, bool extendAttributes)
        {
            string value = html.DropDownList(name).ToString();
            PropertyInfo[] properties = htmlAttributes.GetType().GetProperties();
            int index = -1;
            foreach (PropertyInfo info in properties)
            {
                index = value.ToLower().IndexOf(info.Name.ToLower().Replace("_", "-") + "=");
                if (index < 0)
                {
                    value = value.Insert(value.IndexOf(">"), info.Name.ToLower().Replace("_", "-") + "=\"" + info.GetValue(htmlAttributes, null) + "\"");
                }
                else if (extendAttributes)
                {
                    value = value.Insert(index + info.Name.Length + 2, info.GetValue(htmlAttributes, null) + " ");
                }
            }
            return MvcHtmlString.Create(value);
        }
    }
}

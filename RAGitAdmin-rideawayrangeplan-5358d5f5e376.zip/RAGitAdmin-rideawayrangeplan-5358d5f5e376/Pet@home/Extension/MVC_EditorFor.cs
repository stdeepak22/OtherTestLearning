﻿using System;
using System.Linq.Expressions;
using System.Reflection;
using System.Web.Mvc;
using System.Web.Mvc.Html;

namespace Pet_home.Extension
{
    /// <summary>
    /// Custom HtmlHelper Extension method for Editor (TextBox/Checkbox), have the 
    /// capability to pass the html attribute
    /// </summary>
    public static class MVC_EditorFor
    {
        public static MvcHtmlString PAH_EditorFor<TModel, TValue>(this HtmlHelper<TModel> html, Expression<Func<TModel, TValue>> expression, Object htmlAttributes, bool extendAttributes)
        {
            string value = html.EditorFor(expression).ToString();
            // not to apply the class on checkbox and positin inline
            if (value.ToLower().IndexOf("type=\"checkbox\"", StringComparison.Ordinal) > 0)
            {
                //commented next line as using bootstrap-checkbox ins _Layout.cshtml
                //value = "<span class=\"checkbox-inline\">" + value + "</span>";
                return MvcHtmlString.Create(value);
            }
            PropertyInfo[] properties = htmlAttributes.GetType().GetProperties();
            int index = -1;
            foreach (PropertyInfo info in properties)
            {
                index = value.ToLower().IndexOf(info.Name.ToLower() + "=");
                if (index < 0)
                {
                    value = value.Insert(value.Length - (value.EndsWith("/>") ? 2 : 1), info.Name.ToLower() + "=\"" + info.GetValue(htmlAttributes, null) + "\"");
                }
                else if (extendAttributes)
                {
                    value = value.Insert(index + info.Name.Length + 2, info.GetValue(htmlAttributes, null) + " ");
                }
            }
            #region Add Autocomplete off
            index = value.ToLower().IndexOf("autocomplete" + "=");
            if (index < 0)
            {
                value = value.Insert(value.Length - (value.EndsWith("/>") ? 2 : 1), "autocomplete=\"off\"");
            }
            #endregion
            return MvcHtmlString.Create(value);
        }
    }
}

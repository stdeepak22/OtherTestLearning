﻿using System;
using System.Linq.Expressions;
using System.Reflection;
using System.Web.Mvc;
using System.Web.Mvc.Html;

namespace Pet_home.Extension
{
    /// <summary>
    /// HtmlHelper extension method for ReadOnly editor --
    /// looks like readonly textbox but in fact these are div or in need
    /// they turns in to checkboxes are well.
    /// </summary>
    public static class MVC_ReadOnlyEditorFor
    {
        public static MvcHtmlString PAH_ReadOnlyEditorFor<TModel, TValue>(this HtmlHelper<TModel> html, Expression<Func<TModel, TValue>> expression, Object htmlAttributes, bool extendAttributes)
        {
            string value = String.Empty;
            string tempValue = html.DisplayFor(expression).ToString();
            string stringTemplate = "<div readonly=\"readonly\" />";
            bool isCheckbox = tempValue.ToLower().IndexOf("type=\"checkbox\"", StringComparison.Ordinal) > 0;
            if (!isCheckbox)
            {
                value = stringTemplate;
            }
            else
            {
                value = tempValue;
            }
            PropertyInfo[] properties = htmlAttributes.GetType().GetProperties();
            foreach (PropertyInfo info in properties)
            {
                //don't apply css on checkbox.
                if (isCheckbox && (info.Name.ToLower().IndexOf("class") > -1))
                    continue;
                int index = value.ToLower().IndexOf(info.Name.ToLower() + "=");
                if (index < 0)
                {
                    value = value.Insert(value.Length - (value.EndsWith("/>") ? 2 : 1), info.Name.ToLower() + "=\"" + info.GetValue(htmlAttributes, null) + "\"");
                }
                else if (extendAttributes)
                {
                    value = value.Insert(index + info.Name.Length + 2, info.GetValue(htmlAttributes, null) + " ");
                }
            }
            if (!isCheckbox)
            {
                value = value.Trim();
                value = value.Replace("/>", ">" + html.Raw(tempValue.Replace(Environment.NewLine, "<br/>")) + "</div>");
            }
            // when checkbox make it inline
            else
            {
                // comment this line as using the checkfox from Bootstrap-checkbox plugin
                //value = "<span class=\"checkbox-inline\">" + value + "</span>";
            }
            return MvcHtmlString.Create(value);
        }
    }
}

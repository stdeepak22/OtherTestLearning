﻿using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using PaH.BL;
using PaH.BL.Repository;
using PaH.UiModel.ComboModel;
using Pet_home.App_Start;

namespace Pet_home
{
    /// <summary>
    /// Global asax class
    /// gets loaded on very first call in IIS
    /// </summary>
    public class MvcApplication : System.Web.HttpApplication
    {
        /// <summary>
        /// On Application start.  First call
        /// </summary>
        protected void Application_Start()
        {
            IRepository _repository = new BasicRepository();            
            AreaRegistration.RegisterAllAreas();            
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);            
            BundleConfig.RegisterBundles(BundleTable.Bundles);
            AutoMapper.ConfigureMapping();
            _repository.GetAll<Age>();
            ControllerFactoryConfig.RegisterCustomControllerFactory();                        
        }

    }
}

﻿//SubCatalogueCategoryId -- Depends upon the Master Catalogue Category, it will get filled with corresponding values
$(function () {
    $('#MasterCatalogueCategoryId').change(function () {
        $.getJSON('/JsonResults/CatalogueSubCategoryList/', { catalogueCatId: $('#MasterCatalogueCategoryId').val() }, function (data) {
            var items = '';
            $.each(data, function (i, subcataloguecategory) {
                items += "<option value='" + subcataloguecategory.Value + "'>" + subcataloguecategory.Text + "</option>";
            });
            $('#SubCatalogueCategoryId').html(items);
        });
    });
});


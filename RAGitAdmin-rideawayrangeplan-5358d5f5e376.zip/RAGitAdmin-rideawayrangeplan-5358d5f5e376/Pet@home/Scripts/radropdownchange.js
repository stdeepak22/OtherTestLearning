﻿//depends upon Category change it should fill up corresponding Sub Categories
$(function () {
    $('#RaCategoryId').change(function () {
        var raCatId = $('#RaCategoryId').val();
        if ((raCatId == "") || isNaN(raCatId)) {
            var items = '<option value=""></option>';
            $('#RaSubCategoryId').html(items);
        }
        else {
            $.getJSON(jsonController + '/RaSubCategoryList/', { raCatId: raCatId }, function (data) {
                var items = '<option value=""></option>';
                $.each(data, function(i, rasubcategory) {
                    items += "<option value='" + rasubcategory.Value + "'>" + rasubcategory.Text + "</option>";
                });
                $('#RaSubCategoryId').html(items);
            });
        }
    });
});
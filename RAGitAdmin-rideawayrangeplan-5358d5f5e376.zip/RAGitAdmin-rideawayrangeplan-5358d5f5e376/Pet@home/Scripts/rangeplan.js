﻿$(document).ready(function () {
    $('#FirstPartShufti').attr("readonly", "readonly");
    $('#Personalised').attr("readonly", "readonly");
    $('#SRPLessVAT').attr("readonly", "readonly");
    $('#CostLessSTDSupplierDiscount').attr("readonly", "readonly");
    $('#CostLessFWDSupplierDiscount').attr("readonly", "readonly");
    $('#MarginPound').attr("readonly", "readonly");
    $('#MarginPercentage').attr("readonly", "readonly");
    $('#RideAwayRetailLessVAT').attr("readonly", "readonly");
    $('#RideAwayMarginPound').attr("readonly", "readonly");
    $('#RideAwayMarginPercentSTDcost').attr("readonly", "readonly");
    $('#RideAwayMarginPercentFWDcost').attr("readonly", "readonly");
    $('#EstimateQty').attr("readonly", "readonly");
    $('#RoundedEstimateQTY').attr("readonly", "readonly");
    $('#RetailEstimateSTDCost').attr("readonly", "readonly");
    $('#RetailEstimateFWDCost').attr("readonly", "readonly");
    $('#RetailEstimateExVAT').attr("readonly", "readonly");
    $('#RetailEstimateIncVAT').attr("readonly", "readonly");
    $('#CurrentSeasonEstimate').attr("readonly", "readonly");
    $('#CurrentSeasonClosingStock').attr("readonly", "readonly");
    $('#CurrentSeasonClosingStockRounded').attr("readonly", "readonly");
    $('#ForwardOrderCPStdDisc').attr("readonly", "readonly");
    $('#ForwardOrderCPFwdDisc').attr("readonly", "readonly");
    $('#ForwardOrderRetailExVAT').attr("readonly", "readonly");
    $('#ForwardOrderRetailINCVAT').attr("readonly", "readonly");
    $('#SplitCheck').attr("readonly", "readonly");
    $('#AnalysisCodeDescription').attr("readonly", "readonly");
    $('#VATCode').attr("readonly", "readonly");
    $('#SupplierCode').attr("readonly", "readonly");
    $('#ProductCategoryCode').attr("readonly", "readonly");
    $('#PrimaryPickWarehouse').attr("readonly", "readonly");
    $('#PrimaryPickLocation').attr("readonly", "readonly");
    $('#BuyingPackQTY').attr("readonly", "readonly");
    $('#M4BuyingPackCost').attr("readonly", "readonly");
    //need in future
    //$('#DefiningAtributeValue1').attr("readonly", "readonly");
    //$('#DefiningAtributeValue2').attr("readonly", "readonly");
    //$('#InStoreOnly').attr("readonly", "readonly");    
    //$('#WebCategory1').attr("readonly", "readonly");
    //$('#WebCategory2').attr("readonly", "readonly");
    //$('#WebCategory3').attr("readonly", "readonly");
    //$('#WebCategory4').attr("readonly", "readonly");
    //$('#WebCategory5').attr("readonly", "readonly");
    //$('#WebCategory6').attr("readonly", "readonly");
    //$('#RaSubCategory').attr("readonly", "readonly");
    $('#RaCategory').attr("readonly", "readonly");
    $('#CatalogueCategory').attr("readonly", "readonly");
});

$(function () {
    
    $('#SuppId').change(function () {
        SetSupplierCode($(this).val());
    });
    
    $('#RaSubCategoryId').change(function () {        
        SetAllParentRaCategory($(this).val());
        //PrimaryPickWarehouse -- if (RA Sub Category) = "FEED" then "S01" else "W01"
        //PrimaryPickLocation -- if (Primary Pick Warehouse) = "W01" then "_____" else "ZSHOP"
        var rasubcategoryVal = $('#RaSubCategoryId option:selected').text();
        var result = rasubcategoryVal.split("-");
        var rasubcategory = result[1];
        if (rasubcategory.toLowerCase().trim() == "feed") {
            $('#PrimaryPickWarehouse').val("S01");
            $('#PrimaryPickLocation').val("ZSHOP");
        }
        else {
            $('#PrimaryPickWarehouse').val("W01");
            $('#PrimaryPickLocation').val("_____");
        }
    });

    $('#Brand, #Description').each(function () {
        $(this).change(function () {
            var brand = $('#Brand').val();
            var description = $('#Description').val();
            var space = " ";
            var temp = brand.concat(space);
            var result = temp.concat(description);
            $('#AnalysisCodeDescription').val(result);
        });
    });

    $('#MainColourId').change(function () {
        var color = $('#MainColourId option:selected').text();
        if (color.toLowerCase().trim() == "custom")
            $('#Personalised').val('Y');
        else
            $('#Personalised').val('N');
    });

    $('#TradeCost').change(function () {
        window.RangePlan.TradeCost = GetValueAsFloat($(this).val());
        SetCostLessSTDSupplierDiscount();
        SetCostLessFWDSupplierDiscount();        
    });
    
    $('#RRP').change(function () {
        RangePlan.RRP = GetValueAsFloat($('#RRP').val());
        SetSRPLessVat();                
    });

    $('#SupplierStandardDiscount').change(function () {
        window.RangePlan.SupplierStandardDiscount = GetValueAsFloat($(this).val())/100;
        SetCostLessSTDSupplierDiscount();
    });

    $('#RideAwayRetail').change(function () {
        RangePlan.RideAwayRetail = GetValueAsFloat($(this).val());
        SetRideAwayRetailLessVAT();
        SetRetailEstimateIncVAT();
        SetForwardOrderRetailINCVAT();
    });
    
    $('#VATId').change(function () {
        RangePlan.VatText = $('#VATId option:selected').text();        
        SetSRPLessVat();
        SetRideAwayRetailLessVAT();
    });

    $('#PackSizeId').change(function () {
        SetBuyingPackQty($(this).val());
    });
    
    $('#SalesUnits').change(function () {
        RangePlan.SalesUnits = GetValueAsFloat($(this).val());
        SetCurrentSeasonClosingStock();
    });
    
    $('#SalesForecastUnits').change(function () {
        RangePlan.SalesForecastUnits = GetValueAsFloat($(this).val());
        SetCurrentSeasonEstimate();
        SetCurrentSeasonClosingStock();
    });
    
    $('#EstimateValExVATAve').change(function () {
        RangePlan.EstimateValExVATAve = GetValueAsFloat($(this).val());
        SetEstimateRoundEstimateQty();
    });
    
    $('#CurrentStock').change(function () {
        RangePlan.CurrentStock = GetValueAsFloat($(this).val());
        SetCurrentSeasonClosingStock();
    });

    $('#ForwardOrderQty').change(function () {
        RangePlan.ForwardOrderQty = GetValueAsFloat($(this).val());
        SetForwardOrderCPStdDisc();
        SetForwardOrderCPFwdDisc();
        SetForwardOrderRetailExVAT();
        SetForwardOrderRetailINCVAT();
        SetSplitCheck();
    });

    $('#FirstDROP, #SecondDROP, #ThirdDROP, #FourthDROP, #FifthDROP, #SixthDROP').each(function () {
        $(this).change(function () {
            RangePlan.FirstDROP = GetValueAsFloat($('#FirstDROP').val());
            RangePlan.SecondDROP = GetValueAsFloat($('#SecondDROP').val());
            RangePlan.ThirdDROP = GetValueAsFloat($('#ThirdDROP').val());
            RangePlan.FourthDROP = GetValueAsFloat($('#FourthDROP').val());
            RangePlan.FifthDROP = GetValueAsFloat($('#FifthDROP').val());
            RangePlan.SixthDROP = GetValueAsFloat($('#SixthDROP').val());
            SetSplitCheck();
        });
    });
 
    $('#SubCatalogueCategoryId').change(function () {
        SetCatalogueCategory($(this).val());
    });

    $('#ProdCategoryId').change(function () {
        SetProductCategoryCode($(this).val());
    });
    
    $('#SupplierForwardOrderDiscount').change(function () {
        RangePlan.SupplierForwardOrderDiscount = GetValueAsFloat($(this).val())/100;
        SetCostLessFWDSupplierDiscount();        
    });        
});

//SRPLessVAT -- if VAT == Free then RRP else (RRP/120*100)
//VATCode -- if (VAT) = "Free" then "02" else "01"
var SetSRPLessVat = function () {       
    if (RangePlan.VatText.toLowerCase().trim() == "free") {
        RangePlan.SRPLessVAT = RangePlan.RRP;
        $('#SRPLessVAT').val(RoundOff(RangePlan.SRPLessVAT,2));        
        $('#VATCode').val("02");
    }
    else {
        RangePlan.SRPLessVAT = (RangePlan.RRP / 120) * 100;
        $('#SRPLessVAT').val(RoundOff(RangePlan.SRPLessVAT,2));        
        $('#VATCode').val("01");
    }
    SetMarginInPound();
    SetMarginPercentage();
};

//CostLessSTDSupplierDiscount -- Trade/Cost -(Trade/Cost * Supplier Standard Discount)
var SetCostLessSTDSupplierDiscount = function () {
    RangePlan.CostLessSTDSupplierDiscount = RangePlan.TradeCost - (RangePlan.TradeCost * RangePlan.SupplierStandardDiscount);
    $('#CostLessSTDSupplierDiscount').val(RoundOff(RangePlan.CostLessSTDSupplierDiscount,2));
    SetMarginInPound();
    SetMarginPercentage();
    SetRideAwayMarginPound();
    SetRideAwayMarginPercentSTDcost();
    SetRetailEstimateSTDCost();
    SetForwardOrderCPStdDisc();
    SetM4BuyingPackCost();
};

//CostLessFWDSupplierDiscount -- Trade/Cost -(Trade/Cost * Supplier Forward Order Discount)
var SetCostLessFWDSupplierDiscount = function () {
    RangePlan.CostLessFWDSupplierDiscount = RangePlan.TradeCost - (RangePlan.TradeCost * RangePlan.SupplierForwardOrderDiscount);
    $('#CostLessFWDSupplierDiscount').val(RoundOff(RangePlan.CostLessFWDSupplierDiscount,2));
    //SetMarginPercentage();
    SetRideAwayMarginPercentFWDcost();
    SetRetailEstimateFWDCost();
    SetForwardOrderCPFwdDisc();
};

//MarginPound -- SRP Less VAT - Cost Less STD Supplier Discount
var SetMarginInPound = function () {
    $('#MarginPound').val(RoundOff(RangePlan.SRPLessVAT - RangePlan.CostLessSTDSupplierDiscount,2));
 };

//MarginPercentage -- (SRP Less VAT - Cost Less STD Supplier Discount)/(SRP Less VAT)
var SetMarginPercentage = function () {
    $('#MarginPercentage').val(RoundOff(((RangePlan.SRPLessVAT - RangePlan.CostLessSTDSupplierDiscount) / RangePlan.SRPLessVAT)*100,2));
};

//RideAwayRetailLessVAT -- if VAT == Free then (Ride - Away Retail) else (Ride-Away Retail/120*100)
var SetRideAwayRetailLessVAT = function () {
    if (RangePlan.VatText.toLowerCase().trim() == "free")
    {
        RangePlan.RideAwayRetailLessVAT = RangePlan.RideAwayRetail;
    }
    else
    {
        RangePlan.RideAwayRetailLessVAT = (RangePlan.RideAwayRetail / 120 ) * 100;        
    }
    $('#RideAwayRetailLessVAT').val(RoundOff(RangePlan.RideAwayRetailLessVAT,2));
    SetRideAwayMarginPound();
    SetRideAwayMarginPercentSTDcost();
    SetRideAwayMarginPercentFWDcost();
    SetEstimateRoundEstimateQty();
    SetRetailEstimateExVAT();
    SetForwardOrderRetailExVAT();
};

//RideAwayMarginPound -- (Ride-Away Retail less VAT) - (Cost Less STD Supplier Discount)
var SetRideAwayMarginPound = function () {
    $('#RideAwayMarginPound').val(RoundOff(RangePlan.RideAwayRetailLessVAT - RangePlan.CostLessSTDSupplierDiscount,2));
};

//RideAwayMarginPercentSTDcost -- (Ride-Away Retail less VAT) - (Cost Less STD Supplier Discount) / (Ride-Away Retail less VAT)
var SetRideAwayMarginPercentSTDcost = function () {
    $('#RideAwayMarginPercentSTDcost').val(RoundOff((((RangePlan.RideAwayRetailLessVAT - RangePlan.CostLessSTDSupplierDiscount) / RangePlan.RideAwayRetailLessVAT))*100,2));
};

//RideAwayMarginPercentFWDcost -- (Ride-Away Retail less VAT) - (Cost Less FWD Supplier Discount) / (Ride-Away Retail less VAT)
var SetRideAwayMarginPercentFWDcost = function () {
    $('#RideAwayMarginPercentFWDcost').val(RoundOff((((RangePlan.RideAwayRetailLessVAT - RangePlan.CostLessFWDSupplierDiscount) / RangePlan.RideAwayRetailLessVAT))*100,2));
};

//EstimateQty -- (Extimate Val Ex VAT (Ave))/(Ride-Away Retail less VAT)
//RoundedEstimateQTY -- Round(Extimate Qty)
var SetEstimateRoundEstimateQty = function () {
    RangePlan.EstimateQty = RangePlan.EstimateValExVATAve / RangePlan.RideAwayRetailLessVAT;
    RangePlan.RoundedEstimateQTY = RoundOff(RangePlan.EstimateQty,0);
    $('#EstimateQty').val(RoundOff(RangePlan.EstimateQty,2));
    $('#RoundedEstimateQTY').val(RangePlan.RoundedEstimateQTY);
    SetRetailEstimateSTDCost();
    SetRetailEstimateFWDCost();
    SetRetailEstimateExVAT();
    SetRetailEstimateIncVAT();
};

//RetailEstimateSTDCost -- (Rounded Estimate QTY) * (Cost Less STD Supplier Discount)
var SetRetailEstimateSTDCost = function () {
    $('#RetailEstimateSTDCost').val(RoundOff(RangePlan.RoundedEstimateQTY * RangePlan.CostLessSTDSupplierDiscount,0));
};

//RetailEstimateFWDCost -- (Rounded Estimate QTY) * (Cost Less FWD Supplier Discount)
var SetRetailEstimateFWDCost = function () {
    //SetEstimateRoundEstimateQty();
    //SetCostLessFWDSupplierDiscount();
    $('#RetailEstimateFWDCost').val(RoundOff(RangePlan.RoundedEstimateQTY * RangePlan.CostLessFWDSupplierDiscount,0));
};

//RetailEstimateExVAT -- (Rounded Estimate Qty) *(Ride-Away Retail less VAT)
var SetRetailEstimateExVAT = function () {
    $('#RetailEstimateExVAT').val(RoundOff(RangePlan.RoundedEstimateQTY * RangePlan.RideAwayRetailLessVAT,2));
};

//RetailEstimateIncVAT -- (Rounded Estimate Qty) * (Ride Away Retail)
var SetRetailEstimateIncVAT = function () {
    $('#RetailEstimateIncVAT').val(RoundOff(RangePlan.RoundedEstimateQTY * RangePlan.RideAwayRetail,2));
};

//CurrentSeasonEstimate -- (SS14 Sales Forecast Units)
var SetCurrentSeasonEstimate = function () {
    $('#CurrentSeasonEstimate').val(RoundOff(RangePlan.SalesForecastUnits,2));
};

//CurrentSeasonClosingStock -- If (SS14 Sales Unit) - (SS14 Sales Forecast Units) + (Current Stock) < 0 then 0 
//else (SS14 Sales Unit) - (SS14 Sales Forecast Units) + (Current Stock)
var SetCurrentSeasonClosingStock = function () {
    var result = RangePlan.SalesUnits - RangePlan.SalesForecastUnits + RangePlan.CurrentStock;
    if (result < 0) {
        $('#CurrentSeasonClosingStock').val(0);
        $('#CurrentSeasonClosingStockRounded').val(0);
    }
    else {
        $('#CurrentSeasonClosingStock').val(RoundOff(GetValueAsFloat(result),2));
        $('#CurrentSeasonClosingStockRounded').val(Math.round(GetValueAsFloat(result)));
    }
};

//ForwardOrderCPStdDisc -- (Cost Less STD Supplier Discount) * (Forward Order Qty)
var SetForwardOrderCPStdDisc = function () {
    $('#ForwardOrderCPStdDisc').val(RoundOff(RangePlan.CostLessSTDSupplierDiscount * RangePlan.ForwardOrderQty,0));
};

//ForwardOrderCPFwdDisc -- (Cost Less FWD Supplier Discount) * (Forward Order Qty)
var SetForwardOrderCPFwdDisc = function () {
    $('#ForwardOrderCPFwdDisc').val(RoundOff(RangePlan.CostLessFWDSupplierDiscount * RangePlan.ForwardOrderQty,0));
};

//ForwardOrderRetailExVAT -- (Ride-Away Retail less VAT) * (Forward Order Qty)
var SetForwardOrderRetailExVAT = function () {
    $('#ForwardOrderRetailExVAT').val(RoundOff(RangePlan.RideAwayRetailLessVAT * RangePlan.ForwardOrderQty,2));
};

//ForwardOrderRetailINCVAT -- (Ride-Away Retail) * (Forward Order Qty)
var SetForwardOrderRetailINCVAT = function () {
    $('#ForwardOrderRetailINCVAT').val(RoundOff(RangePlan.RideAwayRetail * RangePlan.ForwardOrderQty,2));
};

//SplitCheck -- (1st Drop + 2nd Drop + 3rd Drop + 4th Drop + 5th Drop + 6th Drop) - (Forward Order Qty)
var SetSplitCheck = function () {
    $('#SplitCheck').val(RoundOff(RangePlan.FirstDROP + RangePlan.SecondDROP + RangePlan.ThirdDROP + RangePlan.FourthDROP + RangePlan.FifthDROP + RangePlan.SixthDROP - RangePlan.ForwardOrderQty,2));
};

//M4BuyingPackCost -- (Cost Less STD Supplier Discount) * Buying Pack Qty
var SetM4BuyingPackCost = function () {
    $('#M4BuyingPackCost').val(RoundOff(RangePlan.CostLessSTDSupplierDiscount * RangePlan.BuyingPackQTY,2));
};

function GetValueAsFloat(val)
{
    if ((val+"").trim().length == 0) {
        return parseFloat("0");
    }
    else if (isNaN(val)) {
        return parseFloat("0");
    }
    else if ((val === Infinity) || (val === -Infinity)) {
        return parseFloat("0");
    }
    else {
        return parseFloat(val);
    }
}

function RoundOff(val, decimalplaces) {
    var calc = Math.pow(10,decimalplaces);
    return parseFloat((Math.round(GetValueAsFloat(val) * calc)) / calc).toFixed(decimalplaces);
}


    


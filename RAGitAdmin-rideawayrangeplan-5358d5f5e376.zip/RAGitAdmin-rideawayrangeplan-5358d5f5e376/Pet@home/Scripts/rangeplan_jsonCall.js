﻿window.RangePlan = {    
    TradeCost: 0,
    SupplierStandardDiscount: 0,
    SupplierForwardOrderDiscount: 0,
    VatText: '',
    RRP: 0,
    SRPLessVAT: 0,
    CostLessSTDSupplierDiscount: 0,
    CostLessFWDSupplierDiscount: 0,
    RideAwayRetail: 0,
    RideAwayRetailLessVAT: 0,
    EstimateValExVATAve: 0,
    EstimateQty: 0,
    RoundedEstimateQTY: 0,    
    Brand: '',    
    Description: '',
    BuyingPackQTY: 0,
    SuppId: null,
    SupplierCode: '',
    ForwardOrderQty: 0,
    FirstDROP: 0,
    SecondDROP: 0,
    ThirdDROP: 0,
    FourthDROP: 0,
    FifthDROP: 0,
    SixthDROP: 0
};

function SetSupplierCode(supplierId) {
    if ((supplierId == "") || isNaN(supplierId)) {
        $('#SupplierCode').val('');        
    } else {
        $.getJSON(jsonController + '/GetSupplierCode/', { supplierId: supplierId }, function (data) {
            $('#SupplierCode').val(data.Code);
        });
    }    
};


function SetAllParentRaCategory(raSubCatId) {
    if ((raSubCatId == "") || isNaN(raSubCatId)) {
        $('#RaCategory').val('');
        //$('#RaSubCategory').val('');
        $('#FirstPartShufti').val('');
    }
    else {
        $.getJSON(jsonController + '/GetAllParentRaCategory/', { raSubCatId: raSubCatId }, function (data) {
            $('#RaCategory').val(data.Name);
            //$('#RaSubCategory').val(data.SubName);
            $('#FirstPartShufti').val(data.FirstPartShufti);
        });
    }
}

function SetCatalogueCategory(subCatalogueCatId) {
    if ((subCatalogueCatId == "") || isNaN(subCatalogueCatId)) {
        $('#CatalogueCategory').val('');        
    }
    else {
        $.getJSON(jsonController + '/GetCatalogueCategory/', { subCatalogueCatId: subCatalogueCatId }, function (data) {
            $('#CatalogueCategory').val(data.Name);            
        });
    }
}

function SetProductCategoryCode(productCatId) {
    if ((productCatId == "") || isNaN(productCatId)) {
        $('#ProductCategoryCode').val('');
    }
    else {
        $.getJSON(jsonController + '/GetProductCategoryCode/', { productCatId: productCatId }, function (data) {
            $('#ProductCategoryCode').val(data.Code);
        });
    }
};



function SetBuyingPackQty(packSizeId) {
    if ((packSizeId == "") || isNaN(packSizeId)) {        
        window.RangePlan.BuyingPackQTY = GetValueAsFloat("0");
        $('#BuyingPackQTY').val(RangePlan.BuyingPackQTY);
        SetM4BuyingPackCost();
    }
    else {
        $.getJSON(jsonController + '/GetBuyingPackQuantity/', { packSizeId: packSizeId }, function (data) {

            window.RangePlan.BuyingPackQTY = GetValueAsFloat(data.Quantity);
            $('#BuyingPackQTY').val(RangePlan.BuyingPackQTY);
            SetM4BuyingPackCost();
        });
    }
}
    

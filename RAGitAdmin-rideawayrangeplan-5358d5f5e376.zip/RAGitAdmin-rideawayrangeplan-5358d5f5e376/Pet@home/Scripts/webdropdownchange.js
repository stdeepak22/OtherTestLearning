﻿//depends upon Category change it should fill up corresponding Sub Categories
$(function () {
    $('#WebCategoryId').change(function () {
        var webCatId = $('#WebCategoryId').val();
        if ((webCatId == "") || isNaN(webCatId)) {
            var items = '<option value=""></option>';
            $('#WebSubCategoryId').html(items);
        }
        else {
            $.getJSON(jsonController+ '/WebSubCategoryList/', { webCatId: $('#WebCategoryId').val() }, function(data) {
                var items = '<option value=""></option>';
                $.each(data, function(i, websubcategory) {
                    items += "<option value='" + websubcategory.Value + "'>" + websubcategory.Text + "</option>";
                });
                $('#WebSubCategoryId').html(items);
            });
        }
    });
});